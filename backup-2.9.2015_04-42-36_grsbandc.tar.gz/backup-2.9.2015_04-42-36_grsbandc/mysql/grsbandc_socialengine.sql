-- MySQL dump 10.13  Distrib 5.5.40, for Linux (x86_64)
--
-- Host: localhost    Database: grsbandc_socialengine
-- ------------------------------------------------------
-- Server version	5.5.40-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `engine4_activity_actions`
--

DROP TABLE IF EXISTS `engine4_activity_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_activity_actions` (
  `action_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `subject_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `subject_id` int(11) unsigned NOT NULL,
  `object_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `object_id` int(11) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `params` text COLLATE utf8_unicode_ci,
  `date` datetime NOT NULL,
  `attachment_count` smallint(3) unsigned NOT NULL DEFAULT '0',
  `comment_count` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `like_count` mediumint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`action_id`),
  KEY `SUBJECT` (`subject_type`,`subject_id`),
  KEY `OBJECT` (`object_type`,`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_activity_actions`
--

LOCK TABLES `engine4_activity_actions` WRITE;
/*!40000 ALTER TABLE `engine4_activity_actions` DISABLE KEYS */;
INSERT INTO `engine4_activity_actions` (`action_id`, `type`, `subject_type`, `subject_id`, `object_type`, `object_id`, `body`, `params`, `date`, `attachment_count`, `comment_count`, `like_count`) VALUES (1,'signup','user',2,'user',2,'','[]','2014-10-17 11:11:57',0,0,0),(2,'event_create','user',2,'event',1,'','[]','2014-10-17 11:27:56',1,0,0),(3,'signup','user',3,'user',3,'','[]','2014-10-17 11:30:55',0,0,0),(4,'event_join','user',3,'event',1,'','[]','2014-10-17 11:31:18',0,0,0),(5,'signup','user',4,'user',4,'','[]','2014-10-23 03:24:47',0,0,0),(6,'profile_photo_update','user',1,'user',1,'{item:$subject} added a new profile photo.','[]','2014-10-23 23:40:55',1,0,0),(7,'status','user',1,'user',1,'Yoo Im Emil and I rule!!','[]','2014-10-23 23:42:02',0,0,0),(8,'album_photo_new','user',1,'album',1,'','{\"count\":4}','2014-10-23 23:45:33',4,0,0),(9,'friends','user',1,'user',4,'{item:$object} is now friends with {item:$subject}.','[]','2014-10-24 01:15:49',0,0,0),(10,'friends','user',4,'user',1,'{item:$object} is now friends with {item:$subject}.','[]','2014-10-24 01:15:49',0,0,0),(11,'signup','user',5,'user',5,'','[]','2014-10-27 01:45:59',0,0,0),(12,'status','user',5,'user',5,'Hello!!','[]','2014-10-27 01:46:49',0,0,0),(13,'profile_photo_update','user',5,'user',5,'{item:$subject} added a new profile photo.','[]','2014-10-27 01:48:06',1,0,1),(14,'profile_photo_update','user',4,'user',4,'{item:$subject} added a new profile photo.','[]','2014-10-28 02:26:58',1,0,0),(15,'group_create','user',1,'group',1,'','[]','2014-10-28 10:53:51',1,0,0),(16,'event_create','user',1,'event',2,'','[]','2014-10-28 10:55:52',1,0,0),(17,'donation_charity_new','user',1,'donation',1,'','[]','2014-10-28 11:14:14',1,0,0),(18,'donation_project_new','user',1,'donation',2,'','[]','2014-10-28 11:18:10',1,0,0);
/*!40000 ALTER TABLE `engine4_activity_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_activity_actionsettings`
--

DROP TABLE IF EXISTS `engine4_activity_actionsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_activity_actionsettings` (
  `user_id` int(11) unsigned NOT NULL,
  `type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_activity_actionsettings`
--

LOCK TABLES `engine4_activity_actionsettings` WRITE;
/*!40000 ALTER TABLE `engine4_activity_actionsettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_activity_actionsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_activity_actiontypes`
--

DROP TABLE IF EXISTS `engine4_activity_actiontypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_activity_actiontypes` (
  `type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `module` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `displayable` tinyint(1) NOT NULL DEFAULT '3',
  `attachable` tinyint(1) NOT NULL DEFAULT '1',
  `commentable` tinyint(1) NOT NULL DEFAULT '1',
  `shareable` tinyint(1) NOT NULL DEFAULT '1',
  `is_generated` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_activity_actiontypes`
--

LOCK TABLES `engine4_activity_actiontypes` WRITE;
/*!40000 ALTER TABLE `engine4_activity_actiontypes` DISABLE KEYS */;
INSERT INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `enabled`, `displayable`, `attachable`, `commentable`, `shareable`, `is_generated`) VALUES ('album_photo_new','album','{item:$subject} added {var:$count} photo(s) to the album {item:$object}:',1,5,1,3,1,1),('blog_new','blog','{item:$subject} wrote a new blog entry:',1,5,1,3,1,1),('classified_new','classified','{item:$subject} posted a new classified listing:',1,5,1,3,1,1),('comment_album','album','{item:$subject} commented on {item:$owner}\'s {item:$object:album}: {body:$body}',1,1,1,1,1,0),('comment_album_photo','album','{item:$subject} commented on {item:$owner}\'s {item:$object:photo}: {body:$body}',1,1,1,1,1,0),('comment_blog','blog','{item:$subject} commented on {item:$owner}\'s {item:$object:blog entry}: {body:$body}',1,1,1,1,1,0),('comment_classified','classified','{item:$subject} commented on {item:$owner}\'s {item:$object:classified listing}: {body:$body}',1,1,1,1,1,0),('comment_playlist','music','{item:$subject} commented on {item:$owner}\'s {item:$object:music_playlist}.',1,1,1,1,1,1),('comment_poll','poll','{item:$subject} commented on {item:$owner}\'s {item:$object:poll}.',1,1,1,1,1,1),('comment_video','video','{item:$subject} commented on {item:$owner}\'s {item:$object:video}: {body:$body}',1,1,1,1,1,0),('donation_charity_new','donation','{item:$subject} posted a new charity:',1,7,1,1,1,1),('donation_fundraise_new','donation','{item:$subject}  is raising funds for {itemParent:$object}:',1,7,1,1,1,1),('donation_project_new','donation','{item:$subject} posted a new project:',1,7,1,1,1,1),('event_create','event','{item:$subject} created a new event:',1,5,1,1,1,1),('event_join','event','{item:$subject} joined the event {item:$object}',1,3,1,1,1,1),('event_photo_upload','event','{item:$subject} added {var:$count} photo(s).',1,3,2,1,1,1),('event_topic_create','event','{item:$subject} posted a {item:$object:topic} in the event {itemParent:$object:event}: {body:$body}',1,3,1,1,1,1),('event_topic_reply','event','{item:$subject} replied to a {item:$object:topic} in the event {itemParent:$object:event}: {body:$body}',1,3,1,1,1,1),('forum_promote','forum','{item:$subject} has been made a moderator for the forum {item:$object}',1,3,1,1,1,1),('forum_topic_create','forum','{item:$subject} posted a {item:$object:topic} in the forum {itemParent:$object:forum}: {body:$body}',1,3,1,1,1,1),('forum_topic_reply','forum','{item:$subject} replied to a {item:$object:topic} in the forum {itemParent:$object:forum}: {body:$body}',1,3,1,1,1,1),('friends','user','{item:$subject} is now friends with {item:$object}.',1,3,0,1,1,1),('friends_follow','user','{item:$subject} is now following {item:$object}.',1,3,0,1,1,1),('group_create','group','{item:$subject} created a new group:',1,5,1,1,1,1),('group_join','group','{item:$subject} joined the group {item:$object}',1,3,1,1,1,1),('group_photo_upload','group','{item:$subject} added {var:$count} photo(s).',1,3,2,1,1,1),('group_promote','group','{item:$subject} has been made an officer for the group {item:$object}',1,3,1,1,1,1),('group_topic_create','group','{item:$subject} posted a {itemChild:$object:topic:$child_id} in the group {item:$object}: {body:$body}',1,3,1,1,1,1),('group_topic_reply','group','{item:$subject} replied to a {itemChild:$object:topic:$child_id} in the group {item:$object}: {body:$body}',1,3,1,1,1,1),('like_item','like','{var:$content}',1,6,0,1,1,0),('like_item_private','like','{var:$content}',1,1,0,1,1,0),('login','user','{item:$subject} has signed in.',0,1,0,1,1,1),('logout','user','{item:$subject} has signed out.',0,1,0,1,1,1),('music_playlist_new','music','{item:$subject} created a new playlist: {item:$object}',1,5,1,3,1,1),('network_join','network','{item:$subject} joined the network {item:$object}',1,3,1,1,1,1),('page_charity_new','donation','{actors:$subject:$object} posted a new charity:',1,7,1,1,1,1),('page_project_new','donation','{actors:$subject:$object} posted a new project:',1,7,1,1,1,1),('poll_new','poll','{item:$subject} created a new poll:',1,5,1,3,1,1),('post','user','{actors:$subject:$object}: {body:$body}',1,7,1,1,1,0),('post_self','user','{item:$subject} {body:$body}',1,5,1,1,1,0),('profile_photo_update','user','{item:$subject} has added a new profile photo.',1,5,1,1,1,1),('share','activity','{item:$subject} shared {item:$object}\'s {var:$type}. {body:$body}',1,5,1,1,0,1),('signup','user','{item:$subject} has just signed up. Say hello!',1,5,0,1,1,1),('status','user','{item:$subject} {body:$body}',1,5,0,1,4,0),('tagged','user','{item:$subject} tagged {item:$object} in a {var:$label}:',1,7,1,1,0,1),('video_new','video','{item:$subject} posted a new video:',1,5,1,3,1,0);
/*!40000 ALTER TABLE `engine4_activity_actiontypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_activity_attachments`
--

DROP TABLE IF EXISTS `engine4_activity_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_activity_attachments` (
  `attachment_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` int(11) unsigned NOT NULL,
  `type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `mode` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`attachment_id`),
  KEY `action_id` (`action_id`),
  KEY `type_id` (`type`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_activity_attachments`
--

LOCK TABLES `engine4_activity_attachments` WRITE;
/*!40000 ALTER TABLE `engine4_activity_attachments` DISABLE KEYS */;
INSERT INTO `engine4_activity_attachments` (`attachment_id`, `action_id`, `type`, `id`, `mode`) VALUES (1,2,'event',1,1),(2,6,'album_photo',1,1),(3,8,'album_photo',2,2),(4,8,'album_photo',3,2),(5,8,'album_photo',4,2),(6,8,'album_photo',5,2),(7,13,'album_photo',6,1),(8,14,'album_photo',7,1),(9,15,'group',1,1),(10,16,'event',2,1),(11,17,'donation',1,1),(12,18,'donation',2,1);
/*!40000 ALTER TABLE `engine4_activity_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_activity_comments`
--

DROP TABLE IF EXISTS `engine4_activity_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_activity_comments` (
  `comment_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) unsigned NOT NULL,
  `poster_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `poster_id` int(11) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `like_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`),
  KEY `resource_type` (`resource_id`),
  KEY `poster_type` (`poster_type`,`poster_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_activity_comments`
--

LOCK TABLES `engine4_activity_comments` WRITE;
/*!40000 ALTER TABLE `engine4_activity_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_activity_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_activity_likes`
--

DROP TABLE IF EXISTS `engine4_activity_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_activity_likes` (
  `like_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) unsigned NOT NULL,
  `poster_type` varchar(16) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `poster_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`like_id`),
  KEY `resource_id` (`resource_id`),
  KEY `poster_type` (`poster_type`,`poster_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_activity_likes`
--

LOCK TABLES `engine4_activity_likes` WRITE;
/*!40000 ALTER TABLE `engine4_activity_likes` DISABLE KEYS */;
INSERT INTO `engine4_activity_likes` (`like_id`, `resource_id`, `poster_type`, `poster_id`) VALUES (1,13,'user',4);
/*!40000 ALTER TABLE `engine4_activity_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_activity_notifications`
--

DROP TABLE IF EXISTS `engine4_activity_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_activity_notifications` (
  `notification_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `subject_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `subject_id` int(11) unsigned NOT NULL,
  `object_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `object_id` int(11) unsigned NOT NULL,
  `type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `params` text COLLATE utf8_unicode_ci,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `mitigated` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `LOOKUP` (`user_id`,`date`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `object` (`object_type`,`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_activity_notifications`
--

LOCK TABLES `engine4_activity_notifications` WRITE;
/*!40000 ALTER TABLE `engine4_activity_notifications` DISABLE KEYS */;
INSERT INTO `engine4_activity_notifications` (`notification_id`, `user_id`, `subject_type`, `subject_id`, `object_type`, `object_id`, `type`, `params`, `read`, `mitigated`, `date`) VALUES (1,4,'user',1,'user',4,'friend_request','',1,1,'2014-10-23 23:41:26'),(2,1,'user',4,'user',1,'friend_accepted','',0,0,'2014-10-24 01:15:49'),(3,5,'user',4,'activity_action',13,'liked','{\"label\":\"post\"}',1,0,'2014-10-28 02:26:33');
/*!40000 ALTER TABLE `engine4_activity_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_activity_notificationsettings`
--

DROP TABLE IF EXISTS `engine4_activity_notificationsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_activity_notificationsettings` (
  `user_id` int(11) unsigned NOT NULL,
  `type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `email` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_activity_notificationsettings`
--

LOCK TABLES `engine4_activity_notificationsettings` WRITE;
/*!40000 ALTER TABLE `engine4_activity_notificationsettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_activity_notificationsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_activity_notificationtypes`
--

DROP TABLE IF EXISTS `engine4_activity_notificationtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_activity_notificationtypes` (
  `type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `module` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `is_request` tinyint(1) NOT NULL DEFAULT '0',
  `handler` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `default` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_activity_notificationtypes`
--

LOCK TABLES `engine4_activity_notificationtypes` WRITE;
/*!40000 ALTER TABLE `engine4_activity_notificationtypes` DISABLE KEYS */;
INSERT INTO `engine4_activity_notificationtypes` (`type`, `module`, `body`, `is_request`, `handler`, `default`) VALUES ('blog_subscribed_new','blog','{item:$subject} has posted a new blog entry: {item:$object}.',0,'',1),('commented','activity','{item:$subject} has commented on your {item:$object:$label}.',0,'',1),('commented_commented','activity','{item:$subject} has commented on a {item:$object:$label} you commented on.',0,'',1),('event_accepted','event','Your request to join the event {item:$object} has been approved.',0,'',1),('event_approve','event','{item:$subject} has requested to join the event {item:$object}.',0,'',1),('event_discussion_reply','event','{item:$subject} has {item:$object:posted} on a {itemParent:$object::event topic} you posted on.',0,'',1),('event_discussion_response','event','{item:$subject} has {item:$object:posted} on a {itemParent:$object::event topic} you created.',0,'',1),('event_invite','event','{item:$subject} has invited you to the event {item:$object}.',1,'event.widget.request-event',1),('forum_promote','forum','You were promoted to moderator in the forum {item:$object}.',0,'',1),('forum_topic_reply','forum','{item:$subject} has {item:$object:posted:$url} on a {itemParent:$object::forum topic} posted on.',0,'',1),('forum_topic_response','forum','{item:$subject} has {item:$object:posted:$url} on a {itemParent:$object::forum topic} you created.',0,'',1),('friend_accepted','user','You and {item:$subject} are now friends.',0,'',1),('friend_follow','user','{item:$subject} is now following you.',0,'',1),('friend_follow_accepted','user','You are now following {item:$subject}.',0,'',1),('friend_follow_request','user','{item:$subject} has requested to follow you.',1,'user.friends.request-follow',1),('friend_request','user','{item:$subject} has requested to be your friend.',1,'user.friends.request-friend',1),('group_accepted','group','Your request to join the group {item:$object} has been approved.',0,'',1),('group_approve','group','{item:$subject} has requested to join the group {item:$object}.',0,'',1),('group_discussion_reply','group','{item:$subject} has {item:$object:posted} on a {itemParent:$object::group topic} you posted on.',0,'',1),('group_discussion_response','group','{item:$subject} has {item:$object:posted} on a {itemParent:$object::group topic} you created.',0,'',1),('group_invite','group','{item:$subject} has invited you to the group {item:$object}.',1,'group.widget.request-group',1),('group_promote','group','You were promoted to officer in the group {item:$object}.',0,'',1),('liked','activity','{item:$subject} likes your {item:$object:$label}.',0,'',1),('liked_commented','activity','{item:$subject} has commented on a {item:$object:$label} you liked.',0,'',1),('like_send_update','like','{item:$subject} send you to an update about {item:$object}.',0,'',1),('like_suggest','like','{item:$subject} suggest you to check this out {item:$object}.',0,'',1),('message_new','messages','{item:$subject} has sent you a {item:$object:message}.',0,'',1),('post_user','user','{item:$subject} has posted on your {item:$object:profile}.',0,'',1),('shared','activity','{item:$subject} has shared your {item:$object:$label}.',0,'',1),('tagged','user','{item:$subject} tagged you in a {item:$object:$label}.',0,'',1),('video_processed','video','Your {item:$object:video} is ready to be viewed.',0,'',1),('video_processed_failed','video','Your {item:$object:video} has failed to process.',0,'',1);
/*!40000 ALTER TABLE `engine4_activity_notificationtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_activity_stream`
--

DROP TABLE IF EXISTS `engine4_activity_stream`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_activity_stream` (
  `target_type` varchar(16) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `target_id` int(11) unsigned NOT NULL,
  `subject_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `subject_id` int(11) unsigned NOT NULL,
  `object_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `object_id` int(11) unsigned NOT NULL,
  `type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `action_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`target_type`,`target_id`,`action_id`),
  KEY `SUBJECT` (`subject_type`,`subject_id`,`action_id`),
  KEY `OBJECT` (`object_type`,`object_id`,`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_activity_stream`
--

LOCK TABLES `engine4_activity_stream` WRITE;
/*!40000 ALTER TABLE `engine4_activity_stream` DISABLE KEYS */;
INSERT INTO `engine4_activity_stream` (`target_type`, `target_id`, `subject_type`, `subject_id`, `object_type`, `object_id`, `type`, `action_id`) VALUES ('event',1,'user',2,'event',1,'event_create',2),('event',1,'user',3,'event',1,'event_join',4),('event',2,'user',1,'event',2,'event_create',16),('everyone',0,'user',2,'user',2,'signup',1),('everyone',0,'user',2,'event',1,'event_create',2),('everyone',0,'user',3,'user',3,'signup',3),('everyone',0,'user',3,'event',1,'event_join',4),('everyone',0,'user',4,'user',4,'signup',5),('everyone',0,'user',1,'user',1,'profile_photo_update',6),('everyone',0,'user',1,'user',1,'status',7),('everyone',0,'user',1,'album',1,'album_photo_new',8),('everyone',0,'user',1,'user',4,'friends',9),('everyone',0,'user',4,'user',1,'friends',10),('everyone',0,'user',5,'user',5,'signup',11),('everyone',0,'user',5,'user',5,'status',12),('everyone',0,'user',5,'user',5,'profile_photo_update',13),('everyone',0,'user',4,'user',4,'profile_photo_update',14),('everyone',0,'user',1,'group',1,'group_create',15),('everyone',0,'user',1,'event',2,'event_create',16),('everyone',0,'user',1,'donation',1,'donation_charity_new',17),('everyone',0,'user',1,'donation',2,'donation_project_new',18),('group',1,'user',1,'group',1,'group_create',15),('members',1,'user',1,'user',1,'profile_photo_update',6),('members',1,'user',1,'user',1,'status',7),('members',1,'user',4,'user',1,'friends',10),('members',1,'user',1,'event',2,'event_create',16),('members',2,'user',2,'user',2,'signup',1),('members',2,'user',2,'event',1,'event_create',2),('members',2,'user',3,'event',1,'event_join',4),('members',3,'user',3,'user',3,'signup',3),('members',4,'user',4,'user',4,'signup',5),('members',4,'user',1,'user',4,'friends',9),('members',4,'user',4,'user',4,'profile_photo_update',14),('members',5,'user',5,'user',5,'signup',11),('members',5,'user',5,'user',5,'status',12),('members',5,'user',5,'user',5,'profile_photo_update',13),('owner',1,'user',1,'user',1,'profile_photo_update',6),('owner',1,'user',1,'user',1,'status',7),('owner',1,'user',1,'album',1,'album_photo_new',8),('owner',1,'user',1,'user',4,'friends',9),('owner',1,'user',1,'group',1,'group_create',15),('owner',1,'user',1,'event',2,'event_create',16),('owner',1,'user',1,'donation',1,'donation_charity_new',17),('owner',1,'user',1,'donation',2,'donation_project_new',18),('owner',2,'user',2,'user',2,'signup',1),('owner',2,'user',2,'event',1,'event_create',2),('owner',3,'user',3,'user',3,'signup',3),('owner',3,'user',3,'event',1,'event_join',4),('owner',4,'user',4,'user',4,'signup',5),('owner',4,'user',4,'user',1,'friends',10),('owner',4,'user',4,'user',4,'profile_photo_update',14),('owner',5,'user',5,'user',5,'signup',11),('owner',5,'user',5,'user',5,'status',12),('owner',5,'user',5,'user',5,'profile_photo_update',13),('parent',1,'user',1,'user',1,'profile_photo_update',6),('parent',1,'user',1,'user',1,'status',7),('parent',1,'user',1,'album',1,'album_photo_new',8),('parent',1,'user',4,'user',1,'friends',10),('parent',1,'user',1,'group',1,'group_create',15),('parent',1,'user',1,'event',2,'event_create',16),('parent',2,'user',2,'user',2,'signup',1),('parent',2,'user',2,'event',1,'event_create',2),('parent',2,'user',3,'event',1,'event_join',4),('parent',3,'user',3,'user',3,'signup',3),('parent',4,'user',4,'user',4,'signup',5),('parent',4,'user',1,'user',4,'friends',9),('parent',4,'user',4,'user',4,'profile_photo_update',14),('parent',5,'user',5,'user',5,'signup',11),('parent',5,'user',5,'user',5,'status',12),('parent',5,'user',5,'user',5,'profile_photo_update',13),('registered',0,'user',2,'user',2,'signup',1),('registered',0,'user',2,'event',1,'event_create',2),('registered',0,'user',3,'user',3,'signup',3),('registered',0,'user',3,'event',1,'event_join',4),('registered',0,'user',4,'user',4,'signup',5),('registered',0,'user',1,'user',1,'profile_photo_update',6),('registered',0,'user',1,'user',1,'status',7),('registered',0,'user',1,'user',4,'friends',9),('registered',0,'user',4,'user',1,'friends',10),('registered',0,'user',5,'user',5,'signup',11),('registered',0,'user',5,'user',5,'status',12),('registered',0,'user',5,'user',5,'profile_photo_update',13),('registered',0,'user',4,'user',4,'profile_photo_update',14),('registered',0,'user',1,'group',1,'group_create',15),('registered',0,'user',1,'event',2,'event_create',16),('registered',0,'user',1,'donation',1,'donation_charity_new',17),('registered',0,'user',1,'donation',2,'donation_project_new',18);
/*!40000 ALTER TABLE `engine4_activity_stream` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_album_albums`
--

DROP TABLE IF EXISTS `engine4_album_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_album_albums` (
  `album_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `owner_type` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `owner_id` int(11) unsigned NOT NULL,
  `category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `photo_id` int(11) unsigned NOT NULL DEFAULT '0',
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `type` enum('wall','profile','message','blog') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`album_id`),
  KEY `owner_type` (`owner_type`,`owner_id`),
  KEY `category_id` (`category_id`),
  KEY `search` (`search`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_album_albums`
--

LOCK TABLES `engine4_album_albums` WRITE;
/*!40000 ALTER TABLE `engine4_album_albums` DISABLE KEYS */;
INSERT INTO `engine4_album_albums` (`album_id`, `title`, `description`, `owner_type`, `owner_id`, `category_id`, `creation_date`, `modified_date`, `photo_id`, `view_count`, `comment_count`, `search`, `type`) VALUES (1,'Profile Photos','','user',1,0,'2014-10-23 23:40:56','2014-10-23 23:47:14',1,0,0,1,'profile'),(2,'Profile Photos','','user',5,0,'2014-10-27 01:48:06','2014-10-27 01:48:07',6,0,0,1,'profile'),(3,'Profile Photos','','user',4,0,'2014-10-28 02:26:58','2014-10-28 02:26:59',7,0,0,1,'profile');
/*!40000 ALTER TABLE `engine4_album_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_album_categories`
--

DROP TABLE IF EXISTS `engine4_album_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_album_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `category_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`category_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_album_categories`
--

LOCK TABLES `engine4_album_categories` WRITE;
/*!40000 ALTER TABLE `engine4_album_categories` DISABLE KEYS */;
INSERT INTO `engine4_album_categories` (`category_id`, `user_id`, `category_name`) VALUES (0,1,'All Categories'),(1,1,'Arts & Culture'),(2,1,'Business'),(3,1,'Entertainment'),(5,1,'Family & Home'),(6,1,'Health'),(7,1,'Recreation'),(8,1,'Personal'),(9,1,'Shopping'),(10,1,'Society'),(11,1,'Sports'),(12,1,'Technology'),(13,1,'Other');
/*!40000 ALTER TABLE `engine4_album_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_album_photos`
--

DROP TABLE IF EXISTS `engine4_album_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_album_photos` (
  `photo_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` int(11) unsigned NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `order` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `owner_id` int(11) unsigned NOT NULL,
  `file_id` int(11) unsigned NOT NULL,
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`photo_id`),
  KEY `album_id` (`album_id`),
  KEY `owner_type` (`owner_type`,`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_album_photos`
--

LOCK TABLES `engine4_album_photos` WRITE;
/*!40000 ALTER TABLE `engine4_album_photos` DISABLE KEYS */;
INSERT INTO `engine4_album_photos` (`photo_id`, `album_id`, `title`, `description`, `creation_date`, `modified_date`, `order`, `owner_type`, `owner_id`, `file_id`, `view_count`, `comment_count`) VALUES (1,1,'Profile Photo','Me at Crows Nest.','2014-10-23 23:40:56','2014-10-23 23:47:14',0,'user',1,5,0,0),(2,1,'Yunyi','Yunyi and his teddy.','2014-10-23 23:43:18','2014-10-23 23:47:14',2,'user',1,7,0,0),(3,1,'Ollie','Ollie Laying Down.','2014-10-23 23:43:22','2014-10-23 23:47:14',3,'user',1,9,0,0),(4,1,'Cat','Some cat.','2014-10-23 23:43:33','2014-10-23 23:47:14',4,'user',1,11,0,0),(5,1,'','','2014-10-23 23:43:43','2014-10-23 23:47:14',5,'user',1,13,0,0),(6,2,'','','2014-10-27 01:48:06','2014-10-27 01:48:07',0,'user',5,19,0,0),(7,3,'','','2014-10-28 02:26:58','2014-10-28 02:26:59',0,'user',4,25,0,0);
/*!40000 ALTER TABLE `engine4_album_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_announcement_announcements`
--

DROP TABLE IF EXISTS `engine4_announcement_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_announcement_announcements` (
  `announcement_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime DEFAULT NULL,
  `networks` text COLLATE utf8_unicode_ci,
  `member_levels` text COLLATE utf8_unicode_ci,
  `profile_types` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`announcement_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_announcement_announcements`
--

LOCK TABLES `engine4_announcement_announcements` WRITE;
/*!40000 ALTER TABLE `engine4_announcement_announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_announcement_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_authorization_allow`
--

DROP TABLE IF EXISTS `engine4_authorization_allow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_authorization_allow` (
  `resource_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `resource_id` int(11) unsigned NOT NULL,
  `action` varchar(16) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `role` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `role_id` int(11) unsigned NOT NULL DEFAULT '0',
  `value` tinyint(1) NOT NULL DEFAULT '0',
  `params` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`resource_type`,`resource_id`,`action`,`role`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_authorization_allow`
--

LOCK TABLES `engine4_authorization_allow` WRITE;
/*!40000 ALTER TABLE `engine4_authorization_allow` DISABLE KEYS */;
INSERT INTO `engine4_authorization_allow` (`resource_type`, `resource_id`, `action`, `role`, `role_id`, `value`, `params`) VALUES ('album',1,'comment','everyone',0,1,NULL),('album',1,'view','everyone',0,1,NULL),('album',2,'comment','everyone',0,1,NULL),('album',2,'view','everyone',0,1,NULL),('album',3,'comment','everyone',0,1,NULL),('album',3,'view','everyone',0,1,NULL),('album_photo',1,'comment','everyone',0,1,NULL),('album_photo',1,'view','everyone',0,1,NULL),('album_photo',6,'comment','everyone',0,1,NULL),('album_photo',6,'view','everyone',0,1,NULL),('album_photo',7,'comment','everyone',0,1,NULL),('album_photo',7,'view','everyone',0,1,NULL),('donation',1,'comment','everyone',0,1,NULL),('donation',1,'order','everyone',0,1,NULL),('donation',1,'view','everyone',0,1,NULL),('donation',1,'view','owner_member',0,1,NULL),('donation',1,'view','owner_member_member',0,1,NULL),('donation',1,'view','owner_network',0,1,NULL),('donation',1,'view','registered',0,1,NULL),('donation',2,'comment','everyone',0,1,NULL),('donation',2,'order','everyone',0,1,NULL),('donation',2,'view','everyone',0,1,NULL),('donation',2,'view','owner_member',0,1,NULL),('donation',2,'view','owner_member_member',0,1,NULL),('donation',2,'view','owner_network',0,1,NULL),('donation',2,'view','registered',0,1,NULL),('event',1,'comment','everyone',0,1,NULL),('event',1,'comment','member',0,1,NULL),('event',1,'comment','owner_member',0,1,NULL),('event',1,'comment','owner_member_member',0,1,NULL),('event',1,'comment','owner_network',0,1,NULL),('event',1,'comment','registered',0,1,NULL),('event',1,'invite','member',0,1,NULL),('event',1,'photo','everyone',0,1,NULL),('event',1,'photo','member',0,1,NULL),('event',1,'photo','owner_member',0,1,NULL),('event',1,'photo','owner_member_member',0,1,NULL),('event',1,'photo','owner_network',0,1,NULL),('event',1,'photo','registered',0,1,NULL),('event',1,'view','everyone',0,1,NULL),('event',1,'view','member',0,1,NULL),('event',1,'view','member_requested',0,1,NULL),('event',1,'view','owner_member',0,1,NULL),('event',1,'view','owner_member_member',0,1,NULL),('event',1,'view','owner_network',0,1,NULL),('event',1,'view','registered',0,1,NULL),('event',2,'comment','everyone',0,1,NULL),('event',2,'comment','member',0,1,NULL),('event',2,'comment','parent_member',0,1,NULL),('event',2,'comment','registered',0,1,NULL),('event',2,'invite','member',0,1,NULL),('event',2,'photo','everyone',0,1,NULL),('event',2,'photo','member',0,1,NULL),('event',2,'photo','parent_member',0,1,NULL),('event',2,'photo','registered',0,1,NULL),('event',2,'view','everyone',0,1,NULL),('event',2,'view','member',0,1,NULL),('event',2,'view','member_requested',0,1,NULL),('event',2,'view','parent_member',0,1,NULL),('event',2,'view','registered',0,1,NULL),('forum',1,'post.create','registered',0,1,NULL),('forum',1,'topic.create','registered',0,1,NULL),('forum',1,'topic.delete','forum_list',1,1,NULL),('forum',1,'topic.edit','forum_list',1,1,NULL),('forum',1,'view','everyone',0,1,NULL),('forum',2,'post.create','registered',0,1,NULL),('forum',2,'topic.create','registered',0,1,NULL),('forum',2,'topic.delete','forum_list',2,1,NULL),('forum',2,'topic.edit','forum_list',2,1,NULL),('forum',2,'view','everyone',0,1,NULL),('forum',3,'post.create','registered',0,1,NULL),('forum',3,'topic.create','registered',0,1,NULL),('forum',3,'topic.delete','forum_list',3,1,NULL),('forum',3,'topic.edit','forum_list',3,1,NULL),('forum',3,'view','everyone',0,1,NULL),('forum',4,'post.create','registered',0,1,NULL),('forum',4,'topic.create','registered',0,1,NULL),('forum',4,'topic.delete','forum_list',4,1,NULL),('forum',4,'topic.edit','forum_list',4,1,NULL),('forum',4,'view','everyone',0,1,NULL),('forum',5,'post.create','registered',0,1,NULL),('forum',5,'topic.create','registered',0,1,NULL),('forum',5,'topic.delete','forum_list',5,1,NULL),('forum',5,'topic.edit','forum_list',5,1,NULL),('forum',5,'view','everyone',0,1,NULL),('group',1,'comment','group_list',1,1,NULL),('group',1,'comment','member',0,1,NULL),('group',1,'comment','registered',0,1,NULL),('group',1,'event','group_list',1,1,NULL),('group',1,'event','member',0,1,NULL),('group',1,'event','registered',0,1,NULL),('group',1,'invite','group_list',1,1,NULL),('group',1,'invite','member',0,1,NULL),('group',1,'photo','group_list',1,1,NULL),('group',1,'photo','member',0,1,NULL),('group',1,'photo','registered',0,1,NULL),('group',1,'photo.edit','group_list',1,1,NULL),('group',1,'topic.edit','group_list',1,1,NULL),('group',1,'view','everyone',0,1,NULL),('group',1,'view','group_list',1,1,NULL),('group',1,'view','member',0,1,NULL),('group',1,'view','member_requested',0,1,NULL),('group',1,'view','registered',0,1,NULL),('user',1,'comment','everyone',0,1,NULL),('user',1,'comment','member',0,1,NULL),('user',1,'comment','network',0,1,NULL),('user',1,'comment','registered',0,1,NULL),('user',1,'interest','everyone',0,1,NULL),('user',1,'interest','owner_member',0,1,NULL),('user',1,'interest','owner_member_member',0,1,NULL),('user',1,'interest','owner_network',0,1,NULL),('user',1,'interest','registered',0,1,NULL),('user',1,'view','everyone',0,1,NULL),('user',1,'view','member',0,1,NULL),('user',1,'view','network',0,1,NULL),('user',1,'view','registered',0,1,NULL),('user',2,'comment','everyone',0,1,NULL),('user',2,'comment','member',0,1,NULL),('user',2,'comment','network',0,1,NULL),('user',2,'comment','registered',0,1,NULL),('user',2,'interest','everyone',0,1,NULL),('user',2,'interest','owner_member',0,1,NULL),('user',2,'interest','owner_member_member',0,1,NULL),('user',2,'interest','owner_network',0,1,NULL),('user',2,'interest','registered',0,1,NULL),('user',2,'view','everyone',0,1,NULL),('user',2,'view','member',0,1,NULL),('user',2,'view','network',0,1,NULL),('user',2,'view','registered',0,1,NULL),('user',3,'comment','everyone',0,1,NULL),('user',3,'comment','member',0,1,NULL),('user',3,'comment','network',0,1,NULL),('user',3,'comment','registered',0,1,NULL),('user',3,'interest','everyone',0,1,NULL),('user',3,'interest','owner_member',0,1,NULL),('user',3,'interest','owner_member_member',0,1,NULL),('user',3,'interest','owner_network',0,1,NULL),('user',3,'interest','registered',0,1,NULL),('user',3,'view','everyone',0,1,NULL),('user',3,'view','member',0,1,NULL),('user',3,'view','network',0,1,NULL),('user',3,'view','registered',0,1,NULL),('user',4,'comment','everyone',0,1,NULL),('user',4,'comment','member',0,1,NULL),('user',4,'comment','network',0,1,NULL),('user',4,'comment','registered',0,1,NULL),('user',4,'interest','everyone',0,1,NULL),('user',4,'interest','owner_member',0,1,NULL),('user',4,'interest','owner_member_member',0,1,NULL),('user',4,'interest','owner_network',0,1,NULL),('user',4,'interest','registered',0,1,NULL),('user',4,'view','everyone',0,1,NULL),('user',4,'view','member',0,1,NULL),('user',4,'view','network',0,1,NULL),('user',4,'view','registered',0,1,NULL),('user',5,'comment','everyone',0,1,NULL),('user',5,'comment','member',0,1,NULL),('user',5,'comment','network',0,1,NULL),('user',5,'comment','registered',0,1,NULL),('user',5,'interest','everyone',0,1,NULL),('user',5,'interest','owner_member',0,1,NULL),('user',5,'interest','owner_member_member',0,1,NULL),('user',5,'interest','owner_network',0,1,NULL),('user',5,'interest','registered',0,1,NULL),('user',5,'view','everyone',0,1,NULL),('user',5,'view','member',0,1,NULL),('user',5,'view','network',0,1,NULL),('user',5,'view','registered',0,1,NULL);
/*!40000 ALTER TABLE `engine4_authorization_allow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_authorization_levels`
--

DROP TABLE IF EXISTS `engine4_authorization_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_authorization_levels` (
  `level_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('public','user','moderator','admin') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'user',
  `flag` enum('default','superadmin','public') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`level_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_authorization_levels`
--

LOCK TABLES `engine4_authorization_levels` WRITE;
/*!40000 ALTER TABLE `engine4_authorization_levels` DISABLE KEYS */;
INSERT INTO `engine4_authorization_levels` (`level_id`, `title`, `description`, `type`, `flag`) VALUES (1,'Superadmins','Users of this level can modify all of your settings and data.  This level cannot be modified or deleted.','admin','superadmin'),(2,'Admins','Users of this level have full access to all of your network settings and data.','admin',''),(3,'Moderators','Users of this level may edit user-side content.','moderator',''),(4,'Default Level','This is the default user level.  New users are assigned to it automatically.','user','default'),(5,'Public','Settings for this level apply to users who have not logged in.','public','public');
/*!40000 ALTER TABLE `engine4_authorization_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_authorization_permissions`
--

DROP TABLE IF EXISTS `engine4_authorization_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_authorization_permissions` (
  `level_id` int(11) unsigned NOT NULL,
  `type` varchar(16) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `name` varchar(16) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `value` tinyint(3) NOT NULL DEFAULT '0',
  `params` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`level_id`,`type`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_authorization_permissions`
--

LOCK TABLES `engine4_authorization_permissions` WRITE;
/*!40000 ALTER TABLE `engine4_authorization_permissions` DISABLE KEYS */;
INSERT INTO `engine4_authorization_permissions` (`level_id`, `type`, `name`, `value`, `params`) VALUES (1,'admin','view',1,NULL),(1,'album','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'album','auth_tag',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'album','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'album','comment',2,NULL),(1,'album','create',1,NULL),(1,'album','delete',2,NULL),(1,'album','edit',2,NULL),(1,'album','tag',2,NULL),(1,'album','view',2,NULL),(1,'announcement','create',1,NULL),(1,'announcement','delete',2,NULL),(1,'announcement','edit',2,NULL),(1,'announcement','view',2,NULL),(1,'blog','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'blog','auth_html',3,'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(1,'blog','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'blog','comment',2,NULL),(1,'blog','create',1,NULL),(1,'blog','delete',2,NULL),(1,'blog','edit',2,NULL),(1,'blog','max',3,'1000'),(1,'blog','style',1,NULL),(1,'blog','view',2,NULL),(1,'chat','chat',1,NULL),(1,'chat','im',1,NULL),(1,'classified','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'classified','auth_html',3,'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(1,'classified','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'classified','comment',2,NULL),(1,'classified','create',1,NULL),(1,'classified','css',2,NULL),(1,'classified','delete',2,NULL),(1,'classified','edit',2,NULL),(1,'classified','max',3,'1000'),(1,'classified','photo',1,NULL),(1,'classified','style',2,NULL),(1,'classified','view',2,NULL),(1,'core_link','create',1,NULL),(1,'core_link','delete',2,NULL),(1,'core_link','view',2,NULL),(1,'donation','auth_comment',1,NULL),(1,'donation','auth_view',1,NULL),(1,'donation','comment',1,NULL),(1,'donation','create_charity',1,NULL),(1,'donation','create_project',1,NULL),(1,'donation','delete',1,NULL),(1,'donation','raise_money',1,NULL),(1,'event','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(1,'event','auth_photo',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(1,'event','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(1,'event','comment',2,NULL),(1,'event','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(1,'event','create',1,NULL),(1,'event','delete',2,NULL),(1,'event','edit',2,NULL),(1,'event','invite',1,NULL),(1,'event','photo',1,NULL),(1,'event','style',1,NULL),(1,'event','view',2,NULL),(1,'forum','comment',2,NULL),(1,'forum','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(1,'forum','create',2,NULL),(1,'forum','delete',2,NULL),(1,'forum','edit',2,NULL),(1,'forum','post.create',2,NULL),(1,'forum','post.delete',2,NULL),(1,'forum','post.edit',2,NULL),(1,'forum','topic.create',2,NULL),(1,'forum','topic.delete',2,NULL),(1,'forum','topic.edit',2,NULL),(1,'forum','view',2,NULL),(1,'forum_post','create',2,NULL),(1,'forum_post','delete',2,NULL),(1,'forum_post','edit',2,NULL),(1,'forum_topic','create',2,NULL),(1,'forum_topic','delete',2,NULL),(1,'forum_topic','edit',2,NULL),(1,'forum_topic','move',2,NULL),(1,'general','activity',2,NULL),(1,'general','style',2,NULL),(1,'group','auth_comment',5,'[\"registered\", \"member\", \"officer\"]'),(1,'group','auth_event',5,'[\"registered\", \"member\", \"officer\"]'),(1,'group','auth_photo',5,'[\"registered\", \"member\", \"officer\"]'),(1,'group','auth_view',5,'[\"everyone\", \"registered\", \"member\"]'),(1,'group','comment',2,NULL),(1,'group','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(1,'group','create',1,NULL),(1,'group','delete',2,NULL),(1,'group','edit',2,NULL),(1,'group','event',1,NULL),(1,'group','invite',1,NULL),(1,'group','photo',1,NULL),(1,'group','photo.edit',2,NULL),(1,'group','style',1,NULL),(1,'group','topic.edit',2,NULL),(1,'group','view',2,NULL),(1,'messages','auth',3,'friends'),(1,'messages','create',1,NULL),(1,'messages','editor',3,'plaintext'),(1,'music_playlist','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'music_playlist','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'music_playlist','comment',2,NULL),(1,'music_playlist','create',1,NULL),(1,'music_playlist','delete',2,NULL),(1,'music_playlist','edit',2,NULL),(1,'music_playlist','view',2,NULL),(1,'poll','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'poll','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'poll','comment',2,NULL),(1,'poll','create',1,NULL),(1,'poll','delete',2,NULL),(1,'poll','edit',2,NULL),(1,'poll','view',2,NULL),(1,'poll','vote',2,NULL),(1,'user','activity',1,NULL),(1,'user','auth_comment',5,'[\"everyone\",\"registered\",\"network\",\"member\",\"owner\"]'),(1,'user','auth_interest',5,'[\"everyone\", \"registered\", \"owner_network\", \"owner_member_member\", \"owner_member\", \"owner\"]'),(1,'user','auth_view',5,'[\"everyone\",\"registered\",\"network\",\"member\",\"owner\"]'),(1,'user','block',1,NULL),(1,'user','comment',2,NULL),(1,'user','create',1,NULL),(1,'user','delete',2,NULL),(1,'user','edit',2,NULL),(1,'user','interest',1,NULL),(1,'user','like_donation',1,NULL),(1,'user','like_event',1,NULL),(1,'user','like_group',1,NULL),(1,'user','like_offer',1,NULL),(1,'user','like_page',1,NULL),(1,'user','like_product',1,NULL),(1,'user','like_user',1,NULL),(1,'user','search',1,NULL),(1,'user','status',1,NULL),(1,'user','style',2,NULL),(1,'user','username',2,NULL),(1,'user','view',2,NULL),(1,'video','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'video','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(1,'video','comment',2,NULL),(1,'video','create',1,NULL),(1,'video','delete',2,NULL),(1,'video','edit',2,NULL),(1,'video','max',3,'20'),(1,'video','upload',1,NULL),(1,'video','view',2,NULL),(2,'admin','view',1,NULL),(2,'album','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'album','auth_tag',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'album','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'album','comment',2,NULL),(2,'album','create',1,NULL),(2,'album','delete',2,NULL),(2,'album','edit',2,NULL),(2,'album','tag',2,NULL),(2,'album','view',2,NULL),(2,'announcement','create',1,NULL),(2,'announcement','delete',2,NULL),(2,'announcement','edit',2,NULL),(2,'announcement','view',2,NULL),(2,'blog','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'blog','auth_html',3,'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(2,'blog','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'blog','comment',2,NULL),(2,'blog','create',1,NULL),(2,'blog','delete',2,NULL),(2,'blog','edit',2,NULL),(2,'blog','max',3,'1000'),(2,'blog','style',1,NULL),(2,'blog','view',2,NULL),(2,'chat','chat',1,NULL),(2,'chat','im',1,NULL),(2,'classified','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'classified','auth_html',3,'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(2,'classified','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'classified','comment',2,NULL),(2,'classified','create',1,NULL),(2,'classified','css',2,NULL),(2,'classified','delete',2,NULL),(2,'classified','edit',2,NULL),(2,'classified','max',3,'1000'),(2,'classified','photo',1,NULL),(2,'classified','style',2,NULL),(2,'classified','view',2,NULL),(2,'core_link','create',1,NULL),(2,'core_link','delete',2,NULL),(2,'core_link','view',2,NULL),(2,'donation','auth_comment',1,NULL),(2,'donation','auth_view',1,NULL),(2,'donation','comment',1,NULL),(2,'donation','create_charity',1,NULL),(2,'donation','create_project',1,NULL),(2,'donation','delete',1,NULL),(2,'donation','raise_money',1,NULL),(2,'event','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(2,'event','auth_photo',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(2,'event','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(2,'event','comment',2,NULL),(2,'event','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(2,'event','create',1,NULL),(2,'event','delete',2,NULL),(2,'event','edit',2,NULL),(2,'event','invite',1,NULL),(2,'event','photo',1,NULL),(2,'event','style',1,NULL),(2,'event','view',2,NULL),(2,'forum','comment',2,NULL),(2,'forum','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(2,'forum','create',2,NULL),(2,'forum','delete',2,NULL),(2,'forum','edit',2,NULL),(2,'forum','post.create',2,NULL),(2,'forum','post.delete',2,NULL),(2,'forum','post.edit',2,NULL),(2,'forum','topic.create',2,NULL),(2,'forum','topic.delete',2,NULL),(2,'forum','topic.edit',2,NULL),(2,'forum','view',2,NULL),(2,'forum_post','create',2,NULL),(2,'forum_post','delete',2,NULL),(2,'forum_post','edit',2,NULL),(2,'forum_topic','create',2,NULL),(2,'forum_topic','delete',2,NULL),(2,'forum_topic','edit',2,NULL),(2,'forum_topic','move',2,NULL),(2,'general','activity',2,NULL),(2,'general','style',2,NULL),(2,'group','auth_comment',5,'[\"registered\", \"member\", \"officer\"]'),(2,'group','auth_event',5,'[\"registered\", \"member\", \"officer\"]'),(2,'group','auth_photo',5,'[\"registered\", \"member\", \"officer\"]'),(2,'group','auth_view',5,'[\"everyone\", \"registered\", \"member\"]'),(2,'group','comment',2,NULL),(2,'group','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(2,'group','create',1,NULL),(2,'group','delete',2,NULL),(2,'group','edit',2,NULL),(2,'group','event',1,NULL),(2,'group','invite',1,NULL),(2,'group','photo',1,NULL),(2,'group','photo.edit',2,NULL),(2,'group','style',1,NULL),(2,'group','topic.edit',2,NULL),(2,'group','view',2,NULL),(2,'messages','auth',3,'friends'),(2,'messages','create',1,NULL),(2,'messages','editor',3,'plaintext'),(2,'music_playlist','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'music_playlist','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'music_playlist','comment',2,NULL),(2,'music_playlist','create',1,NULL),(2,'music_playlist','delete',2,NULL),(2,'music_playlist','edit',2,NULL),(2,'music_playlist','view',2,NULL),(2,'poll','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'poll','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'poll','comment',2,NULL),(2,'poll','create',1,NULL),(2,'poll','delete',2,NULL),(2,'poll','edit',2,NULL),(2,'poll','view',2,NULL),(2,'poll','vote',2,NULL),(2,'user','activity',1,NULL),(2,'user','auth_comment',5,'[\"everyone\",\"registered\",\"network\",\"member\",\"owner\"]'),(2,'user','auth_interest',5,'[\"everyone\", \"registered\", \"owner_network\", \"owner_member_member\", \"owner_member\", \"owner\"]'),(2,'user','auth_view',5,'[\"everyone\",\"registered\",\"network\",\"member\",\"owner\"]'),(2,'user','block',1,NULL),(2,'user','comment',2,NULL),(2,'user','create',1,NULL),(2,'user','delete',2,NULL),(2,'user','edit',2,NULL),(2,'user','interest',1,NULL),(2,'user','like_donation',1,NULL),(2,'user','like_event',1,NULL),(2,'user','like_group',1,NULL),(2,'user','like_offer',1,NULL),(2,'user','like_page',1,NULL),(2,'user','like_product',1,NULL),(2,'user','like_user',1,NULL),(2,'user','search',1,NULL),(2,'user','status',1,NULL),(2,'user','style',2,NULL),(2,'user','username',2,NULL),(2,'user','view',2,NULL),(2,'video','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'video','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(2,'video','comment',2,NULL),(2,'video','create',1,NULL),(2,'video','delete',2,NULL),(2,'video','edit',2,NULL),(2,'video','max',3,'20'),(2,'video','upload',1,NULL),(2,'video','view',2,NULL),(3,'album','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'album','auth_tag',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'album','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'album','comment',2,NULL),(3,'album','create',1,NULL),(3,'album','delete',2,NULL),(3,'album','edit',2,NULL),(3,'album','tag',2,NULL),(3,'album','view',2,NULL),(3,'announcement','view',1,NULL),(3,'blog','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'blog','auth_html',3,'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(3,'blog','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'blog','comment',2,NULL),(3,'blog','create',1,NULL),(3,'blog','delete',2,NULL),(3,'blog','edit',2,NULL),(3,'blog','max',3,'1000'),(3,'blog','style',1,NULL),(3,'blog','view',2,NULL),(3,'chat','chat',1,NULL),(3,'chat','im',1,NULL),(3,'classified','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'classified','auth_html',3,'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(3,'classified','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'classified','comment',2,NULL),(3,'classified','create',1,NULL),(3,'classified','css',2,NULL),(3,'classified','delete',2,NULL),(3,'classified','edit',2,NULL),(3,'classified','max',3,'1000'),(3,'classified','photo',1,NULL),(3,'classified','style',2,NULL),(3,'classified','view',2,NULL),(3,'core_link','create',1,NULL),(3,'core_link','delete',2,NULL),(3,'core_link','view',2,NULL),(3,'donation','auth_comment',1,NULL),(3,'donation','auth_view',1,NULL),(3,'donation','comment',1,NULL),(3,'donation','create_charity',1,NULL),(3,'donation','create_project',1,NULL),(3,'donation','raise_money',1,NULL),(3,'event','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(3,'event','auth_photo',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(3,'event','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(3,'event','comment',2,NULL),(3,'event','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(3,'event','create',1,NULL),(3,'event','delete',2,NULL),(3,'event','edit',2,NULL),(3,'event','invite',1,NULL),(3,'event','photo',1,NULL),(3,'event','style',1,NULL),(3,'event','view',2,NULL),(3,'forum','comment',2,NULL),(3,'forum','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(3,'forum','create',2,NULL),(3,'forum','delete',2,NULL),(3,'forum','edit',2,NULL),(3,'forum','post.create',2,NULL),(3,'forum','post.delete',2,NULL),(3,'forum','post.edit',2,NULL),(3,'forum','topic.create',2,NULL),(3,'forum','topic.delete',2,NULL),(3,'forum','topic.edit',2,NULL),(3,'forum','view',2,NULL),(3,'forum_post','create',2,NULL),(3,'forum_post','delete',2,NULL),(3,'forum_post','edit',2,NULL),(3,'forum_topic','create',2,NULL),(3,'forum_topic','delete',2,NULL),(3,'forum_topic','edit',2,NULL),(3,'forum_topic','move',2,NULL),(3,'general','activity',2,NULL),(3,'general','style',2,NULL),(3,'group','auth_comment',5,'[\"registered\", \"member\", \"officer\"]'),(3,'group','auth_event',5,'[\"registered\", \"member\", \"officer\"]'),(3,'group','auth_photo',5,'[\"registered\", \"member\", \"officer\"]'),(3,'group','auth_view',5,'[\"everyone\", \"registered\", \"member\"]'),(3,'group','comment',2,NULL),(3,'group','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(3,'group','create',1,NULL),(3,'group','delete',2,NULL),(3,'group','edit',2,NULL),(3,'group','event',1,NULL),(3,'group','invite',1,NULL),(3,'group','photo',1,NULL),(3,'group','photo.edit',2,NULL),(3,'group','style',1,NULL),(3,'group','topic.edit',2,NULL),(3,'group','view',2,NULL),(3,'messages','auth',3,'friends'),(3,'messages','create',1,NULL),(3,'messages','editor',3,'plaintext'),(3,'music_playlist','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'music_playlist','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'music_playlist','comment',2,NULL),(3,'music_playlist','create',1,NULL),(3,'music_playlist','delete',2,NULL),(3,'music_playlist','edit',2,NULL),(3,'music_playlist','view',2,NULL),(3,'poll','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'poll','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'poll','comment',2,NULL),(3,'poll','create',1,NULL),(3,'poll','delete',2,NULL),(3,'poll','edit',2,NULL),(3,'poll','view',2,NULL),(3,'poll','vote',2,NULL),(3,'user','activity',1,NULL),(3,'user','auth_comment',5,'[\"everyone\",\"registered\",\"network\",\"member\",\"owner\"]'),(3,'user','auth_interest',5,'[\"everyone\", \"registered\", \"owner_network\", \"owner_member_member\", \"owner_member\", \"owner\"]'),(3,'user','auth_view',5,'[\"everyone\",\"registered\",\"network\",\"member\",\"owner\"]'),(3,'user','block',1,NULL),(3,'user','comment',2,NULL),(3,'user','create',1,NULL),(3,'user','delete',2,NULL),(3,'user','edit',2,NULL),(3,'user','interest',1,NULL),(3,'user','like_donation',1,NULL),(3,'user','like_event',1,NULL),(3,'user','like_group',1,NULL),(3,'user','like_offer',1,NULL),(3,'user','like_page',1,NULL),(3,'user','like_product',1,NULL),(3,'user','like_user',1,NULL),(3,'user','search',1,NULL),(3,'user','status',1,NULL),(3,'user','style',2,NULL),(3,'user','username',2,NULL),(3,'user','view',2,NULL),(3,'video','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'video','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(3,'video','comment',2,NULL),(3,'video','create',1,NULL),(3,'video','delete',2,NULL),(3,'video','edit',2,NULL),(3,'video','max',3,'20'),(3,'video','upload',1,NULL),(3,'video','view',2,NULL),(4,'album','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'album','auth_tag',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'album','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'album','comment',1,NULL),(4,'album','create',1,NULL),(4,'album','delete',1,NULL),(4,'album','edit',1,NULL),(4,'album','tag',1,NULL),(4,'album','view',1,NULL),(4,'announcement','view',1,NULL),(4,'blog','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'blog','auth_html',3,'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(4,'blog','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'blog','comment',1,NULL),(4,'blog','create',1,NULL),(4,'blog','delete',1,NULL),(4,'blog','edit',1,NULL),(4,'blog','max',3,'50'),(4,'blog','style',1,NULL),(4,'blog','view',1,NULL),(4,'chat','chat',1,NULL),(4,'chat','im',1,NULL),(4,'classified','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'classified','auth_html',3,'strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(4,'classified','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'classified','comment',1,NULL),(4,'classified','create',1,NULL),(4,'classified','css',1,NULL),(4,'classified','delete',1,NULL),(4,'classified','edit',1,NULL),(4,'classified','max',3,'50'),(4,'classified','photo',1,NULL),(4,'classified','style',1,NULL),(4,'classified','view',1,NULL),(4,'core_link','create',1,NULL),(4,'core_link','delete',1,NULL),(4,'core_link','view',1,NULL),(4,'donation','auth_comment',1,NULL),(4,'donation','auth_view',1,NULL),(4,'donation','comment',1,NULL),(4,'donation','create_charity',1,NULL),(4,'donation','create_project',1,NULL),(4,'donation','raise_money',1,NULL),(4,'event','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(4,'event','auth_photo',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(4,'event','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"parent_member\",\"member\",\"owner\"]'),(4,'event','comment',1,NULL),(4,'event','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(4,'event','create',1,NULL),(4,'event','delete',1,NULL),(4,'event','edit',1,NULL),(4,'event','invite',1,NULL),(4,'event','photo',1,NULL),(4,'event','style',1,NULL),(4,'event','view',1,NULL),(4,'forum','comment',1,NULL),(4,'forum','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(4,'forum','post.create',2,NULL),(4,'forum','post.delete',1,NULL),(4,'forum','post.edit',1,NULL),(4,'forum','topic.create',1,NULL),(4,'forum','topic.delete',1,NULL),(4,'forum','topic.edit',1,NULL),(4,'forum','view',1,NULL),(4,'forum_post','create',1,NULL),(4,'forum_post','delete',1,NULL),(4,'forum_post','edit',1,NULL),(4,'forum_topic','create',1,NULL),(4,'forum_topic','delete',1,NULL),(4,'forum_topic','edit',1,NULL),(4,'general','style',1,NULL),(4,'group','auth_comment',5,'[\"registered\", \"member\", \"officer\"]'),(4,'group','auth_event',5,'[\"registered\", \"member\", \"officer\"]'),(4,'group','auth_photo',5,'[\"registered\", \"member\", \"officer\"]'),(4,'group','auth_view',5,'[\"everyone\", \"registered\", \"member\"]'),(4,'group','comment',1,NULL),(4,'group','commentHtml',3,'blockquote, strong, b, em, i, u, strike, sub, sup, p, div, pre, address, h1, h2, h3, h4, h5, h6, span, ol, li, ul, a, img, embed, br, hr'),(4,'group','create',1,NULL),(4,'group','delete',1,NULL),(4,'group','edit',1,NULL),(4,'group','event',1,NULL),(4,'group','invite',1,NULL),(4,'group','photo',1,NULL),(4,'group','photo.edit',1,NULL),(4,'group','style',1,NULL),(4,'group','topic.edit',1,NULL),(4,'group','view',1,NULL),(4,'messages','auth',3,'friends'),(4,'messages','create',1,NULL),(4,'messages','editor',3,'plaintext'),(4,'music_playlist','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'music_playlist','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'music_playlist','comment',1,NULL),(4,'music_playlist','create',1,NULL),(4,'music_playlist','delete',1,NULL),(4,'music_playlist','edit',1,NULL),(4,'music_playlist','view',1,NULL),(4,'poll','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'poll','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'poll','comment',1,NULL),(4,'poll','create',1,NULL),(4,'poll','delete',1,NULL),(4,'poll','edit',1,NULL),(4,'poll','view',1,NULL),(4,'poll','vote',1,NULL),(4,'user','auth_comment',5,'[\"everyone\",\"registered\",\"network\",\"member\",\"owner\"]'),(4,'user','auth_interest',5,'[\"everyone\", \"registered\", \"owner_network\", \"owner_member_member\", \"owner_member\", \"owner\"]'),(4,'user','auth_view',5,'[\"everyone\",\"registered\",\"network\",\"member\",\"owner\"]'),(4,'user','block',1,NULL),(4,'user','comment',1,NULL),(4,'user','create',1,NULL),(4,'user','delete',1,NULL),(4,'user','edit',1,NULL),(4,'user','interest',1,NULL),(4,'user','like_donation',1,NULL),(4,'user','like_event',1,NULL),(4,'user','like_group',1,NULL),(4,'user','like_offer',1,NULL),(4,'user','like_page',1,NULL),(4,'user','like_product',1,NULL),(4,'user','like_user',1,NULL),(4,'user','search',1,NULL),(4,'user','status',1,NULL),(4,'user','style',1,NULL),(4,'user','username',1,NULL),(4,'user','view',1,NULL),(4,'video','auth_comment',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'video','auth_view',5,'[\"everyone\",\"owner_network\",\"owner_member_member\",\"owner_member\",\"owner\"]'),(4,'video','comment',1,NULL),(4,'video','create',1,NULL),(4,'video','delete',1,NULL),(4,'video','edit',1,NULL),(4,'video','max',3,'20'),(4,'video','upload',1,NULL),(4,'video','view',1,NULL),(5,'album','tag',0,NULL),(5,'album','view',1,NULL),(5,'announcement','view',1,NULL),(5,'blog','view',1,NULL),(5,'classified','view',1,NULL),(5,'core_link','view',1,NULL),(5,'event','view',1,NULL),(5,'forum','view',1,NULL),(5,'group','view',1,NULL),(5,'music_playlist','view',1,NULL),(5,'poll','view',1,NULL),(5,'user','interest',1,NULL),(5,'user','view',1,''),(5,'video','view',1,NULL);
/*!40000 ALTER TABLE `engine4_authorization_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_blog_blogs`
--

DROP TABLE IF EXISTS `engine4_blog_blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_blog_blogs` (
  `blog_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8_unicode_ci NOT NULL,
  `owner_type` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `owner_id` int(11) unsigned NOT NULL,
  `category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `draft` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `owner_type` (`owner_type`,`owner_id`),
  KEY `search` (`search`,`creation_date`),
  KEY `owner_id` (`owner_id`,`draft`),
  KEY `draft` (`draft`,`search`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_blog_blogs`
--

LOCK TABLES `engine4_blog_blogs` WRITE;
/*!40000 ALTER TABLE `engine4_blog_blogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_blog_blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_blog_categories`
--

DROP TABLE IF EXISTS `engine4_blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_blog_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `category_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`category_id`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`,`category_name`),
  KEY `category_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_blog_categories`
--

LOCK TABLES `engine4_blog_categories` WRITE;
/*!40000 ALTER TABLE `engine4_blog_categories` DISABLE KEYS */;
INSERT INTO `engine4_blog_categories` (`category_id`, `user_id`, `category_name`) VALUES (1,1,'Arts & Culture'),(2,1,'Business'),(3,1,'Entertainment'),(5,1,'Family & Home'),(6,1,'Health'),(7,1,'Recreation'),(8,1,'Personal'),(9,1,'Shopping'),(10,1,'Society'),(11,1,'Sports'),(12,1,'Technology'),(13,1,'Other');
/*!40000 ALTER TABLE `engine4_blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_blog_subscriptions`
--

DROP TABLE IF EXISTS `engine4_blog_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_blog_subscriptions` (
  `subscription_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `subscriber_user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`subscription_id`),
  UNIQUE KEY `user_id` (`user_id`,`subscriber_user_id`),
  KEY `subscriber_user_id` (`subscriber_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_blog_subscriptions`
--

LOCK TABLES `engine4_blog_subscriptions` WRITE;
/*!40000 ALTER TABLE `engine4_blog_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_blog_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_chat_bans`
--

DROP TABLE IF EXISTS `engine4_chat_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_chat_bans` (
  `ban_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `room_id` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ban_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_chat_bans`
--

LOCK TABLES `engine4_chat_bans` WRITE;
/*!40000 ALTER TABLE `engine4_chat_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_chat_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_chat_events`
--

DROP TABLE IF EXISTS `engine4_chat_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_chat_events` (
  `event_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `type` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`event_id`),
  KEY `user_id` (`user_id`,`date`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_chat_events`
--

LOCK TABLES `engine4_chat_events` WRITE;
/*!40000 ALTER TABLE `engine4_chat_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_chat_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_chat_messages`
--

DROP TABLE IF EXISTS `engine4_chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_chat_messages` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0',
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `room_id` (`room_id`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_chat_messages`
--

LOCK TABLES `engine4_chat_messages` WRITE;
/*!40000 ALTER TABLE `engine4_chat_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_chat_rooms`
--

DROP TABLE IF EXISTS `engine4_chat_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_chat_rooms` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_count` smallint(6) NOT NULL,
  `modified_date` datetime NOT NULL,
  `public` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`room_id`),
  KEY `public` (`public`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_chat_rooms`
--

LOCK TABLES `engine4_chat_rooms` WRITE;
/*!40000 ALTER TABLE `engine4_chat_rooms` DISABLE KEYS */;
INSERT INTO `engine4_chat_rooms` (`room_id`, `title`, `user_count`, `modified_date`, `public`) VALUES (1,'General Chat',0,'2010-02-02 00:44:04',1),(2,'Introduce Yourself',0,'2010-02-02 00:44:04',1);
/*!40000 ALTER TABLE `engine4_chat_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_chat_roomusers`
--

DROP TABLE IF EXISTS `engine4_chat_roomusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_chat_roomusers` (
  `room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL,
  PRIMARY KEY (`room_id`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `date` (`date`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_chat_roomusers`
--

LOCK TABLES `engine4_chat_roomusers` WRITE;
/*!40000 ALTER TABLE `engine4_chat_roomusers` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_chat_roomusers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_chat_users`
--

DROP TABLE IF EXISTS `engine4_chat_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_chat_users` (
  `user_id` int(11) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL,
  `event_count` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  KEY `date` (`date`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_chat_users`
--

LOCK TABLES `engine4_chat_users` WRITE;
/*!40000 ALTER TABLE `engine4_chat_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_chat_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_chat_whispers`
--

DROP TABLE IF EXISTS `engine4_chat_whispers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_chat_whispers` (
  `whisper_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `recipient_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `recipient_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `sender_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`whisper_id`),
  KEY `recipient_id` (`recipient_id`),
  KEY `sender_id` (`sender_id`),
  KEY `recipient_deleted` (`recipient_deleted`,`sender_deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_chat_whispers`
--

LOCK TABLES `engine4_chat_whispers` WRITE;
/*!40000 ALTER TABLE `engine4_chat_whispers` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_chat_whispers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_classified_albums`
--

DROP TABLE IF EXISTS `engine4_classified_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_classified_albums` (
  `album_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `classified_id` int(11) unsigned NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `photo_id` int(11) unsigned NOT NULL DEFAULT '0',
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  `collectible_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`album_id`),
  KEY `classified_id` (`classified_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_classified_albums`
--

LOCK TABLES `engine4_classified_albums` WRITE;
/*!40000 ALTER TABLE `engine4_classified_albums` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_classified_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_classified_categories`
--

DROP TABLE IF EXISTS `engine4_classified_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_classified_categories` (
  `category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `category_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`category_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_classified_categories`
--

LOCK TABLES `engine4_classified_categories` WRITE;
/*!40000 ALTER TABLE `engine4_classified_categories` DISABLE KEYS */;
INSERT INTO `engine4_classified_categories` (`category_id`, `user_id`, `category_name`) VALUES (1,1,'Arts & Culture'),(2,1,'Business'),(3,1,'Entertainment'),(5,1,'Family & Home'),(6,1,'Health'),(7,1,'Recreation'),(8,1,'Personal'),(9,1,'Shopping'),(10,1,'Society'),(11,1,'Sports'),(12,1,'Technology'),(13,1,'Other');
/*!40000 ALTER TABLE `engine4_classified_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_classified_classifieds`
--

DROP TABLE IF EXISTS `engine4_classified_classifieds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_classified_classifieds` (
  `classified_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8_unicode_ci NOT NULL,
  `owner_id` int(11) unsigned NOT NULL,
  `category_id` int(11) unsigned NOT NULL,
  `photo_id` int(10) unsigned NOT NULL DEFAULT '0',
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`classified_id`),
  KEY `owner_id` (`owner_id`),
  KEY `search` (`search`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_classified_classifieds`
--

LOCK TABLES `engine4_classified_classifieds` WRITE;
/*!40000 ALTER TABLE `engine4_classified_classifieds` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_classified_classifieds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_classified_fields_maps`
--

DROP TABLE IF EXISTS `engine4_classified_fields_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_classified_fields_maps` (
  `field_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL,
  `order` smallint(6) NOT NULL,
  PRIMARY KEY (`field_id`,`option_id`,`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_classified_fields_maps`
--

LOCK TABLES `engine4_classified_fields_maps` WRITE;
/*!40000 ALTER TABLE `engine4_classified_fields_maps` DISABLE KEYS */;
INSERT INTO `engine4_classified_fields_maps` (`field_id`, `option_id`, `child_id`, `order`) VALUES (0,0,2,2),(0,0,3,3);
/*!40000 ALTER TABLE `engine4_classified_fields_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_classified_fields_meta`
--

DROP TABLE IF EXISTS `engine4_classified_fields_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_classified_fields_meta` (
  `field_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `label` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `display` tinyint(1) unsigned NOT NULL,
  `search` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `order` smallint(3) unsigned NOT NULL DEFAULT '999',
  `config` text COLLATE utf8_unicode_ci NOT NULL,
  `validators` text COLLATE utf8_unicode_ci,
  `filters` text COLLATE utf8_unicode_ci,
  `style` text COLLATE utf8_unicode_ci,
  `error` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`field_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_classified_fields_meta`
--

LOCK TABLES `engine4_classified_fields_meta` WRITE;
/*!40000 ALTER TABLE `engine4_classified_fields_meta` DISABLE KEYS */;
INSERT INTO `engine4_classified_fields_meta` (`field_id`, `type`, `label`, `description`, `alias`, `required`, `display`, `search`, `show`, `order`, `config`, `validators`, `filters`, `style`, `error`) VALUES (2,'currency','Price','','price',0,1,1,1,999,'{\"unit\":\"USD\"}',NULL,NULL,NULL,NULL),(3,'location','Location','','location',0,1,1,1,999,'',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `engine4_classified_fields_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_classified_fields_options`
--

DROP TABLE IF EXISTS `engine4_classified_fields_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_classified_fields_options` (
  `option_id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `label` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order` smallint(6) NOT NULL DEFAULT '999',
  PRIMARY KEY (`option_id`),
  KEY `field_id` (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_classified_fields_options`
--

LOCK TABLES `engine4_classified_fields_options` WRITE;
/*!40000 ALTER TABLE `engine4_classified_fields_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_classified_fields_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_classified_fields_search`
--

DROP TABLE IF EXISTS `engine4_classified_fields_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_classified_fields_search` (
  `item_id` int(11) NOT NULL,
  `price` double DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `price` (`price`),
  KEY `location` (`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_classified_fields_search`
--

LOCK TABLES `engine4_classified_fields_search` WRITE;
/*!40000 ALTER TABLE `engine4_classified_fields_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_classified_fields_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_classified_fields_values`
--

DROP TABLE IF EXISTS `engine4_classified_fields_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_classified_fields_values` (
  `item_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `index` smallint(3) NOT NULL DEFAULT '0',
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`item_id`,`field_id`,`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_classified_fields_values`
--

LOCK TABLES `engine4_classified_fields_values` WRITE;
/*!40000 ALTER TABLE `engine4_classified_fields_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_classified_fields_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_classified_photos`
--

DROP TABLE IF EXISTS `engine4_classified_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_classified_photos` (
  `photo_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` int(11) unsigned NOT NULL,
  `classified_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `collection_id` int(11) unsigned NOT NULL,
  `file_id` int(11) unsigned NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`photo_id`),
  KEY `album_id` (`album_id`),
  KEY `classified_id` (`classified_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_classified_photos`
--

LOCK TABLES `engine4_classified_photos` WRITE;
/*!40000 ALTER TABLE `engine4_classified_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_classified_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_adcampaigns`
--

DROP TABLE IF EXISTS `engine4_core_adcampaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_adcampaigns` (
  `adcampaign_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `end_settings` tinyint(4) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `limit_view` int(11) unsigned NOT NULL DEFAULT '0',
  `limit_click` int(11) unsigned NOT NULL DEFAULT '0',
  `limit_ctr` varchar(11) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `network` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `level` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `views` int(11) unsigned NOT NULL DEFAULT '0',
  `clicks` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`adcampaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_adcampaigns`
--

LOCK TABLES `engine4_core_adcampaigns` WRITE;
/*!40000 ALTER TABLE `engine4_core_adcampaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_adcampaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_adphotos`
--

DROP TABLE IF EXISTS `engine4_core_adphotos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_adphotos` (
  `adphoto_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ad_id` int(11) unsigned NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_id` int(11) unsigned NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`adphoto_id`),
  KEY `ad_id` (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_adphotos`
--

LOCK TABLES `engine4_core_adphotos` WRITE;
/*!40000 ALTER TABLE `engine4_core_adphotos` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_adphotos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_ads`
--

DROP TABLE IF EXISTS `engine4_core_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_ads` (
  `ad_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `ad_campaign` int(11) unsigned NOT NULL,
  `views` int(11) unsigned NOT NULL DEFAULT '0',
  `clicks` int(11) unsigned NOT NULL DEFAULT '0',
  `media_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `html_code` text COLLATE utf8_unicode_ci NOT NULL,
  `photo_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ad_id`),
  KEY `ad_campaign` (`ad_campaign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_ads`
--

LOCK TABLES `engine4_core_ads` WRITE;
/*!40000 ALTER TABLE `engine4_core_ads` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_ads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_auth`
--

DROP TABLE IF EXISTS `engine4_core_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_auth` (
  `id` varchar(40) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `expires` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`user_id`),
  KEY `expires` (`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_auth`
--

LOCK TABLES `engine4_core_auth` WRITE;
/*!40000 ALTER TABLE `engine4_core_auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_bannedemails`
--

DROP TABLE IF EXISTS `engine4_core_bannedemails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_bannedemails` (
  `bannedemail_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`bannedemail_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_bannedemails`
--

LOCK TABLES `engine4_core_bannedemails` WRITE;
/*!40000 ALTER TABLE `engine4_core_bannedemails` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_bannedemails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_bannedips`
--

DROP TABLE IF EXISTS `engine4_core_bannedips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_bannedips` (
  `bannedip_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `start` varbinary(16) NOT NULL,
  `stop` varbinary(16) NOT NULL,
  PRIMARY KEY (`bannedip_id`),
  UNIQUE KEY `start` (`start`,`stop`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_bannedips`
--

LOCK TABLES `engine4_core_bannedips` WRITE;
/*!40000 ALTER TABLE `engine4_core_bannedips` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_bannedips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_bannedusernames`
--

DROP TABLE IF EXISTS `engine4_core_bannedusernames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_bannedusernames` (
  `bannedusername_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`bannedusername_id`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_bannedusernames`
--

LOCK TABLES `engine4_core_bannedusernames` WRITE;
/*!40000 ALTER TABLE `engine4_core_bannedusernames` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_bannedusernames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_bannedwords`
--

DROP TABLE IF EXISTS `engine4_core_bannedwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_bannedwords` (
  `bannedword_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`bannedword_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_bannedwords`
--

LOCK TABLES `engine4_core_bannedwords` WRITE;
/*!40000 ALTER TABLE `engine4_core_bannedwords` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_bannedwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_comments`
--

DROP TABLE IF EXISTS `engine4_core_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_comments` (
  `comment_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `resource_type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `resource_id` int(11) unsigned NOT NULL,
  `poster_type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `poster_id` int(11) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `like_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`),
  KEY `resource_type` (`resource_type`,`resource_id`),
  KEY `poster_type` (`poster_type`,`poster_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_comments`
--

LOCK TABLES `engine4_core_comments` WRITE;
/*!40000 ALTER TABLE `engine4_core_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_content`
--

DROP TABLE IF EXISTS `engine4_core_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_content` (
  `content_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(11) unsigned NOT NULL,
  `type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'widget',
  `name` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `parent_content_id` int(11) unsigned DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT '1',
  `params` text COLLATE utf8_unicode_ci,
  `attribs` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`content_id`),
  KEY `page_id` (`page_id`,`order`)
) ENGINE=InnoDB AUTO_INCREMENT=1070 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_content`
--

LOCK TABLES `engine4_core_content` WRITE;
/*!40000 ALTER TABLE `engine4_core_content` DISABLE KEYS */;
INSERT INTO `engine4_core_content` (`content_id`, `page_id`, `type`, `name`, `parent_content_id`, `order`, `params`, `attribs`) VALUES (100,1,'container','main',NULL,2,'[\"\"]',NULL),(200,2,'container','main',NULL,2,'[\"\"]',NULL),(300,3,'container','main',NULL,2,'[\"\"]',NULL),(312,3,'container','middle',300,6,'[\"\"]',NULL),(400,4,'container','main',NULL,2,'[\"\"]',NULL),(410,4,'container','left',400,4,'[\"\"]',NULL),(412,4,'container','middle',400,6,'[\"\"]',NULL),(500,5,'container','main',NULL,2,'[\"\"]',NULL),(510,5,'container','left',500,4,'[\"\"]',NULL),(511,5,'container','middle',500,6,'[\"\"]',NULL),(522,5,'widget','user.profile-friends-common',510,4,'{\"title\":\"Mutual Friends\"}',NULL),(523,5,'widget','user.profile-info',510,5,'{\"title\":\"Member Info\"}',NULL),(530,5,'widget','user.profile-status',511,8,'[\"\"]',NULL),(531,5,'widget','core.container-tabs',511,9,'{\"max\":\"6\"}',NULL),(540,5,'widget','activity.feed',531,10,'{\"title\":\"Updates\"}',NULL),(541,5,'widget','user.profile-fields',531,11,'{\"title\":\"Info\"}',NULL),(542,5,'widget','user.profile-friends',531,12,'{\"title\":\"Friends\",\"titleCount\":true}',NULL),(546,5,'widget','core.profile-links',531,16,'{\"title\":\"Links\",\"titleCount\":true}',NULL),(547,6,'container','main',NULL,1,NULL,NULL),(548,6,'container','middle',547,2,NULL,NULL),(549,6,'widget','core.content',548,1,NULL,NULL),(550,7,'container','main',NULL,1,NULL,NULL),(551,7,'container','middle',550,2,NULL,NULL),(552,7,'widget','core.content',551,1,NULL,NULL),(553,8,'container','main',NULL,1,NULL,NULL),(554,8,'container','middle',553,2,NULL,NULL),(555,8,'widget','core.content',554,1,NULL,NULL),(556,9,'container','main',NULL,1,NULL,NULL),(557,9,'container','middle',556,1,NULL,NULL),(558,9,'widget','core.content',557,1,NULL,NULL),(559,10,'container','main',NULL,1,NULL,NULL),(560,10,'container','middle',559,1,NULL,NULL),(561,10,'widget','core.content',560,1,NULL,NULL),(562,11,'container','main',NULL,1,NULL,NULL),(563,11,'container','middle',562,1,NULL,NULL),(564,11,'widget','core.content',563,1,NULL,NULL),(565,12,'container','main',NULL,1,NULL,NULL),(566,12,'container','middle',565,1,NULL,NULL),(567,12,'widget','core.content',566,1,NULL,NULL),(568,13,'container','main',NULL,1,NULL,NULL),(569,13,'container','middle',568,1,NULL,NULL),(570,13,'widget','core.content',569,1,NULL,NULL),(571,14,'container','top',NULL,1,NULL,NULL),(572,14,'container','main',NULL,2,NULL,NULL),(573,14,'container','middle',571,1,NULL,NULL),(574,14,'container','middle',572,2,NULL,NULL),(575,14,'widget','user.settings-menu',573,1,NULL,NULL),(576,14,'widget','core.content',574,1,NULL,NULL),(577,15,'container','top',NULL,1,NULL,NULL),(578,15,'container','main',NULL,2,NULL,NULL),(579,15,'container','middle',577,1,NULL,NULL),(580,15,'container','middle',578,2,NULL,NULL),(581,15,'widget','user.settings-menu',579,1,NULL,NULL),(582,15,'widget','core.content',580,1,NULL,NULL),(583,16,'container','top',NULL,1,NULL,NULL),(584,16,'container','main',NULL,2,NULL,NULL),(585,16,'container','middle',583,1,NULL,NULL),(586,16,'container','middle',584,2,NULL,NULL),(587,16,'widget','user.settings-menu',585,1,NULL,NULL),(588,16,'widget','core.content',586,1,NULL,NULL),(589,17,'container','top',NULL,1,NULL,NULL),(590,17,'container','main',NULL,2,NULL,NULL),(591,17,'container','middle',589,1,NULL,NULL),(592,17,'container','middle',590,2,NULL,NULL),(593,17,'widget','user.settings-menu',591,1,NULL,NULL),(594,17,'widget','core.content',592,1,NULL,NULL),(595,18,'container','top',NULL,1,NULL,NULL),(596,18,'container','main',NULL,2,NULL,NULL),(597,18,'container','middle',595,1,NULL,NULL),(598,18,'container','middle',596,2,NULL,NULL),(599,18,'widget','user.settings-menu',597,1,NULL,NULL),(600,18,'widget','core.content',598,1,NULL,NULL),(601,19,'container','top',NULL,1,NULL,NULL),(602,19,'container','main',NULL,2,NULL,NULL),(603,19,'container','middle',601,1,NULL,NULL),(604,19,'container','middle',602,2,NULL,NULL),(605,19,'widget','user.settings-menu',603,1,NULL,NULL),(606,19,'widget','core.content',604,1,NULL,NULL),(607,20,'container','main',NULL,1,NULL,NULL),(608,20,'container','middle',607,2,NULL,NULL),(609,20,'widget','core.content',608,1,NULL,NULL),(610,20,'widget','core.comments',608,2,NULL,NULL),(611,21,'container','main',NULL,1,NULL,NULL),(612,21,'container','middle',611,2,NULL,NULL),(613,21,'widget','core.content',612,1,NULL,NULL),(614,21,'widget','core.comments',612,2,NULL,NULL),(615,22,'container','top',NULL,1,NULL,NULL),(616,22,'container','main',NULL,2,NULL,NULL),(617,22,'container','middle',615,1,NULL,NULL),(618,22,'container','middle',616,2,NULL,NULL),(619,22,'container','right',616,1,NULL,NULL),(620,22,'widget','album.browse-menu',617,1,NULL,NULL),(621,22,'widget','core.content',618,1,NULL,NULL),(622,22,'widget','album.browse-search',619,1,NULL,NULL),(623,22,'widget','album.browse-menu-quick',619,2,NULL,NULL),(624,5,'widget','album.profile-albums',531,13,'{\"title\":\"Albums\",\"titleCount\":true}',NULL),(625,23,'container','top',NULL,1,NULL,NULL),(626,23,'container','main',NULL,2,NULL,NULL),(627,23,'container','middle',625,1,NULL,NULL),(628,23,'container','middle',626,2,NULL,NULL),(629,23,'widget','album.browse-menu',627,1,NULL,NULL),(630,23,'widget','core.content',628,1,NULL,NULL),(631,24,'container','top',NULL,1,NULL,NULL),(632,24,'container','main',NULL,2,NULL,NULL),(633,24,'container','middle',631,1,NULL,NULL),(634,24,'container','middle',632,2,NULL,NULL),(635,24,'container','right',632,1,NULL,NULL),(636,24,'widget','album.browse-menu',633,1,NULL,NULL),(637,24,'widget','core.content',634,1,NULL,NULL),(638,24,'widget','album.browse-search',635,1,NULL,NULL),(639,24,'widget','album.browse-menu-quick',635,2,NULL,NULL),(640,5,'widget','blog.profile-blogs',531,14,'{\"title\":\"Blogs\",\"titleCount\":true}',NULL),(641,25,'container','main',NULL,1,NULL,NULL),(642,25,'container','left',641,1,NULL,NULL),(643,25,'container','middle',641,2,NULL,NULL),(644,25,'widget','blog.gutter-photo',642,1,NULL,NULL),(645,25,'widget','blog.gutter-menu',642,2,NULL,NULL),(646,25,'widget','blog.gutter-search',642,3,NULL,NULL),(647,25,'widget','core.content',643,1,NULL,NULL),(648,26,'container','main',NULL,1,NULL,NULL),(649,26,'container','left',648,1,NULL,NULL),(650,26,'container','middle',648,2,NULL,NULL),(651,26,'widget','blog.gutter-photo',649,1,NULL,NULL),(652,26,'widget','blog.gutter-menu',649,2,NULL,NULL),(653,26,'widget','blog.gutter-search',649,3,NULL,NULL),(654,26,'widget','core.content',650,1,NULL,NULL),(655,26,'widget','core.comments',650,2,NULL,NULL),(656,27,'container','top',NULL,1,NULL,NULL),(657,27,'container','main',NULL,2,NULL,NULL),(658,27,'container','middle',656,1,NULL,NULL),(659,27,'container','middle',657,2,NULL,NULL),(660,27,'container','right',657,1,NULL,NULL),(661,27,'widget','blog.browse-menu',658,1,NULL,NULL),(662,27,'widget','core.content',659,1,NULL,NULL),(663,27,'widget','blog.browse-search',660,1,NULL,NULL),(664,27,'widget','blog.browse-menu-quick',660,2,NULL,NULL),(665,28,'container','top',NULL,1,NULL,NULL),(666,28,'container','main',NULL,2,NULL,NULL),(667,28,'container','middle',665,1,NULL,NULL),(668,28,'container','middle',666,2,NULL,NULL),(669,28,'widget','blog.browse-menu',667,1,NULL,NULL),(670,28,'widget','core.content',668,1,NULL,NULL),(671,29,'container','top',NULL,1,NULL,NULL),(672,29,'container','main',NULL,2,NULL,NULL),(673,29,'container','middle',671,1,NULL,NULL),(674,29,'container','middle',672,2,NULL,NULL),(675,29,'container','right',672,1,NULL,NULL),(676,29,'widget','blog.browse-menu',673,1,NULL,NULL),(677,29,'widget','core.content',674,1,NULL,NULL),(678,29,'widget','blog.browse-search',675,1,NULL,NULL),(679,29,'widget','blog.browse-menu-quick',675,2,NULL,NULL),(680,30,'container','main',0,1,'',NULL),(681,30,'container','middle',680,3,'',NULL),(682,30,'widget','core.content',681,1,'',NULL),(683,5,'widget','classified.profile-classifieds',531,15,'{\"title\":\"Classifieds\",\"titleCount\":true}',NULL),(684,31,'container','top',NULL,1,NULL,NULL),(685,31,'container','main',NULL,2,NULL,NULL),(686,31,'container','middle',684,1,NULL,NULL),(687,31,'container','middle',685,2,NULL,NULL),(688,31,'container','right',685,1,NULL,NULL),(689,31,'widget','classified.browse-menu',686,1,NULL,NULL),(690,31,'widget','core.content',687,1,NULL,NULL),(691,31,'widget','classified.browse-search',688,1,NULL,NULL),(692,31,'widget','classified.browse-menu-quick',688,2,NULL,NULL),(693,32,'container','main',0,1,'',NULL),(694,32,'container','middle',693,3,'',NULL),(695,32,'widget','core.content',694,1,'',NULL),(696,32,'widget','core.comments',694,2,'',NULL),(697,33,'container','top',NULL,1,NULL,NULL),(698,33,'container','main',NULL,2,NULL,NULL),(699,33,'container','middle',697,1,NULL,NULL),(700,33,'container','middle',698,2,NULL,NULL),(701,33,'widget','classified.browse-menu',699,1,NULL,NULL),(702,33,'widget','core.content',700,1,NULL,NULL),(703,34,'container','top',NULL,1,NULL,NULL),(704,34,'container','main',NULL,2,NULL,NULL),(705,34,'container','middle',703,1,NULL,NULL),(706,34,'container','middle',704,2,NULL,NULL),(707,34,'container','right',704,1,NULL,NULL),(708,34,'widget','classified.browse-menu',705,1,NULL,NULL),(709,34,'widget','core.content',706,1,NULL,NULL),(710,34,'widget','classified.browse-search',707,1,NULL,NULL),(711,34,'widget','classified.browse-menu-quick',707,2,NULL,NULL),(712,35,'container','main',0,1,'',NULL),(713,35,'container','middle',712,2,'',NULL),(714,35,'widget','event.profile-status',713,3,'',NULL),(715,35,'widget','event.profile-photo',713,4,'',NULL),(716,35,'widget','event.profile-info',713,5,'',NULL),(717,35,'widget','event.profile-rsvp',713,6,'',NULL),(718,35,'widget','core.container-tabs',713,7,'{\"max\":6}',NULL),(719,35,'widget','activity.feed',718,8,'{\"title\":\"What\'s New\"}',NULL),(720,35,'widget','event.profile-members',718,9,'{\"title\":\"Guests\",\"titleCount\":true}',NULL),(721,36,'container','main',0,1,'',NULL),(722,36,'container','middle',721,3,'',NULL),(723,36,'container','left',721,1,'',NULL),(724,36,'widget','core.container-tabs',722,2,'{\"max\":\"6\"}',NULL),(725,36,'widget','event.profile-status',722,1,'',NULL),(726,36,'widget','event.profile-photo',723,1,'',NULL),(727,36,'widget','event.profile-options',723,2,'',NULL),(728,36,'widget','event.profile-info',723,3,'',NULL),(729,36,'widget','event.profile-rsvp',723,4,'',NULL),(730,36,'widget','activity.feed',724,1,'{\"title\":\"Updates\"}',NULL),(731,36,'widget','event.profile-members',724,2,'{\"title\":\"Guests\",\"titleCount\":true}',NULL),(732,36,'widget','event.profile-photos',724,3,'{\"title\":\"Photos\",\"titleCount\":true}',NULL),(733,36,'widget','event.profile-discussions',724,4,'{\"title\":\"Discussions\",\"titleCount\":true}',NULL),(734,36,'widget','core.profile-links',724,5,'{\"title\":\"Links\",\"titleCount\":true}',NULL),(736,5,'widget','event.profile-events',531,17,'{\"title\":\"Events\",\"titleCount\":true}',NULL),(737,37,'container','top',NULL,1,NULL,NULL),(738,37,'container','main',NULL,2,NULL,NULL),(739,37,'container','middle',737,1,NULL,NULL),(740,37,'container','middle',738,2,NULL,NULL),(741,37,'container','right',738,1,NULL,NULL),(742,37,'widget','event.browse-menu',739,1,NULL,NULL),(743,37,'widget','core.content',740,1,NULL,NULL),(744,37,'widget','event.browse-search',741,1,NULL,NULL),(745,37,'widget','event.browse-menu-quick',741,2,NULL,NULL),(746,38,'container','top',NULL,1,NULL,NULL),(747,38,'container','main',NULL,2,NULL,NULL),(748,38,'container','middle',746,1,NULL,NULL),(749,38,'container','middle',747,2,NULL,NULL),(750,38,'widget','event.browse-menu',748,1,NULL,NULL),(751,38,'widget','core.content',749,1,NULL,NULL),(752,39,'container','top',NULL,1,NULL,NULL),(753,39,'container','main',NULL,2,NULL,NULL),(754,39,'container','middle',752,1,NULL,NULL),(755,39,'container','middle',753,2,NULL,NULL),(756,39,'container','right',753,1,NULL,NULL),(757,39,'widget','event.browse-menu',754,1,NULL,NULL),(758,39,'widget','core.content',755,1,NULL,NULL),(759,39,'widget','event.browse-search',756,1,NULL,NULL),(760,39,'widget','event.browse-menu-quick',756,2,NULL,NULL),(761,5,'widget','forum.profile-forum-posts',531,18,'{\"title\":\"Forum Posts\",\"titleCount\":true}',NULL),(762,40,'container','main',NULL,1,NULL,NULL),(763,40,'container','middle',762,1,NULL,NULL),(764,40,'widget','core.content',763,1,NULL,NULL),(765,41,'container','main',NULL,1,NULL,NULL),(766,41,'container','middle',765,1,NULL,NULL),(767,41,'widget','core.content',766,1,NULL,NULL),(768,42,'container','main',NULL,1,NULL,NULL),(769,42,'container','middle',768,1,NULL,NULL),(770,42,'widget','core.content',769,1,NULL,NULL),(771,5,'widget','group.profile-groups',531,19,'{\"title\":\"Groups\",\"titleCount\":true}',NULL),(772,43,'container','main',0,1,'',NULL),(773,43,'container','middle',772,3,'',NULL),(774,43,'container','left',772,1,'',NULL),(775,43,'widget','core.container-tabs',773,2,'{\"max\":\"6\"}',NULL),(776,43,'widget','group.profile-status',773,1,'',NULL),(777,43,'widget','group.profile-photo',774,1,'',NULL),(778,43,'widget','group.profile-options',774,2,'',NULL),(779,43,'widget','group.profile-info',774,3,'',NULL),(780,43,'widget','activity.feed',775,1,'{\"title\":\"Updates\"}',NULL),(781,43,'widget','group.profile-members',775,2,'{\"title\":\"Members\",\"titleCount\":true}',NULL),(782,43,'widget','group.profile-photos',775,3,'{\"title\":\"Photos\",\"titleCount\":true}',NULL),(783,43,'widget','group.profile-discussions',775,4,'{\"title\":\"Discussions\",\"titleCount\":true}',NULL),(784,43,'widget','core.profile-links',775,5,'{\"title\":\"Links\",\"titleCount\":true}',NULL),(785,43,'widget','group.profile-events',775,6,'{\"title\":\"Events\",\"titleCount\":true}',NULL),(786,44,'container','main',0,1,'',NULL),(787,44,'container','middle',786,2,'',NULL),(788,44,'widget','group.profile-status',787,3,'',NULL),(789,44,'widget','group.profile-photo',787,4,'',NULL),(790,44,'widget','group.profile-info',787,5,'',NULL),(791,44,'widget','core.container-tabs',787,6,'{\"max\":6}',NULL),(792,44,'widget','activity.feed',791,7,'{\"title\":\"What\'s New\"}',NULL),(793,44,'widget','group.profile-members',791,8,'{\"title\":\"Members\",\"titleCount\":true}',NULL),(794,45,'container','top',NULL,1,NULL,NULL),(795,45,'container','main',NULL,2,NULL,NULL),(796,45,'container','middle',794,1,NULL,NULL),(797,45,'container','middle',795,2,NULL,NULL),(798,45,'container','right',795,1,NULL,NULL),(799,45,'widget','group.browse-menu',796,1,NULL,NULL),(800,45,'widget','core.content',797,1,NULL,NULL),(801,45,'widget','group.browse-search',798,1,NULL,NULL),(802,45,'widget','group.browse-menu-quick',798,2,NULL,NULL),(803,46,'container','top',NULL,1,NULL,NULL),(804,46,'container','main',NULL,2,NULL,NULL),(805,46,'container','middle',803,1,NULL,NULL),(806,46,'container','middle',804,2,NULL,NULL),(807,46,'widget','group.browse-menu',805,1,NULL,NULL),(808,46,'widget','core.content',806,1,NULL,NULL),(809,47,'container','top',NULL,1,NULL,NULL),(810,47,'container','main',NULL,2,NULL,NULL),(811,47,'container','middle',809,1,NULL,NULL),(812,47,'container','middle',810,2,NULL,NULL),(813,47,'container','right',810,1,NULL,NULL),(814,47,'widget','group.browse-menu',811,1,NULL,NULL),(815,47,'widget','core.content',812,1,NULL,NULL),(816,47,'widget','group.browse-search',813,1,NULL,NULL),(817,47,'widget','group.browse-menu-quick',813,2,NULL,NULL),(818,48,'container','main',NULL,1,NULL,NULL),(819,48,'container','middle',818,1,NULL,NULL),(820,48,'widget','core.content',819,1,NULL,NULL),(821,49,'container','main',NULL,1,NULL,NULL),(822,49,'container','middle',821,1,NULL,NULL),(823,49,'widget','core.content',822,2,NULL,NULL),(824,49,'widget','messages.menu',822,1,NULL,NULL),(825,50,'container','main',NULL,1,NULL,NULL),(826,50,'container','middle',825,1,NULL,NULL),(827,50,'widget','core.content',826,2,NULL,NULL),(828,50,'widget','messages.menu',826,1,NULL,NULL),(829,51,'container','main',NULL,1,NULL,NULL),(830,51,'container','middle',829,1,NULL,NULL),(831,51,'widget','core.content',830,2,NULL,NULL),(832,51,'widget','messages.menu',830,1,NULL,NULL),(833,52,'container','main',NULL,1,NULL,NULL),(834,52,'container','middle',833,1,NULL,NULL),(835,52,'widget','core.content',834,2,NULL,NULL),(836,52,'widget','messages.menu',834,1,NULL,NULL),(837,53,'container','main',NULL,1,NULL,NULL),(838,53,'container','middle',837,1,NULL,NULL),(839,53,'widget','core.content',838,2,NULL,NULL),(840,53,'widget','messages.menu',838,1,NULL,NULL),(841,54,'container','main',0,1,'',NULL),(842,54,'widget','core.menu-logo',841,2,'',NULL),(843,54,'widget','mobi.mobi-menu-main',841,3,'',NULL),(844,55,'container','main',0,1,'',NULL),(845,55,'widget','mobi.mobi-footer',844,2,'',NULL),(846,56,'container','main',0,1,'',NULL),(847,56,'container','middle',846,2,'',NULL),(848,56,'widget','user.login-or-signup',847,3,'',NULL),(849,57,'container','main',0,1,'',NULL),(850,57,'container','middle',849,2,'',NULL),(851,57,'widget','activity.feed',850,3,'',NULL),(852,58,'container','main',0,1,'',NULL),(853,58,'container','middle',852,2,'',NULL),(854,58,'widget','user.profile-photo',853,3,'',NULL),(855,58,'widget','user.profile-status',853,4,'',NULL),(856,58,'widget','mobi.mobi-profile-options',853,5,'',NULL),(857,58,'widget','core.container-tabs',853,6,'{\"max\":6}',NULL),(858,58,'widget','activity.feed',857,7,'{\"title\":\"What\'s New\"}',NULL),(859,58,'widget','user.profile-fields',857,8,'{\"title\":\"Info\"}',NULL),(860,58,'widget','user.profile-friends',857,9,'{\"title\":\"Friends\",\"titleCount\":true}',NULL),(861,5,'widget','music.profile-music',531,20,'{\"title\":\"Music\",\"titleCount\":true}',NULL),(862,5,'widget','music.profile-player',510,6,'[\"\"]',NULL),(863,59,'container','top',NULL,1,NULL,NULL),(864,59,'container','main',NULL,2,NULL,NULL),(865,59,'container','middle',863,1,NULL,NULL),(866,59,'container','middle',864,2,NULL,NULL),(867,59,'container','right',864,1,NULL,NULL),(868,59,'widget','music.browse-menu',865,1,NULL,NULL),(869,59,'widget','core.content',866,1,NULL,NULL),(870,59,'widget','music.browse-search',867,1,NULL,NULL),(871,59,'widget','music.browse-menu-quick',867,2,NULL,NULL),(872,60,'container','main',NULL,1,NULL,NULL),(873,60,'container','middle',872,1,NULL,NULL),(874,60,'widget','core.content',873,1,NULL,NULL),(875,60,'widget','core.comments',873,2,NULL,NULL),(876,61,'container','top',NULL,1,NULL,NULL),(877,61,'container','main',NULL,2,NULL,NULL),(878,61,'container','middle',876,1,NULL,NULL),(879,61,'container','middle',877,2,NULL,NULL),(880,61,'widget','music.browse-menu',878,1,NULL,NULL),(881,61,'widget','core.content',879,1,NULL,NULL),(882,62,'container','top',NULL,1,NULL,NULL),(883,62,'container','main',NULL,2,NULL,NULL),(884,62,'container','middle',882,1,NULL,NULL),(885,62,'container','middle',883,2,NULL,NULL),(886,62,'container','right',883,1,NULL,NULL),(887,62,'widget','music.browse-menu',884,1,NULL,NULL),(888,62,'widget','core.content',885,1,NULL,NULL),(889,62,'widget','music.browse-search',886,1,NULL,NULL),(890,62,'widget','music.browse-menu-quick',886,2,NULL,NULL),(891,5,'widget','poll.profile-polls',531,21,'{\"title\":\"Polls\",\"titleCount\":true}',NULL),(892,63,'container','top',NULL,1,NULL,NULL),(893,63,'container','main',NULL,2,NULL,NULL),(894,63,'container','middle',892,1,NULL,NULL),(895,63,'container','middle',893,2,NULL,NULL),(896,63,'container','right',893,1,NULL,NULL),(897,63,'widget','poll.browse-menu',894,1,NULL,NULL),(898,63,'widget','core.content',895,1,NULL,NULL),(899,63,'widget','poll.browse-search',896,1,NULL,NULL),(900,63,'widget','poll.browse-menu-quick',896,2,NULL,NULL),(901,64,'container','main',0,1,'',NULL),(902,64,'container','middle',901,3,'',NULL),(903,64,'widget','core.content',902,1,'',NULL),(904,64,'widget','core.comments',902,2,'',NULL),(905,65,'container','top',NULL,1,NULL,NULL),(906,65,'container','main',NULL,2,NULL,NULL),(907,65,'container','middle',905,1,NULL,NULL),(908,65,'container','middle',906,2,NULL,NULL),(909,65,'widget','poll.browse-menu',907,1,NULL,NULL),(910,65,'widget','core.content',908,1,NULL,NULL),(911,66,'container','top',NULL,1,NULL,NULL),(912,66,'container','main',NULL,2,NULL,NULL),(913,66,'container','middle',911,1,NULL,NULL),(914,66,'container','middle',912,2,NULL,NULL),(915,66,'container','right',912,1,NULL,NULL),(916,66,'widget','poll.browse-menu',913,1,NULL,NULL),(917,66,'widget','core.content',914,1,NULL,NULL),(918,66,'widget','poll.browse-search',915,1,NULL,NULL),(919,66,'widget','poll.browse-menu-quick',915,2,NULL,NULL),(920,5,'widget','video.profile-videos',531,22,'{\"title\":\"Videos\",\"titleCount\":true}',NULL),(921,67,'container','main',0,1,'',NULL),(922,67,'container','right',921,1,'',NULL),(923,67,'container','middle',921,3,'',NULL),(924,67,'widget','core.content',923,1,'',NULL),(925,67,'widget','core.comments',923,2,'',NULL),(926,67,'widget','video.show-same-tags',922,1,'',NULL),(927,67,'widget','video.show-also-liked',922,2,'',NULL),(928,67,'widget','video.show-same-poster',922,3,'',NULL),(929,68,'container','top',NULL,1,NULL,NULL),(930,68,'container','main',NULL,2,NULL,NULL),(931,68,'container','middle',929,1,NULL,NULL),(932,68,'container','middle',930,2,NULL,NULL),(933,68,'container','right',930,1,NULL,NULL),(934,68,'widget','video.browse-menu',931,1,NULL,NULL),(935,68,'widget','core.content',932,1,NULL,NULL),(936,68,'widget','video.browse-search',933,1,NULL,NULL),(937,68,'widget','video.browse-menu-quick',933,2,NULL,NULL),(938,69,'container','top',NULL,1,NULL,NULL),(939,69,'container','main',NULL,2,NULL,NULL),(940,69,'container','middle',938,1,NULL,NULL),(941,69,'container','middle',939,2,NULL,NULL),(942,69,'widget','video.browse-menu',940,1,NULL,NULL),(943,69,'widget','core.content',941,1,NULL,NULL),(944,70,'container','top',NULL,1,NULL,NULL),(945,70,'container','main',NULL,2,NULL,NULL),(946,70,'container','middle',944,1,NULL,NULL),(947,70,'container','middle',945,2,NULL,NULL),(948,70,'container','right',945,1,NULL,NULL),(949,70,'widget','video.browse-menu',946,1,NULL,NULL),(950,70,'widget','core.content',947,1,NULL,NULL),(951,70,'widget','video.browse-search',948,1,NULL,NULL),(952,70,'widget','video.browse-menu-quick',948,2,NULL,NULL),(963,2,'widget','zephyrtheme.footer-menu',200,2,'{\"title\":null,\"nomobile\":null,\"name\":\"zephyrtheme.footer-menu\"}',NULL),(966,5,'widget','zephyrtheme.profile-photomenu',510,3,'{\"title\":null,\"nomobile\":null,\"mpmShowphoto\":\"1\",\"mpmShowmenu\":\"1\",\"name\":\"zephyrtheme.profile-photomenu\"}',NULL),(986,4,'widget','zephyrtheme.member-photomenu',410,3,'{\"title\":null,\"nomobile\":null,\"mpmShowheadline\":\"1\",\"mpmShowphoto\":\"1\",\"mpmShowmenu\":\"1\",\"name\":\"zephyrtheme.member-photomenu\"}',NULL),(987,4,'widget','user.profile-friends',410,4,'{\"title\":\"Friends\",\"titleCount\":true}',NULL),(988,4,'widget','core.comments',412,6,'{\"title\":\"Comments\"}',NULL),(989,4,'widget','activity.feed',412,7,'{\"title\":\"What\'s New\"}',NULL),(990,4,'container','right',400,5,'[\"[]\"]',NULL),(992,4,'widget','activity.list-requests',990,9,'{\"title\":\"Requests\"}',NULL),(993,4,'widget','announcement.list-announcements',990,10,'{\"title\":\"Announcements\"}',NULL),(997,1,'widget','zephyrtheme.header-menu',100,2,'[]',NULL),(1009,3,'widget','zephyrtheme.home',312,3,'[\"[]\"]',NULL),(1010,72,'container','top',NULL,1,'[\"[]\"]',NULL),(1011,72,'container','main',NULL,2,'[\"[]\"]',NULL),(1012,72,'container','middle',1010,6,'[\"[]\"]',NULL),(1013,72,'container','right',1011,5,'[\"[]\"]',NULL),(1014,72,'container','middle',1011,6,'[\"[]\"]',NULL),(1015,72,'widget','donation.browse-menu',1012,3,'[\"[]\"]',NULL),(1016,72,'widget','core.content',1014,6,'[\"[]\"]',NULL),(1017,72,'widget','donation.donation-search',1013,8,'[\"[]\"]',NULL),(1018,72,'widget','donation.browse-menu-charity-quick',1013,9,'[]',NULL),(1019,73,'container','main',NULL,2,'[\"[]\"]',NULL),(1020,73,'container','middle',1019,6,'[\"[]\"]',NULL),(1021,73,'container','right',1019,5,'[\"[]\"]',NULL),(1022,73,'widget','core.container-tabs',1020,6,'{\"max\":6}',NULL),(1023,73,'widget','donation.profile-status',1021,12,'[\"[]\"]',NULL),(1024,73,'widget','donation.profile-options',1021,13,'[\"[]\"]',NULL),(1025,73,'widget','donation.profile-map',1021,14,'[\"[]\"]',NULL),(1026,73,'widget','donation.profile-supporters',1021,15,'[\"[]\"]',NULL),(1027,73,'widget','donation.profile-photo',1020,3,'[\"[]\"]',NULL),(1028,73,'widget','like.donation-status',1020,4,'[\"[]\"]',NULL),(1029,73,'widget','donation.profile-description',1020,5,'[\"[]\"]',NULL),(1030,73,'widget','donation.profile-photos',1022,8,'{\"title\":\"Photos\",\"titleCount\":true}',NULL),(1031,73,'widget','core.comments',1022,7,'{\"title\":\"Comments\"}',NULL),(1032,73,'widget','donation.profile-fundraisers',1020,9,'{\"titleCount\":true}',NULL),(1033,73,'widget','donation.profile-donations',1020,10,'{\"titleCount\":true}',NULL),(1034,74,'container','main',NULL,2,'[\"[]\"]',NULL),(1035,74,'container','middle',1034,6,'[\"[]\"]',NULL),(1036,74,'widget','core.content',1035,3,'[]',NULL),(1037,74,'container','right',1034,5,'[\"[]\"]',NULL),(1038,75,'container','main',NULL,2,'[\"[]\"]',NULL),(1039,75,'container','top',NULL,1,'[\"[]\"]',NULL),(1040,75,'container','middle',1038,6,'[\"[]\"]',NULL),(1041,75,'container','right',1038,5,'[\"[]\"]',NULL),(1042,75,'container','middle',1039,6,'[\"[]\"]',NULL),(1043,75,'widget','core.content',1040,6,'[\"[]\"]',NULL),(1044,75,'widget','donation.browse-menu',1042,3,'[\"[]\"]',NULL),(1045,75,'widget','donation.donation-search',1041,8,'[\"[]\"]',NULL),(1046,75,'widget','donation.browse-menu-project-quick',1041,9,'[]',NULL),(1047,76,'container','top',NULL,1,'[]',NULL),(1048,76,'container','main',NULL,2,'[\"[]\"]',NULL),(1049,76,'container','right',1048,5,'[]',NULL),(1050,76,'container','middle',1048,6,'[\"[]\"]',NULL),(1051,76,'container','middle',1047,6,'[]',NULL),(1052,76,'widget','donation.browse-menu',1051,3,'[]',NULL),(1053,76,'widget','core.content',1050,6,'[]',NULL),(1054,76,'widget','donation.donation-search',1049,8,'[]',NULL),(1055,77,'container','main',NULL,2,'[\"[]\"]',''),(1056,77,'container','right',1055,5,'[\"[]\"]',NULL),(1057,77,'container','middle',1055,6,'[\"[]\"]',''),(1058,77,'widget','core.container-tabs',1057,7,'{\"max\":6}',NULL),(1059,77,'widget','donation.profile-photo',1057,3,'[\"[]\"]',NULL),(1060,77,'widget','like.donation-status',1057,4,'[\"[]\"]',NULL),(1061,77,'widget','donation.parent-donation',1057,5,'[\"[]\"]',NULL),(1062,77,'widget','donation.profile-description',1057,6,'[\"[]\"]',NULL),(1063,77,'widget','core.comments',1058,8,'{\"title\":\"Comments\"}',NULL),(1064,77,'widget','donation.profile-photos',1058,9,'{\"title\":\"Photos\",\"titleCount\":true}',NULL),(1065,77,'widget','donation.profile-donations',1057,10,'{\"titleCount\":true}',NULL),(1066,77,'widget','donation.profile-status',1056,12,'[\"[]\"]',NULL),(1067,77,'widget','donation.profile-options',1056,13,'[\"[]\"]',NULL),(1068,77,'widget','donation.profile-supporters',1056,14,'[\"[]\"]',NULL),(1069,0,'widget','donation.top-donors',4,17,'{\"title\":\"Top Donors\"}',NULL);
/*!40000 ALTER TABLE `engine4_core_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_geotags`
--

DROP TABLE IF EXISTS `engine4_core_geotags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_geotags` (
  `geotag_id` int(11) unsigned NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  PRIMARY KEY (`geotag_id`),
  KEY `latitude` (`latitude`,`longitude`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_geotags`
--

LOCK TABLES `engine4_core_geotags` WRITE;
/*!40000 ALTER TABLE `engine4_core_geotags` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_geotags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_jobs`
--

DROP TABLE IF EXISTS `engine4_core_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_jobs` (
  `job_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `jobtype_id` int(10) unsigned NOT NULL,
  `state` enum('pending','active','sleeping','failed','cancelled','completed','timeout') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pending',
  `is_complete` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `progress` decimal(5,4) unsigned NOT NULL DEFAULT '0.0000',
  `creation_date` datetime NOT NULL,
  `modified_date` datetime DEFAULT NULL,
  `started_date` datetime DEFAULT NULL,
  `completion_date` datetime DEFAULT NULL,
  `priority` mediumint(9) NOT NULL DEFAULT '100',
  `data` text COLLATE utf8_unicode_ci,
  `messages` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`job_id`),
  KEY `jobtype_id` (`jobtype_id`),
  KEY `state` (`state`),
  KEY `is_complete` (`is_complete`,`priority`,`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_jobs`
--

LOCK TABLES `engine4_core_jobs` WRITE;
/*!40000 ALTER TABLE `engine4_core_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_jobtypes`
--

DROP TABLE IF EXISTS `engine4_core_jobtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_jobtypes` (
  `jobtype_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `module` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `plugin` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `form` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `priority` mediumint(9) NOT NULL DEFAULT '100',
  `multi` tinyint(3) unsigned DEFAULT '1',
  PRIMARY KEY (`jobtype_id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_jobtypes`
--

LOCK TABLES `engine4_core_jobtypes` WRITE;
/*!40000 ALTER TABLE `engine4_core_jobtypes` DISABLE KEYS */;
INSERT INTO `engine4_core_jobtypes` (`jobtype_id`, `title`, `type`, `module`, `plugin`, `form`, `enabled`, `priority`, `multi`) VALUES (1,'Download File','file_download','core','Core_Plugin_Job_FileDownload','Core_Form_Admin_Job_FileDownload',1,100,1),(2,'Upload File','file_upload','core','Core_Plugin_Job_FileUpload','Core_Form_Admin_Job_FileUpload',1,100,1),(3,'Rebuild Activity Privacy','activity_maintenance_rebuild_privacy','activity','Activity_Plugin_Job_Maintenance_RebuildPrivacy',NULL,1,50,1),(4,'Rebuild Member Privacy','user_maintenance_rebuild_privacy','user','User_Plugin_Job_Maintenance_RebuildPrivacy',NULL,1,50,1),(5,'Rebuild Network Membership','network_maintenance_rebuild_membership','network','Network_Plugin_Job_Maintenance_RebuildMembership',NULL,1,50,1),(6,'Storage Transfer','storage_transfer','core','Storage_Plugin_Job_Transfer','Core_Form_Admin_Job_Generic',1,100,1),(7,'Storage Cleanup','storage_cleanup','core','Storage_Plugin_Job_Cleanup','Core_Form_Admin_Job_Generic',1,100,1),(8,'Rebuild Album Privacy','album_maintenance_rebuild_privacy','album','Album_Plugin_Job_Maintenance_RebuildPrivacy',NULL,1,50,1),(9,'Rebuild Blog Privacy','blog_maintenance_rebuild_privacy','blog','Blog_Plugin_Job_Maintenance_RebuildPrivacy',NULL,1,50,1),(10,'Rebuild Classified Privacy','classified_maintenance_rebuild_privacy','classified','Classified_Plugin_Job_Maintenance_RebuildPrivacy',NULL,1,50,1),(11,'Rebuild Event Privacy','event_maintenance_rebuild_privacy','event','Event_Plugin_Job_Maintenance_RebuildPrivacy',NULL,1,50,1),(12,'Rebuild Group Privacy','group_maintenance_rebuild_privacy','group','Group_Plugin_Job_Maintenance_RebuildPrivacy',NULL,1,50,1),(13,'Rebuild Music Privacy','music_maintenance_rebuild_privacy','music','Music_Plugin_Job_Maintenance_RebuildPrivacy',NULL,1,50,1),(14,'Rebuild Poll Privacy','poll_maintenance_rebuild_privacy','poll','Poll_Plugin_Job_Maintenance_RebuildPrivacy',NULL,1,50,1),(15,'Video Encode','video_encode','video','Video_Plugin_Job_Encode',NULL,1,75,2),(16,'Rebuild Video Privacy','video_maintenance_rebuild_privacy','video','Video_Plugin_Job_Maintenance_RebuildPrivacy',NULL,1,50,1);
/*!40000 ALTER TABLE `engine4_core_jobtypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_languages`
--

DROP TABLE IF EXISTS `engine4_core_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_languages` (
  `language_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(8) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fallback` varchar(8) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `order` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_languages`
--

LOCK TABLES `engine4_core_languages` WRITE;
/*!40000 ALTER TABLE `engine4_core_languages` DISABLE KEYS */;
INSERT INTO `engine4_core_languages` (`language_id`, `code`, `name`, `fallback`, `order`) VALUES (1,'en','English','en',1);
/*!40000 ALTER TABLE `engine4_core_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_likes`
--

DROP TABLE IF EXISTS `engine4_core_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_likes` (
  `like_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `resource_type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `resource_id` int(11) unsigned NOT NULL,
  `poster_type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `poster_id` int(11) unsigned NOT NULL,
  `creation_date` datetime NOT NULL,
  PRIMARY KEY (`like_id`),
  KEY `resource_type` (`resource_type`,`resource_id`),
  KEY `poster_type` (`poster_type`,`poster_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_likes`
--

LOCK TABLES `engine4_core_likes` WRITE;
/*!40000 ALTER TABLE `engine4_core_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_links`
--

DROP TABLE IF EXISTS `engine4_core_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_links` (
  `link_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `photo_id` int(11) unsigned NOT NULL DEFAULT '0',
  `parent_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `parent_id` int(11) unsigned NOT NULL,
  `owner_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `owner_id` int(11) unsigned NOT NULL,
  `view_count` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `creation_date` datetime NOT NULL,
  `search` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`link_id`),
  KEY `owner` (`owner_type`,`owner_id`),
  KEY `parent` (`parent_type`,`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_links`
--

LOCK TABLES `engine4_core_links` WRITE;
/*!40000 ALTER TABLE `engine4_core_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_listitems`
--

DROP TABLE IF EXISTS `engine4_core_listitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_listitems` (
  `listitem_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `list_id` int(11) unsigned NOT NULL,
  `child_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`listitem_id`),
  KEY `list_id` (`list_id`),
  KEY `child_id` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_listitems`
--

LOCK TABLES `engine4_core_listitems` WRITE;
/*!40000 ALTER TABLE `engine4_core_listitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_listitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_lists`
--

DROP TABLE IF EXISTS `engine4_core_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_lists` (
  `list_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `owner_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `owner_id` int(11) unsigned NOT NULL,
  `child_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `child_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`list_id`),
  KEY `owner_type` (`owner_type`,`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_lists`
--

LOCK TABLES `engine4_core_lists` WRITE;
/*!40000 ALTER TABLE `engine4_core_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_log`
--

DROP TABLE IF EXISTS `engine4_core_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_log` (
  `message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `plugin` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timestamp` datetime NOT NULL,
  `message` longtext COLLATE utf8_unicode_ci NOT NULL,
  `priority` smallint(2) NOT NULL DEFAULT '6',
  `priorityName` varchar(16) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'INFO',
  PRIMARY KEY (`message_id`),
  KEY `domain` (`domain`,`timestamp`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_log`
--

LOCK TABLES `engine4_core_log` WRITE;
/*!40000 ALTER TABLE `engine4_core_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_mail`
--

DROP TABLE IF EXISTS `engine4_core_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_mail` (
  `mail_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('system','zend') CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `body` longtext COLLATE utf8_unicode_ci NOT NULL,
  `priority` smallint(3) DEFAULT '100',
  `recipient_count` int(11) unsigned DEFAULT '0',
  `recipient_total` int(10) NOT NULL DEFAULT '0',
  `creation_time` datetime NOT NULL,
  PRIMARY KEY (`mail_id`),
  KEY `priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_mail`
--

LOCK TABLES `engine4_core_mail` WRITE;
/*!40000 ALTER TABLE `engine4_core_mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_mailrecipients`
--

DROP TABLE IF EXISTS `engine4_core_mailrecipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_mailrecipients` (
  `recipient_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mail_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `email` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`recipient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_mailrecipients`
--

LOCK TABLES `engine4_core_mailrecipients` WRITE;
/*!40000 ALTER TABLE `engine4_core_mailrecipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_mailrecipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_mailtemplates`
--

DROP TABLE IF EXISTS `engine4_core_mailtemplates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_mailtemplates` (
  `mailtemplate_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `module` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vars` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`mailtemplate_id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_mailtemplates`
--

LOCK TABLES `engine4_core_mailtemplates` WRITE;
/*!40000 ALTER TABLE `engine4_core_mailtemplates` DISABLE KEYS */;
INSERT INTO `engine4_core_mailtemplates` (`mailtemplate_id`, `type`, `module`, `vars`) VALUES (1,'header','core',''),(2,'footer','core',''),(3,'header_member','core',''),(4,'footer_member','core',''),(5,'core_contact','core','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_name],[sender_email],[sender_link],[sender_photo],[message]'),(6,'core_verification','core','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[object_link]'),(7,'core_verification_password','core','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[object_link],[password]'),(8,'core_welcome','core','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[object_link]'),(9,'core_welcome_password','core','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[object_link],[password]'),(10,'notify_admin_user_signup','core','[host],[email],[date],[recipient_title],[object_title],[object_link]'),(11,'core_lostpassword','core','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[object_link]'),(12,'notify_commented','activity','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(13,'notify_commented_commented','activity','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(14,'notify_liked','activity','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(15,'notify_liked_commented','activity','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(16,'user_account_approved','user','[host],[email],[recipient_title],[recipient_link],[recipient_photo]'),(17,'notify_friend_accepted','user','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(18,'notify_friend_request','user','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(19,'notify_friend_follow_request','user','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(20,'notify_friend_follow_accepted','user','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(21,'notify_friend_follow','user','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(22,'notify_post_user','user','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(23,'notify_tagged','user','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(24,'notify_message_new','messages','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(25,'invite','invite','[host],[email],[sender_email],[sender_title],[sender_link],[sender_photo],[message],[object_link],[code]'),(26,'invite_code','invite','[host],[email],[sender_email],[sender_title],[sender_link],[sender_photo],[message],[object_link],[code]'),(27,'payment_subscription_active','payment','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]'),(28,'payment_subscription_cancelled','payment','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]'),(29,'payment_subscription_expired','payment','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]'),(30,'payment_subscription_overdue','payment','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]'),(31,'payment_subscription_pending','payment','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]'),(32,'payment_subscription_recurrence','payment','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]'),(33,'payment_subscription_refunded','payment','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[subscription_title],[subscription_description],[object_link]'),(34,'notify_blog_subscribed_new','blog','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(35,'notify_event_accepted','event','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(36,'notify_event_approve','event','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(37,'notify_event_discussion_response','event','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(38,'notify_event_discussion_reply','event','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(39,'notify_event_invite','event','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(40,'notify_forum_topic_reply','forum','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(41,'notify_forum_topic_response','forum','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(42,'notify_forum_promote','forum','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(43,'notify_group_accepted','group','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(44,'notify_group_approve','group','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(45,'notify_group_discussion_reply','group','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(46,'notify_group_discussion_response','group','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(47,'notify_group_invite','group','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(48,'notify_group_promote','group','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(49,'notify_video_processed','video','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(50,'notify_video_processed_failed','video','[host],[email],[recipient_title],[recipient_link],[recipient_photo],[sender_title],[sender_link],[sender_photo],[object_title],[object_link],[object_photo],[object_description]'),(51,'like_suggest_page','like','[user],[link]'),(52,'like_suggest_user','like','[user],[link]'),(53,'donation_expired','donation','[donation],[owner_name]'),(54,'donation_fundraise_expired','donation','[fundraise],[owner_name]'),(55,'donation_child_fundraise_expired','donation','[child_fundraise],[owner_name]'),(56,'donation_target','donation','[donation],[owner_name]'),(57,'donation_fundraise_target','donation','[fundraise],[owner_name]'),(58,'donation_child_fundraise_target','donation','[child_fundraise],[owner_name]');
/*!40000 ALTER TABLE `engine4_core_mailtemplates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_menuitems`
--

DROP TABLE IF EXISTS `engine4_core_menuitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_menuitems` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `module` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `label` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `plugin` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  `menu` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `submenu` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `custom` tinyint(1) NOT NULL DEFAULT '0',
  `order` smallint(6) NOT NULL DEFAULT '999',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `LOOKUP` (`name`,`order`)
) ENGINE=InnoDB AUTO_INCREMENT=299 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_menuitems`
--

LOCK TABLES `engine4_core_menuitems` WRITE;
/*!40000 ALTER TABLE `engine4_core_menuitems` DISABLE KEYS */;
INSERT INTO `engine4_core_menuitems` (`id`, `name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `enabled`, `custom`, `order`) VALUES (1,'core_main_home','core','Home','User_Plugin_Menus','','core_main','',1,0,1),(2,'core_sitemap_home','core','Home','','{\"route\":\"default\"}','core_sitemap','',1,0,1),(3,'core_footer_privacy','core','Privacy','','{\"route\":\"default\",\"module\":\"core\",\"controller\":\"help\",\"action\":\"privacy\"}','core_footer','',1,0,1),(4,'core_footer_terms','core','Terms of Service','','{\"route\":\"default\",\"module\":\"core\",\"controller\":\"help\",\"action\":\"terms\"}','core_footer','',1,0,2),(5,'core_footer_contact','core','Contact','','{\"route\":\"default\",\"module\":\"core\",\"controller\":\"help\",\"action\":\"contact\"}','core_footer','',1,0,3),(6,'core_mini_admin','core','Admin','User_Plugin_Menus','','core_mini','',1,0,6),(7,'core_mini_profile','user','My Profile','User_Plugin_Menus','','core_mini','',1,0,5),(8,'core_mini_settings','user','Settings','User_Plugin_Menus','','core_mini','',1,0,3),(9,'core_mini_auth','user','Auth','User_Plugin_Menus','','core_mini','',1,0,2),(10,'core_mini_signup','user','Signup','User_Plugin_Menus','','core_mini','',1,0,1),(11,'core_admin_main_home','core','Home','','{\"route\":\"admin_default\"}','core_admin_main','',1,0,1),(12,'core_admin_main_manage','core','Manage','','{\"uri\":\"javascript:void(0);this.blur();\"}','core_admin_main','core_admin_main_manage',1,0,2),(13,'core_admin_main_settings','core','Settings','','{\"uri\":\"javascript:void(0);this.blur();\"}','core_admin_main','core_admin_main_settings',1,0,3),(14,'core_admin_main_plugins','core','Plugins','','{\"uri\":\"javascript:void(0);this.blur();\"}','core_admin_main','core_admin_main_plugins',1,0,4),(15,'core_admin_main_layout','core','Layout','','{\"uri\":\"javascript:void(0);this.blur();\"}','core_admin_main','core_admin_main_layout',1,0,5),(16,'core_admin_main_ads','core','Ads','','{\"uri\":\"javascript:void(0);this.blur();\"}','core_admin_main','core_admin_main_ads',1,0,6),(17,'core_admin_main_stats','core','Stats','','{\"uri\":\"javascript:void(0);this.blur();\"}','core_admin_main','core_admin_main_stats',1,0,8),(18,'core_admin_main_manage_levels','core','Member Levels','','{\"route\":\"admin_default\",\"module\":\"authorization\",\"controller\":\"level\"}','core_admin_main_manage','',1,0,2),(19,'core_admin_main_manage_networks','network','Networks','','{\"route\":\"admin_default\",\"module\":\"network\",\"controller\":\"manage\"}','core_admin_main_manage','',1,0,3),(20,'core_admin_main_manage_announcements','announcement','Announcements','','{\"route\":\"admin_default\",\"module\":\"announcement\",\"controller\":\"manage\"}','core_admin_main_manage','',1,0,4),(21,'core_admin_message_mail','core','Email All Members','','{\"route\":\"admin_default\",\"module\":\"core\",\"controller\":\"message\",\"action\":\"mail\"}','core_admin_main_manage','',1,0,5),(22,'core_admin_main_manage_reports','core','Abuse Reports','','{\"route\":\"admin_default\",\"module\":\"core\",\"controller\":\"report\"}','core_admin_main_manage','',1,0,6),(23,'core_admin_main_manage_packages','core','Packages & Plugins','','{\"route\":\"admin_default\",\"module\":\"core\",\"controller\":\"packages\"}','core_admin_main_manage','',1,0,7),(24,'core_admin_main_settings_general','core','General Settings','','{\"route\":\"core_admin_settings\",\"action\":\"general\"}','core_admin_main_settings','',1,0,1),(25,'core_admin_main_settings_locale','core','Locale Settings','','{\"route\":\"core_admin_settings\",\"action\":\"locale\"}','core_admin_main_settings','',1,0,1),(26,'core_admin_main_settings_fields','fields','Profile Questions','','{\"route\":\"admin_default\",\"module\":\"user\",\"controller\":\"fields\"}','core_admin_main_settings','',1,0,2),(27,'core_admin_main_wibiya','core','Wibiya Integration','','{\"route\":\"admin_default\", \"action\":\"wibiya\", \"controller\":\"settings\", \"module\":\"core\"}','core_admin_main_settings','',1,0,4),(28,'core_admin_main_settings_spam','core','Spam & Banning Tools','','{\"route\":\"core_admin_settings\",\"action\":\"spam\"}','core_admin_main_settings','',1,0,5),(29,'core_admin_main_settings_mailtemplates','core','Mail Templates','','{\"route\":\"admin_default\",\"controller\":\"mail\",\"action\":\"templates\"}','core_admin_main_settings','',1,0,6),(30,'core_admin_main_settings_mailsettings','core','Mail Settings','','{\"route\":\"admin_default\",\"controller\":\"mail\",\"action\":\"settings\"}','core_admin_main_settings','',1,0,7),(31,'core_admin_main_settings_performance','core','Performance & Caching','','{\"route\":\"core_admin_settings\",\"action\":\"performance\"}','core_admin_main_settings','',1,0,8),(32,'core_admin_main_settings_password','core','Admin Password','','{\"route\":\"core_admin_settings\",\"action\":\"password\"}','core_admin_main_settings','',1,0,9),(33,'core_admin_main_settings_tasks','core','Task Scheduler','','{\"route\":\"admin_default\",\"controller\":\"tasks\"}','core_admin_main_settings','',1,0,10),(34,'core_admin_main_layout_content','core','Layout Editor','','{\"route\":\"admin_default\",\"controller\":\"content\"}','core_admin_main_layout','',1,0,1),(35,'core_admin_main_layout_themes','core','Theme Editor','','{\"route\":\"admin_default\",\"controller\":\"themes\"}','core_admin_main_layout','',1,0,2),(36,'core_admin_main_layout_files','core','File & Media Manager','','{\"route\":\"admin_default\",\"controller\":\"files\"}','core_admin_main_layout','',1,0,3),(37,'core_admin_main_layout_language','core','Language Manager','','{\"route\":\"admin_default\",\"controller\":\"language\"}','core_admin_main_layout','',1,0,4),(38,'core_admin_main_layout_menus','core','Menu Editor','','{\"route\":\"admin_default\",\"controller\":\"menus\"}','core_admin_main_layout','',1,0,5),(39,'core_admin_main_ads_manage','core','Manage Ad Campaigns','','{\"route\":\"admin_default\",\"controller\":\"ads\"}','core_admin_main_ads','',1,0,1),(40,'core_admin_main_ads_create','core','Create New Campaign','','{\"route\":\"admin_default\",\"controller\":\"ads\",\"action\":\"create\"}','core_admin_main_ads','',1,0,2),(41,'core_admin_main_ads_affiliate','core','SE Affiliate Program','','{\"route\":\"admin_default\",\"controller\":\"settings\",\"action\":\"affiliate\"}','core_admin_main_ads','',1,0,3),(42,'core_admin_main_ads_viglink','core','VigLink','','{\"route\":\"admin_default\",\"controller\":\"settings\",\"action\":\"viglink\"}','core_admin_main_ads','',1,0,4),(43,'core_admin_main_stats_statistics','core','Site-wide Statistics','','{\"route\":\"admin_default\",\"controller\":\"stats\"}','core_admin_main_stats','',1,0,1),(44,'core_admin_main_stats_url','core','Referring URLs','','{\"route\":\"admin_default\",\"controller\":\"stats\",\"action\":\"referrers\"}','core_admin_main_stats','',1,0,2),(45,'core_admin_main_stats_resources','core','Server Information','','{\"route\":\"admin_default\",\"controller\":\"system\"}','core_admin_main_stats','',1,0,3),(46,'core_admin_main_stats_logs','core','Log Browser','','{\"route\":\"admin_default\",\"controller\":\"log\",\"action\":\"index\"}','core_admin_main_stats','',1,0,3),(47,'core_admin_banning_general','core','Spam & Banning Tools','','{\"route\":\"core_admin_settings\",\"action\":\"spam\"}','core_admin_banning','',1,0,1),(48,'adcampaign_admin_main_edit','core','Edit Settings','','{\"route\":\"admin_default\",\"module\":\"core\",\"controller\":\"ads\",\"action\":\"edit\"}','adcampaign_admin_main','',1,0,1),(49,'adcampaign_admin_main_manageads','core','Manage Advertisements','','{\"route\":\"admin_default\",\"module\":\"core\",\"controller\":\"ads\",\"action\":\"manageads\"}','adcampaign_admin_main','',1,0,2),(50,'core_admin_main_settings_activity','activity','Activity Feed Settings','','{\"route\":\"admin_default\",\"module\":\"activity\",\"controller\":\"settings\",\"action\":\"index\"}','core_admin_main_settings','',1,0,4),(51,'core_admin_main_settings_notifications','activity','Default Email Notifications','','{\"route\":\"admin_default\",\"module\":\"activity\",\"controller\":\"settings\",\"action\":\"notifications\"}','core_admin_main_settings','',1,0,11),(52,'authorization_admin_main_manage','authorization','View Member Levels','','{\"route\":\"admin_default\",\"module\":\"authorization\",\"controller\":\"level\"}','authorization_admin_main','',1,0,1),(53,'authorization_admin_main_level','authorization','Member Level Settings','','{\"route\":\"admin_default\",\"module\":\"authorization\",\"controller\":\"level\",\"action\":\"edit\"}','authorization_admin_main','',1,0,3),(54,'authorization_admin_level_main','authorization','Level Info','','{\"route\":\"admin_default\",\"module\":\"authorization\",\"controller\":\"level\",\"action\":\"edit\"}','authorization_admin_level','',1,0,1),(55,'core_main_user','user','Members','','{\"route\":\"user_general\",\"action\":\"browse\"}','core_main','',1,0,2),(56,'core_sitemap_user','user','Members','','{\"route\":\"user_general\",\"action\":\"browse\"}','core_sitemap','',1,0,2),(57,'user_home_updates','user','View Recent Updates','','{\"route\":\"recent_activity\",\"icon\":\"application/modules/User/externals/images/links/updates.png\"}','user_home','',1,0,1),(58,'user_home_view','user','View My Profile','User_Plugin_Menus','{\"route\":\"user_profile_self\",\"icon\":\"application/modules/User/externals/images/links/profile.png\"}','user_home','',1,0,2),(59,'user_home_edit','user','Edit My Profile','User_Plugin_Menus','{\"route\":\"user_extended\",\"module\":\"user\",\"controller\":\"edit\",\"action\":\"profile\",\"icon\":\"application/modules/User/externals/images/links/edit.png\"}','user_home','',1,0,3),(60,'user_home_friends','user','Browse Members','','{\"route\":\"user_general\",\"controller\":\"index\",\"action\":\"browse\",\"icon\":\"application/modules/User/externals/images/links/search.png\"}','user_home','',1,0,4),(61,'user_profile_edit','user','Edit Profile','User_Plugin_Menus','','user_profile','',1,0,1),(62,'user_profile_friend','user','Friends','User_Plugin_Menus','','user_profile','',1,0,3),(63,'user_profile_block','user','Block','User_Plugin_Menus','','user_profile','',1,0,4),(64,'user_profile_report','user','Report User','User_Plugin_Menus','','user_profile','',1,0,5),(65,'user_profile_admin','user','Admin Settings','User_Plugin_Menus','','user_profile','',1,0,9),(66,'user_edit_profile','user','Personal Info','','{\"route\":\"user_extended\",\"module\":\"user\",\"controller\":\"edit\",\"action\":\"profile\"}','user_edit','',1,0,1),(67,'user_edit_photo','user','Edit My Photo','','{\"route\":\"user_extended\",\"module\":\"user\",\"controller\":\"edit\",\"action\":\"photo\"}','user_edit','',1,0,2),(68,'user_edit_style','user','Profile Style','User_Plugin_Menus','{\"route\":\"user_extended\",\"module\":\"user\",\"controller\":\"edit\",\"action\":\"style\"}','user_edit','',1,0,3),(69,'user_settings_general','user','General','','{\"route\":\"user_extended\",\"module\":\"user\",\"controller\":\"settings\",\"action\":\"general\"}','user_settings','',1,0,1),(70,'user_settings_privacy','user','Privacy','','{\"route\":\"user_extended\",\"module\":\"user\",\"controller\":\"settings\",\"action\":\"privacy\"}','user_settings','',1,0,2),(71,'user_settings_notifications','user','Notifications','','{\"route\":\"user_extended\",\"module\":\"user\",\"controller\":\"settings\",\"action\":\"notifications\"}','user_settings','',1,0,3),(72,'user_settings_password','user','Change Password','','{\"route\":\"user_extended\", \"module\":\"user\", \"controller\":\"settings\", \"action\":\"password\"}','user_settings','',1,0,5),(73,'user_settings_delete','user','Delete Account','User_Plugin_Menus::canDelete','{\"route\":\"user_extended\", \"module\":\"user\", \"controller\":\"settings\", \"action\":\"delete\"}','user_settings','',1,0,6),(74,'core_admin_main_manage_members','user','Members','','{\"route\":\"admin_default\",\"module\":\"user\",\"controller\":\"manage\"}','core_admin_main_manage','',1,0,1),(75,'core_admin_main_signup','user','Signup Process','','{\"route\":\"admin_default\", \"controller\":\"signup\", \"module\":\"user\"}','core_admin_main_settings','',1,0,3),(76,'core_admin_main_facebook','user','Facebook Integration','','{\"route\":\"admin_default\", \"action\":\"facebook\", \"controller\":\"settings\", \"module\":\"user\"}','core_admin_main_settings','',1,0,4),(77,'core_admin_main_twitter','user','Twitter Integration','','{\"route\":\"admin_default\", \"action\":\"twitter\", \"controller\":\"settings\", \"module\":\"user\"}','core_admin_main_settings','',1,0,4),(78,'core_admin_main_janrain','user','Janrain Integration','','{\"route\":\"admin_default\", \"action\":\"janrain\", \"controller\":\"settings\", \"module\":\"user\"}','core_admin_main_settings','',1,0,4),(79,'core_admin_main_settings_friends','user','Friendship Settings','','{\"route\":\"admin_default\",\"module\":\"user\",\"controller\":\"settings\",\"action\":\"friends\"}','core_admin_main_settings','',1,0,6),(80,'user_admin_banning_logins','user','Login History','','{\"route\":\"admin_default\",\"module\":\"user\",\"controller\":\"logins\",\"action\":\"index\"}','core_admin_banning','',1,0,2),(81,'authorization_admin_level_user','user','Members','','{\"route\":\"admin_default\",\"module\":\"user\",\"controller\":\"settings\",\"action\":\"level\"}','authorization_admin_level','',1,0,2),(82,'core_mini_messages','messages','Messages','Messages_Plugin_Menus','','core_mini','',1,0,4),(83,'user_profile_message','messages','Send Message','Messages_Plugin_Menus','','user_profile','',1,0,2),(84,'authorization_admin_level_messages','messages','Messages','','{\"route\":\"admin_default\",\"module\":\"messages\",\"controller\":\"settings\",\"action\":\"level\"}','authorization_admin_level','',1,0,3),(85,'messages_main_inbox','messages','Inbox','','{\"route\":\"messages_general\",\"action\":\"inbox\"}','messages_main','',1,0,1),(86,'messages_main_outbox','messages','Sent Messages','','{\"route\":\"messages_general\",\"action\":\"outbox\"}','messages_main','',1,0,2),(87,'messages_main_compose','messages','Compose Message','','{\"route\":\"messages_general\",\"action\":\"compose\"}','messages_main','',1,0,3),(88,'user_settings_network','network','Networks','','{\"route\":\"user_extended\", \"module\":\"user\", \"controller\":\"settings\", \"action\":\"network\"}','user_settings','',1,0,3),(89,'core_main_invite','invite','Invite','Invite_Plugin_Menus::canInvite','{\"route\":\"default\",\"module\":\"invite\"}','core_main','',1,0,1),(90,'user_home_invite','invite','Invite Your Friends','Invite_Plugin_Menus::canInvite','{\"route\":\"default\",\"module\":\"invite\",\"icon\":\"application/modules/Invite/externals/images/invite.png\"}','user_home','',1,0,5),(91,'core_admin_main_settings_storage','core','Storage System','','{\"route\":\"admin_default\",\"module\":\"storage\",\"controller\":\"services\",\"action\":\"index\"}','core_admin_main_settings','',1,0,11),(92,'user_settings_payment','user','Subscription','Payment_Plugin_Menus','{\"route\":\"default\", \"module\":\"payment\", \"controller\":\"settings\", \"action\":\"index\"}','user_settings','',1,0,4),(93,'core_admin_main_payment','payment','Billing','','{\"uri\":\"javascript:void(0);this.blur();\"}','core_admin_main','core_admin_main_payment',1,0,7),(94,'core_admin_main_payment_transactions','payment','Transactions','','{\"route\":\"admin_default\",\"module\":\"payment\",\"controller\":\"index\",\"action\":\"index\"}','core_admin_main_payment','',1,0,1),(95,'core_admin_main_payment_settings','payment','Settings','','{\"route\":\"admin_default\",\"module\":\"payment\",\"controller\":\"settings\",\"action\":\"index\"}','core_admin_main_payment','',1,0,2),(96,'core_admin_main_payment_gateways','payment','Gateways','','{\"route\":\"admin_default\",\"module\":\"payment\",\"controller\":\"gateway\",\"action\":\"index\"}','core_admin_main_payment','',1,0,3),(97,'core_admin_main_payment_packages','payment','Plans','','{\"route\":\"admin_default\",\"module\":\"payment\",\"controller\":\"package\",\"action\":\"index\"}','core_admin_main_payment','',1,0,4),(98,'core_admin_main_payment_subscriptions','payment','Subscriptions','','{\"route\":\"admin_default\",\"module\":\"payment\",\"controller\":\"subscription\",\"action\":\"index\"}','core_admin_main_payment','',1,0,5),(99,'core_main_album','album','Albums','','{\"route\":\"album_general\",\"action\":\"browse\"}','core_main','',1,0,3),(100,'core_sitemap_album','album','Albums','','{\"route\":\"album_general\",\"action\":\"browse\"}','core_sitemap','',1,0,3),(101,'album_main_browse','album','Browse Albums','Album_Plugin_Menus::canViewAlbums','{\"route\":\"album_general\",\"action\":\"browse\"}','album_main','',1,0,1),(102,'album_main_manage','album','My Albums','Album_Plugin_Menus::canCreateAlbums','{\"route\":\"album_general\",\"action\":\"manage\"}','album_main','',1,0,2),(103,'album_main_upload','album','Add New Photos','Album_Plugin_Menus::canCreateAlbums','{\"route\":\"album_general\",\"action\":\"upload\"}','album_main','',1,0,3),(104,'album_quick_upload','album','Add New Photos','Album_Plugin_Menus::canCreateAlbums','{\"route\":\"album_general\",\"action\":\"upload\",\"class\":\"buttonlink icon_photos_new\"}','album_quick','',1,0,1),(105,'core_admin_main_plugins_album','album','Photo Albums','','{\"route\":\"admin_default\",\"module\":\"album\",\"controller\":\"manage\",\"action\":\"index\"}','core_admin_main_plugins','',1,0,999),(106,'album_admin_main_manage','album','View Albums','','{\"route\":\"admin_default\",\"module\":\"album\",\"controller\":\"manage\"}','album_admin_main','',1,0,1),(107,'album_admin_main_settings','album','Global Settings','','{\"route\":\"admin_default\",\"module\":\"album\",\"controller\":\"settings\"}','album_admin_main','',1,0,2),(108,'album_admin_main_level','album','Member Level Settings','','{\"route\":\"admin_default\",\"module\":\"album\",\"controller\":\"level\"}','album_admin_main','',1,0,3),(109,'album_admin_main_categories','album','Categories','','{\"route\":\"admin_default\",\"module\":\"album\",\"controller\":\"settings\", \"action\":\"categories\"}','album_admin_main','',1,0,4),(110,'authorization_admin_level_album','album','Photo Albums','','{\"route\":\"admin_default\",\"module\":\"album\",\"controller\":\"level\",\"action\":\"index\"}','authorization_admin_level','',1,0,999),(111,'mobi_browse_album','album','Albums','','{\"route\":\"album_general\",\"action\":\"browse\"}','mobi_browse','',1,0,2),(112,'core_main_blog','blog','Blogs','','{\"route\":\"blog_general\"}','core_main','',1,0,4),(113,'core_sitemap_blog','blog','Blogs','','{\"route\":\"blog_general\"}','core_sitemap','',1,0,4),(114,'blog_main_browse','blog','Browse Entries','Blog_Plugin_Menus::canViewBlogs','{\"route\":\"blog_general\"}','blog_main','',1,0,1),(115,'blog_main_manage','blog','My Entries','Blog_Plugin_Menus::canCreateBlogs','{\"route\":\"blog_general\",\"action\":\"manage\"}','blog_main','',1,0,2),(116,'blog_main_create','blog','Write New Entry','Blog_Plugin_Menus::canCreateBlogs','{\"route\":\"blog_general\",\"action\":\"create\"}','blog_main','',1,0,3),(117,'blog_quick_create','blog','Write New Entry','Blog_Plugin_Menus::canCreateBlogs','{\"route\":\"blog_general\",\"action\":\"create\",\"class\":\"buttonlink icon_blog_new\"}','blog_quick','',1,0,1),(118,'blog_quick_style','blog','Edit Blog Style','Blog_Plugin_Menus','{\"route\":\"blog_general\",\"action\":\"style\",\"class\":\"smoothbox buttonlink icon_blog_style\"}','blog_quick','',1,0,2),(119,'blog_gutter_list','blog','View All Entries','Blog_Plugin_Menus','{\"route\":\"blog_view\",\"class\":\"buttonlink icon_blog_viewall\"}','blog_gutter','',1,0,1),(120,'blog_gutter_create','blog','Write New Entry','Blog_Plugin_Menus','{\"route\":\"blog_general\",\"action\":\"create\",\"class\":\"buttonlink icon_blog_new\"}','blog_gutter','',1,0,2),(121,'blog_gutter_style','blog','Edit Blog Style','Blog_Plugin_Menus','{\"route\":\"blog_general\",\"action\":\"style\",\"class\":\"smoothbox buttonlink icon_blog_style\"}','blog_gutter','',1,0,3),(122,'blog_gutter_edit','blog','Edit This Entry','Blog_Plugin_Menus','{\"route\":\"blog_specific\",\"action\":\"edit\",\"class\":\"buttonlink icon_blog_edit\"}','blog_gutter','',1,0,4),(123,'blog_gutter_delete','blog','Delete This Entry','Blog_Plugin_Menus','{\"route\":\"blog_specific\",\"action\":\"delete\",\"class\":\"buttonlink smoothbox icon_blog_delete\"}','blog_gutter','',1,0,5),(124,'blog_gutter_share','blog','Share','Blog_Plugin_Menus','{\"route\":\"default\",\"module\":\"activity\",\"controller\":\"index\",\"action\":\"share\",\"class\":\"buttonlink smoothbox icon_comments\"}','blog_gutter','',1,0,6),(125,'blog_gutter_report','blog','Report','Blog_Plugin_Menus','{\"route\":\"default\",\"module\":\"core\",\"controller\":\"report\",\"action\":\"create\",\"class\":\"buttonlink smoothbox icon_report\"}','blog_gutter','',1,0,7),(126,'blog_gutter_subscribe','blog','Subscribe','Blog_Plugin_Menus','{\"route\":\"default\",\"module\":\"blog\",\"controller\":\"subscription\",\"action\":\"add\",\"class\":\"buttonlink smoothbox icon_blog_subscribe\"}','blog_gutter','',1,0,8),(127,'core_admin_main_plugins_blog','blog','Blogs','','{\"route\":\"admin_default\",\"module\":\"blog\",\"controller\":\"manage\"}','core_admin_main_plugins','',1,0,999),(128,'blog_admin_main_manage','blog','View Blogs','','{\"route\":\"admin_default\",\"module\":\"blog\",\"controller\":\"manage\"}','blog_admin_main','',1,0,1),(129,'blog_admin_main_settings','blog','Global Settings','','{\"route\":\"admin_default\",\"module\":\"blog\",\"controller\":\"settings\"}','blog_admin_main','',1,0,2),(130,'blog_admin_main_level','blog','Member Level Settings','','{\"route\":\"admin_default\",\"module\":\"blog\",\"controller\":\"level\"}','blog_admin_main','',1,0,3),(131,'blog_admin_main_categories','blog','Categories','','{\"route\":\"admin_default\",\"module\":\"blog\",\"controller\":\"settings\", \"action\":\"categories\"}','blog_admin_main','',1,0,4),(132,'authorization_admin_level_blog','blog','Blogs','','{\"route\":\"admin_default\",\"module\":\"blog\",\"controller\":\"level\",\"action\":\"index\"}','authorization_admin_level','',1,0,999),(133,'mobi_browse_blog','blog','Blogs','','{\"route\":\"blog_general\"}','mobi_browse','',1,0,3),(134,'core_main_chat','chat','Chat','','{\"route\":\"default\",\"module\":\"chat\"}','core_main','',1,0,5),(135,'core_sitemap_chat','chat','Chat','','{\"route\":\"default\",\"module\":\"chat\"}','core_sitemap','',1,0,5),(136,'core_admin_main_plugins_chat','chat','Chat','','{\"route\":\"admin_default\",\"module\":\"chat\",\"controller\":\"manage\"}','core_admin_main_plugins','',1,0,999),(137,'chat_admin_main_manage','chat','Manage Chat Rooms','','{\"route\":\"admin_default\",\"module\":\"chat\",\"controller\":\"manage\"}','chat_admin_main','',1,0,1),(138,'chat_admin_main_settings','chat','Global Settings','','{\"route\":\"admin_default\",\"module\":\"chat\",\"controller\":\"settings\"}','chat_admin_main','',1,0,2),(139,'chat_admin_main_level','chat','Member Level Settings','','{\"route\":\"admin_default\",\"module\":\"chat\",\"controller\":\"settings\",\"action\":\"level\"}','chat_admin_main','',1,0,3),(140,'authorization_admin_level_chat','chat','Chat','','{\"route\":\"admin_default\",\"module\":\"chat\",\"controller\":\"settings\",\"action\":\"level\"}','authorization_admin_level','',1,0,999),(141,'core_main_classified','classified','Classifieds','','{\"route\":\"classified_general\"}','core_main','',0,0,4),(142,'core_sitemap_classified','classified','Classifieds','','{\"route\":\"classified_general\"}','core_sitemap','',1,0,4),(143,'classified_main_browse','classified','Browse Listings','Classified_Plugin_Menus::canViewClassifieds','{\"route\":\"classified_general\"}','classified_main','',1,0,1),(144,'classified_main_manage','classified','My Listings','Classified_Plugin_Menus::canCreateClassifieds','{\"route\":\"classified_general\",\"action\":\"manage\"}','classified_main','',1,0,2),(145,'classified_main_create','classified','Post a New Listing','Classified_Plugin_Menus::canCreateClassifieds','{\"route\":\"classified_general\",\"action\":\"create\"}','classified_main','',1,0,3),(146,'classified_quick_create','classified','Post a New Listing','Classified_Plugin_Menus::canCreateClassifieds','{\"route\":\"classified_general\",\"action\":\"create\",\"class\":\"buttonlink icon_classified_new\"}','classified_quick','',1,0,1),(147,'core_admin_main_plugins_classified','classified','Classifieds','','{\"route\":\"admin_default\",\"module\":\"classified\",\"controller\":\"manage\"}','core_admin_main_plugins','',1,0,999),(148,'classified_admin_main_manage','classified','View Classifieds','','{\"route\":\"admin_default\",\"module\":\"classified\",\"controller\":\"manage\"}','classified_admin_main','',1,0,1),(149,'classified_admin_main_settings','classified','Global Settings','','{\"route\":\"admin_default\",\"module\":\"classified\",\"controller\":\"settings\"}','classified_admin_main','',1,0,2),(150,'classified_admin_main_level','classified','Member Level Settings','','{\"route\":\"admin_default\",\"module\":\"classified\",\"controller\":\"level\"}','classified_admin_main','',1,0,3),(151,'classified_admin_main_fields','classified','Classified Questions','','{\"route\":\"admin_default\",\"module\":\"classified\",\"controller\":\"fields\"}','classified_admin_main','',1,0,4),(152,'classified_admin_main_categories','classified','Categories','','{\"route\":\"admin_default\",\"module\":\"classified\",\"controller\":\"settings\",\"action\":\"categories\"}','classified_admin_main','',1,0,5),(153,'authorization_admin_level_classified','classified','Classifieds','','{\"route\":\"admin_default\",\"module\":\"classified\",\"controller\":\"level\",\"action\":\"index\"}','authorization_admin_level','',1,0,999),(154,'mobi_browse_classified','classified','Classifieds','','{\"route\":\"classified_general\"}','mobi_browse','',1,0,4),(155,'core_main_event','event','Events','','{\"route\":\"event_general\"}','core_main','',1,0,6),(156,'core_sitemap_event','event','Events','','{\"route\":\"event_general\"}','core_sitemap','',1,0,6),(157,'event_main_upcoming','event','Upcoming Events','','{\"route\":\"event_upcoming\"}','event_main','',1,0,1),(158,'event_main_past','event','Past Events','','{\"route\":\"event_past\"}','event_main','',1,0,2),(159,'event_main_manage','event','My Events','Event_Plugin_Menus','{\"route\":\"event_general\",\"action\":\"manage\"}','event_main','',1,0,3),(160,'event_main_create','event','Create New Event','Event_Plugin_Menus','{\"route\":\"event_general\",\"action\":\"create\"}','event_main','',1,0,4),(161,'event_quick_create','event','Create New Event','Event_Plugin_Menus::canCreateEvents','{\"route\":\"event_general\",\"action\":\"create\",\"class\":\"buttonlink icon_event_new\"}','event_quick','',1,0,1),(162,'event_profile_edit','event','Edit Profile','Event_Plugin_Menus','','event_profile','',1,0,1),(163,'event_profile_style','event','Edit Styles','Event_Plugin_Menus','','event_profile','',1,0,2),(164,'event_profile_member','event','Member','Event_Plugin_Menus','','event_profile','',1,0,3),(165,'event_profile_report','event','Report Event','Event_Plugin_Menus','','event_profile','',1,0,4),(166,'event_profile_share','event','Share','Event_Plugin_Menus','','event_profile','',1,0,5),(167,'event_profile_invite','event','Invite','Event_Plugin_Menus','','event_profile','',1,0,6),(168,'event_profile_message','event','Message Members','Event_Plugin_Menus','','event_profile','',1,0,7),(169,'event_profile_delete','event','Delete Event','Event_Plugin_Menus','','event_profile','',1,0,8),(170,'core_admin_main_plugins_event','event','Events','','{\"route\":\"admin_default\",\"module\":\"event\",\"controller\":\"manage\"}','core_admin_main_plugins','',1,0,999),(171,'event_admin_main_manage','event','Manage Events','','{\"route\":\"admin_default\",\"module\":\"event\",\"controller\":\"manage\"}','event_admin_main','',1,0,1),(172,'event_admin_main_settings','event','Global Settings','','{\"route\":\"admin_default\",\"module\":\"event\",\"controller\":\"settings\"}','event_admin_main','',1,0,2),(173,'event_admin_main_level','event','Member Level Settings','','{\"route\":\"admin_default\",\"module\":\"event\",\"controller\":\"settings\",\"action\":\"level\"}','event_admin_main','',1,0,3),(174,'event_admin_main_categories','event','Categories','','{\"route\":\"admin_default\",\"module\":\"event\",\"controller\":\"settings\",\"action\":\"categories\"}','event_admin_main','',1,0,4),(175,'authorization_admin_level_event','event','Events','','{\"route\":\"admin_default\",\"module\":\"event\",\"controller\":\"level\",\"action\":\"index\"}','authorization_admin_level','',1,0,999),(176,'mobi_browse_event','event','Events','','{\"route\":\"event_general\"}','mobi_browse','',1,0,7),(177,'core_main_forum','forum','Forum','','{\"route\":\"forum_general\"}','core_main','',1,0,5),(178,'core_sitemap_forum','forum','Forum','','{\"route\":\"forum_general\"}','core_sitemap','',1,0,5),(179,'core_admin_main_plugins_forum','forum','Forums','','{\"route\":\"admin_default\",\"module\":\"forum\",\"controller\":\"manage\"}','core_admin_main_plugins','',1,0,999),(180,'forum_admin_main_manage','forum','Manage Forums','','{\"route\":\"admin_default\",\"module\":\"forum\",\"controller\":\"manage\"}','forum_admin_main','',1,0,1),(181,'forum_admin_main_settings','forum','Global Settings','','{\"route\":\"admin_default\",\"module\":\"forum\",\"controller\":\"settings\"}','forum_admin_main','',1,0,2),(182,'forum_admin_main_level','forum','Member Level Settings','','{\"route\":\"admin_default\",\"module\":\"forum\",\"controller\":\"level\"}','forum_admin_main','',1,0,3),(183,'authorization_admin_level_forum','forum','Forums','','{\"route\":\"admin_default\",\"module\":\"forum\",\"controller\":\"level\",\"action\":\"index\"}','authorization_admin_level','',1,0,999),(184,'mobi_browse_forum','forum','Forum','','{\"route\":\"forum_general\"}','mobi_browse','',1,0,5),(185,'core_main_group','group','Groups','','{\"route\":\"group_general\"}','core_main','',1,0,6),(186,'core_sitemap_group','group','Groups','','{\"route\":\"group_general\"}','core_sitemap','',1,0,6),(187,'group_main_browse','group','Browse Groups','','{\"route\":\"group_general\",\"action\":\"browse\"}','group_main','',1,0,1),(188,'group_main_manage','group','My Groups','Group_Plugin_Menus','{\"route\":\"group_general\",\"action\":\"manage\"}','group_main','',1,0,2),(189,'group_main_create','group','Create New Group','Group_Plugin_Menus','{\"route\":\"group_general\",\"action\":\"create\"}','group_main','',1,0,3),(190,'group_quick_create','group','Create New Group','Group_Plugin_Menus::canCreateGroups','{\"route\":\"group_general\",\"action\":\"create\",\"class\":\"buttonlink icon_group_new\"}','group_quick','',1,0,1),(191,'group_profile_edit','group','Edit Profile','Group_Plugin_Menus','','group_profile','',1,0,1),(192,'group_profile_style','group','Edit Styles','Group_Plugin_Menus','','group_profile','',1,0,2),(193,'group_profile_member','group','Member','Group_Plugin_Menus','','group_profile','',1,0,3),(194,'group_profile_report','group','Report Group','Group_Plugin_Menus','','group_profile','',1,0,4),(195,'group_profile_share','group','Share','Group_Plugin_Menus','','group_profile','',1,0,5),(196,'group_profile_invite','group','Invite','Group_Plugin_Menus','','group_profile','',1,0,6),(197,'group_profile_message','group','Message Members','Group_Plugin_Menus','','group_profile','',1,0,7),(198,'core_admin_main_plugins_group','group','Groups','','{\"route\":\"admin_default\",\"module\":\"group\",\"controller\":\"manage\"}','core_admin_main_plugins','',1,0,999),(199,'group_admin_main_manage','group','Manage Groups','','{\"route\":\"admin_default\",\"module\":\"group\",\"controller\":\"manage\"}','group_admin_main','',1,0,1),(200,'group_admin_main_settings','group','Global Settings','','{\"route\":\"admin_default\",\"module\":\"group\",\"controller\":\"settings\"}','group_admin_main','',1,0,2),(201,'group_admin_main_level','group','Member Level Settings','','{\"route\":\"admin_default\",\"module\":\"group\",\"controller\":\"settings\",\"action\":\"level\"}','group_admin_main','',1,0,3),(202,'group_admin_main_categories','group','Categories','','{\"route\":\"admin_default\",\"module\":\"group\",\"controller\":\"settings\",\"action\":\"categories\"}','group_admin_main','',1,0,4),(203,'authorization_admin_level_group','group','Groups','','{\"route\":\"admin_default\",\"module\":\"group\",\"controller\":\"settings\",\"action\":\"level\"}','authorization_admin_level','',1,0,999),(204,'mobi_browse_group','group','Groups','','{\"route\":\"group_general\"}','mobi_browse','',1,0,8),(205,'core_footer_mobile','mobi','Mobile Site','Mobi_Plugin_Menus','','core_footer','',1,0,4),(206,'mobi_footer_mobile','mobi','Mobile Site','Mobi_Plugin_Menus','','mobi_footer','',1,0,1),(207,'mobi_footer_auth','mobi','Auth','Mobi_Plugin_Menus','','mobi_footer','',1,0,2),(208,'mobi_footer_signup','mobi','Sign Up','Mobi_Plugin_Menus','','mobi_footer','',1,0,3),(209,'mobi_main_home','mobi','Home','Mobi_Plugin_Menus','','mobi_main','',1,0,1),(210,'mobi_main_profile','mobi','Profile','Mobi_Plugin_Menus','','mobi_main','',1,0,2),(211,'mobi_main_messages','mobi','Inbox','Mobi_Plugin_Menus','','mobi_main','',1,0,3),(212,'mobi_main_browse','mobi','Browse','Mobi_Plugin_Menus','','mobi_main','',1,0,4),(213,'mobi_profile_message','mobi','Send Message','Mobi_Plugin_Menus','','mobi_profile','',1,0,1),(214,'mobi_profile_friend','mobi','Friends','Mobi_Plugin_Menus','','mobi_profile','',1,0,2),(215,'mobi_profile_edit','mobi','Edit Profile','Mobi_Plugin_Menus','','mobi_profile','',1,0,3),(216,'mobi_profile_report','mobi','Report User','Mobi_Plugin_Menus','','mobi_profile','',1,0,4),(217,'mobi_profile_block','mobi','Block','Mobi_Plugin_Menus','','mobi_profile','',1,0,5),(218,'mobi_profile_admin','mobi','Admin','Mobi_Plugin_Menus','','mobi_profile','',1,0,6),(219,'mobi_browse_members','user','Members','','{\"route\":\"user_general\",\"action\":\"browse\"}','mobi_browse','',1,0,1),(220,'core_main_music','music','Music','','{\"route\":\"music_general\",\"action\":\"browse\"}','core_main','',0,0,100),(221,'core_sitemap_music','music','Music','','{\"route\":\"music_general\",\"action\":\"browse\"}','core_sitemap','',1,0,100),(222,'music_main_browse','music','Browse Music','Music_Plugin_Menus::canViewPlaylists','{\"route\":\"music_general\",\"action\":\"browse\"}','music_main','',1,0,1),(223,'music_main_manage','music','My Music','Music_Plugin_Menus::canCreatePlaylists','{\"route\":\"music_general\",\"action\":\"manage\"}','music_main','',1,0,2),(224,'music_main_create','music','Upload Music','Music_Plugin_Menus::canCreatePlaylists','{\"route\":\"music_general\",\"action\":\"create\"}','music_main','',1,0,3),(225,'music_quick_create','music','Upload Music','Music_Plugin_Menus::canCreatePlaylists','{\"route\":\"music_general\",\"action\":\"create\",\"class\":\"buttonlink icon_music_new\"}','music_quick','',1,0,1),(226,'core_admin_main_plugins_music','music','Music','','{\"route\":\"admin_default\",\"module\":\"music\",\"controller\":\"manage\"}','core_admin_main_plugins','',1,0,999),(227,'music_admin_main_manage','music','Manage Music','','{\"route\":\"admin_default\",\"module\":\"music\",\"controller\":\"manage\"}','music_admin_main','',1,0,1),(228,'music_admin_main_settings','music','Global Settings','','{\"route\":\"admin_default\",\"module\":\"music\",\"controller\":\"settings\"}','music_admin_main','',1,0,2),(229,'music_admin_main_level','music','Member Level Settings','','{\"route\":\"admin_default\",\"module\":\"music\",\"controller\":\"level\"}','music_admin_main','',1,0,3),(230,'authorization_admin_level_music','music','Music','','{\"route\":\"admin_default\",\"module\":\"music\",\"controller\":\"level\",\"action\":\"index\"}','authorization_admin_level','',1,0,999),(231,'mobi_browse_music','music','Music','','{\"route\":\"music_general\",\"action\":\"browse\"}','mobi_browse','',1,0,10),(232,'core_main_poll','poll','Polls','','{\"route\":\"poll_general\",\"action\":\"browse\"}','core_main','',0,0,5),(233,'core_sitemap_poll','poll','Polls','','{\"route\":\"poll_general\",\"action\":\"browse\"}','core_sitemap','',1,0,5),(234,'poll_main_browse','poll','Browse Polls','Poll_Plugin_Menus::canViewPolls','{\"route\":\"poll_general\",\"action\":\"browse\"}','poll_main','',1,0,1),(235,'poll_main_manage','poll','My Polls','Poll_Plugin_Menus::canCreatePolls','{\"route\":\"poll_general\",\"action\":\"manage\"}','poll_main','',1,0,2),(236,'poll_main_create','poll','Create New Poll','Poll_Plugin_Menus::canCreatePolls','{\"route\":\"poll_general\",\"action\":\"create\"}','poll_main','',1,0,3),(237,'poll_quick_create','poll','Create New Poll','Poll_Plugin_Menus::canCreatePolls','{\"route\":\"poll_general\",\"action\":\"create\",\"class\":\"buttonlink icon_poll_new\"}','poll_quick','',1,0,1),(238,'core_admin_main_plugins_poll','poll','Polls','','{\"route\":\"admin_default\",\"module\":\"poll\",\"controller\":\"manage\"}','core_admin_main_plugins','',1,0,999),(239,'poll_admin_main_manage','poll','Manage Polls','','{\"route\":\"admin_default\",\"module\":\"poll\",\"controller\":\"manage\"}','poll_admin_main','',1,0,1),(240,'poll_admin_main_settings','poll','Global Settings','','{\"route\":\"admin_default\",\"module\":\"poll\",\"controller\":\"settings\"}','poll_admin_main','',1,0,2),(241,'poll_admin_main_level','poll','Member Level Settings','','{\"route\":\"admin_default\",\"module\":\"poll\",\"controller\":\"settings\",\"action\":\"level\"}','poll_admin_main','',1,0,3),(242,'authorization_admin_level_poll','poll','Polls','','{\"route\":\"admin_default\",\"module\":\"poll\",\"controller\":\"settings\",\"action\":\"level\"}','authorization_admin_level','',1,0,999),(243,'mobi_browse_poll','poll','Polls','','{\"route\":\"poll_general\",\"action\":\"browse\"}','mobi_browse','',1,0,6),(244,'core_main_video','video','Videos','','{\"route\":\"video_general\"}','core_main','',1,0,7),(245,'core_sitemap_video','video','Videos','','{\"route\":\"video_general\"}','core_sitemap','',1,0,7),(246,'core_admin_main_plugins_video','video','Videos','','{\"route\":\"admin_default\",\"module\":\"video\",\"controller\":\"manage\"}','core_admin_main_plugins','',1,0,999),(247,'video_main_browse','video','Browse Videos','','{\"route\":\"video_general\"}','video_main','',1,0,1),(248,'video_main_manage','video','My Videos','Video_Plugin_Menus','{\"route\":\"video_general\",\"action\":\"manage\"}','video_main','',1,0,2),(249,'video_main_create','video','Post New Video','Video_Plugin_Menus','{\"route\":\"video_general\",\"action\":\"create\"}','video_main','',1,0,3),(250,'video_quick_create','video','Post New Video','Video_Plugin_Menus::canCreateVideos','{\"route\":\"video_general\",\"action\":\"create\",\"class\":\"buttonlink icon_video_new\"}','video_quick','',1,0,1),(251,'video_admin_main_manage','video','Manage Videos','','{\"route\":\"admin_default\",\"module\":\"video\",\"controller\":\"manage\"}','video_admin_main','',1,0,1),(252,'video_admin_main_utility','video','Video Utilities','','{\"route\":\"admin_default\",\"module\":\"video\",\"controller\":\"settings\",\"action\":\"utility\"}','video_admin_main','',1,0,2),(253,'video_admin_main_settings','video','Global Settings','','{\"route\":\"admin_default\",\"module\":\"video\",\"controller\":\"settings\"}','video_admin_main','',1,0,3),(254,'video_admin_main_level','video','Member Level Settings','','{\"route\":\"admin_default\",\"module\":\"video\",\"controller\":\"settings\",\"action\":\"level\"}','video_admin_main','',1,0,4),(255,'video_admin_main_categories','video','Categories','','{\"route\":\"admin_default\",\"module\":\"video\",\"controller\":\"settings\",\"action\":\"categories\"}','video_admin_main','',1,0,5),(256,'authorization_admin_level_video','video','Videos','','{\"route\":\"admin_default\",\"module\":\"video\",\"controller\":\"settings\",\"action\":\"level\"}','authorization_admin_level','',1,0,999),(257,'mobi_browse_video','video','Videos','','{\"route\":\"video_general\"}','mobi_browse','',1,0,9),(258,'core_admin_main_plugins_zephyrtheme','zephyrtheme','Zephyr Theme Options','','{\"route\":\"admin_default\",\"module\":\"zephyrtheme\",\"controller\":\"general\"}','core_admin_main_layout','',1,0,999),(259,'zephyr_admin_main_general','zephyrtheme','General','','{\"route\":\"admin_default\",\"module\":\"zephyrtheme\",\"controller\":\"general\"}','zephyr_admin_main','',1,0,1),(260,'zephyr_admin_main_landing','zephyrtheme','Landing Page','','{\"route\":\"admin_default\",\"module\":\"zephyrtheme\",\"controller\":\"landingpage\"}','zephyr_admin_main','',1,0,2),(261,'zephyr_admin_main_header','zephyrtheme','Header','','{\"route\":\"admin_default\",\"module\":\"zephyrtheme\",\"controller\":\"header\"}','zephyr_admin_main','',1,0,3),(262,'zephyr_admin_main_footer','zephyrtheme','Footer','','{\"route\":\"admin_default\",\"module\":\"zephyrtheme\",\"controller\":\"footer\"}','zephyr_admin_main','',1,0,4),(263,'zephyr_admin_main_styling','zephyrtheme','Styling','','{\"route\":\"admin_default\",\"module\":\"zephyrtheme\",\"controller\":\"styling\"}','zephyr_admin_main','',1,0,5),(264,'zephyr_admin_main_typography','zephyrtheme','Typography','','{\"route\":\"admin_default\",\"module\":\"zephyrtheme\",\"controller\":\"typography\"}','zephyr_admin_main','',1,0,6),(265,'core_admin_main_plugins_hecore','hecore','Hire-Experts','','{\"route\":\"admin_default\",\"module\":\"hecore\",\"controller\":\"index\"}','core_admin_main_plugins','',1,0,887),(266,'hecore_admin_main_settings','hecore','hecore_Global Settings','','{\"route\":\"admin_default\",\"module\":\"hecore\",\"controller\":\"settings\"}','hecore_admin_main','',1,0,2),(267,'hecore_admin_main_plugins','hecore','hecore_Plugins','','{\"route\":\"admin_default\",\"module\":\"hecore\",\"controller\":\"index\"}','hecore_admin_main','',1,0,3),(268,'hecore_admin_main_featureds','hecore','hecore_Featured Members','','{\"route\":\"admin_default\",\"module\":\"hecore\",\"controller\":\"featureds\"}','hecore_admin_main','',1,0,1),(269,'user_edit_interests','like','like_Profile Interests','Like_Plugin_Menus','{\"route\":\"like_interests\",\"action\":\"index\"}','user_edit','',1,0,4),(270,'store_product_profile_promote','like','LIKE_PromoteProduct','Like_Plugin_Menus','','store_product_profile','',1,0,2),(271,'core_admin_main_plugins_like','like','HE - Like','','{\"route\":\"admin_default\",\"module\":\"like\",\"controller\":\"settings\"}','core_admin_main_plugins','',1,0,888),(272,'like_admin_main_level','like','Level Settings','','{\"route\":\"admin_default\",\"module\":\"like\",\"controller\":\"level\"}','like_admin_main','',1,0,2),(273,'like_admin_main_settings','like','Settings','','{\"route\":\"admin_default\",\"module\":\"like\",\"controller\":\"settings\"}','like_admin_main','',1,0,3),(274,'like_admin_main_faq','like','FAQ','','{\"route\":\"admin_default\",\"module\":\"like\",\"controller\":\"faq\"}','like_admin_main','',1,0,4),(275,'donation_main_browse_charity','donation','Charities','Donation_Plugin_Menus','{\"route\":\"donation_charity_browse\"}','donation_main','',1,0,1),(276,'donation_main_browse_project','donation','Projects','Donation_Plugin_Menus','{\"route\":\"donation_project_browse\"}','donation_main','',1,0,2),(277,'donation_main_browse_fundraise','donation','Fundraisings','Donation_Plugin_Menus','{\"route\":\"donation_fundraise_browse\"}','donation_main','',1,0,3),(278,'donation_main_manage_donations','donation','My Donations','Donation_Plugin_Menus','{\"route\":\"donation_manage_donations\"}','donation_main','',1,0,4),(279,'core_admin_main_plugins_donation','donation','HE - Donation','','{\"route\":\"admin_default\",\"module\":\"donation\", \"controller\":\"donations\"}','core_admin_main_plugins','',1,0,888),(280,'donation_admin_main_donations','donation','DONATION_Donations','','{\"route\":\"admin_default\",\"module\":\"donation\", \"controller\":\"donations\"}','donation_admin_main','',1,0,1),(281,'donation_profile_edit','donation','Donation Edit','Donation_Plugin_Menus','','donation_profile',NULL,1,0,1),(282,'donation_profile_delete','donation','Donation Delete','Donation_Plugin_Menus','','donation_profile','',1,0,4),(283,'donation_profile_share','donation','Donation Share','Donation_Plugin_Menus','','donation_profile','',1,0,2),(284,'donation_profile_promote','donation','Donation Promote','Donation_Plugin_Menus','','donation_profile',NULL,1,0,3),(285,'donation_profile_statistics','donation','DONATION_Profile_statistic','Donation_Plugin_Menus','','donation_profile','',1,0,5),(286,'donation_profile_donation','donation','Back to Donations','Donation_Plugin_Menus','','donation_profile','',1,0,999),(287,'donation_profile_fundraise','donation','Raise Money for Us','Donation_Plugin_Menus','','donation_profile','',1,0,0),(288,'donation_profile_suggest','donation','Suggest To Friends','Donation_Plugin_Menus','','donation_profile',NULL,1,0,999),(289,'donation_quick_create_charity','donation','Create New Charity','Donation_Plugin_Menus','{\"route\":\"donation_extended\",\"controller\":\"charity\",\"action\":\"create\",\"class\":\"buttonlink icon_donation_new\"}','donation_quick',NULL,1,0,999),(290,'donation_quick_create_project','donation','Create New Project','Donation_Plugin_Menus','{\"route\":\"donation_extended\",\"controller\":\"project\",\"action\":\"create\",\"class\":\"buttonlink icon_donation_new\"}','donation_quick',NULL,1,0,999),(291,'donation_page_browse_charity','donation','Charity','Donation_Plugin_Menus','','donation_page',NULL,1,0,1),(292,'donation_page_browse_project','donation','Projects','Donation_Plugin_Menus','','donation_page',NULL,1,0,2),(293,'donation_admin_main_categories','donation','Categories',NULL,'{\"route\":\"admin_default\",\"module\":\"donation\",\"controller\":\"category\"}','donation_admin_main',NULL,1,0,2),(294,'donation_admin_main_global','donation','DONATION_Global Settings',NULL,'{\"route\":\"admin_default\",\"module\":\"donation\",\"controller\":\"global\"}','donation_admin_main',NULL,1,0,3),(295,'donation_admin_main_level','donation','DONATION_Level Settings',NULL,'{\"route\":\"admin_default\",\"module\":\"donation\",\"controller\":\"level\"}','donation_admin_main',NULL,1,0,4),(296,'donation_profile_fininfo','donation','Edit Financial Information','Donation_Plugin_Menus','','donation_profile',NULL,1,0,6),(297,'donation_admin_main_statistics','donation','Statistics',NULL,'{\"route\":\"admin_default\",\"module\":\"donation\",\"controller\":\"statistics\"}','donation_admin_main',NULL,1,0,3),(298,'core_main_donation','donation','Donations','','{\"route\":\"donation_charity_browse\"}','core_main','',1,0,999);
/*!40000 ALTER TABLE `engine4_core_menuitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_menus`
--

DROP TABLE IF EXISTS `engine4_core_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_menus` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `type` enum('standard','hidden','custom') CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'standard',
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `order` smallint(3) NOT NULL DEFAULT '999',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `order` (`order`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_menus`
--

LOCK TABLES `engine4_core_menus` WRITE;
/*!40000 ALTER TABLE `engine4_core_menus` DISABLE KEYS */;
INSERT INTO `engine4_core_menus` (`id`, `name`, `type`, `title`, `order`) VALUES (1,'core_main','standard','Main Navigation Menu',1),(2,'core_mini','standard','Mini Navigation Menu',2),(3,'core_footer','standard','Footer Menu',3),(4,'core_sitemap','standard','Sitemap',4),(5,'user_home','standard','Member Home Quick Links Menu',999),(6,'user_profile','standard','Member Profile Options Menu',999),(7,'user_edit','standard','Member Edit Profile Navigation Menu',999),(8,'user_settings','standard','Member Settings Navigation Menu',999),(9,'messages_main','standard','Messages Main Navigation Menu',999),(10,'album_main','standard','Album Main Navigation Menu',999),(11,'album_quick','standard','Album Quick Navigation Menu',999),(12,'blog_main','standard','Blog Main Navigation Menu',999),(13,'blog_quick','standard','Blog Quick Navigation Menu',999),(14,'blog_gutter','standard','Blog Gutter Navigation Menu',999),(15,'classified_main','standard','Classified Main Navigation Menu',999),(16,'classified_quick','standard','Classified Quick Navigation Menu',999),(17,'event_main','standard','Event Main Navigation Menu',999),(18,'event_profile','standard','Event Profile Options Menu',999),(19,'group_main','standard','Group Main Navigation Menu',999),(20,'group_profile','standard','Group Profile Options Menu',999),(21,'mobi_footer','standard','Mobile Footer Menu',999),(22,'mobi_main','standard','Mobile Main Menu',999),(23,'mobi_profile','standard','Mobile Profile Options Menu',999),(24,'mobi_browse','standard','Mobile Browse Page Menu',999),(25,'music_main','standard','Music Main Navigation Menu',999),(26,'music_quick','standard','Music Quick Navigation Menu',999),(27,'poll_main','standard','Poll Main Navigation Menu',999),(28,'poll_quick','standard','Poll Quick Navigation Menu',999),(29,'video_main','standard','Video Main Navigation Menu',999),(30,'donation_main','standard','Donation Main Navigation Menu',999),(31,'donation_quick','standard','Donation Quick Navigation Menu',999);
/*!40000 ALTER TABLE `engine4_core_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_migrations`
--

DROP TABLE IF EXISTS `engine4_core_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_migrations` (
  `package` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `current` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`package`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_migrations`
--

LOCK TABLES `engine4_core_migrations` WRITE;
/*!40000 ALTER TABLE `engine4_core_migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_modules`
--

DROP TABLE IF EXISTS `engine4_core_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_modules` (
  `name` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `version` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `type` enum('core','standard','extra') CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'extra',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_modules`
--

LOCK TABLES `engine4_core_modules` WRITE;
/*!40000 ALTER TABLE `engine4_core_modules` DISABLE KEYS */;
INSERT INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`, `type`) VALUES ('activity','Activity','Activity','4.8.5',1,'core'),('album','Albums','Albums','4.8.6',1,'extra'),('announcement','Announcements','Announcements','4.8.0',1,'standard'),('authorization','Authorization','Authorization','4.7.0',1,'core'),('blog','Blogs','Blogs','4.8.6',1,'extra'),('chat','Chat','Chat','4.8.2',1,'extra'),('classified','Classifieds','Classifieds','4.7.0',1,'extra'),('core','Core','Core','4.8.6',1,'core'),('donation','Donation','Donation Plugin','4.2.3p2',1,'extra'),('event','Events','Events','4.8.6',1,'extra'),('fields','Fields','Fields','4.8.6',1,'core'),('forum','Forum','Forum','4.8.5',1,'extra'),('group','Groups','Groups','4.8.6',1,'extra'),('hecore','Hire-Experts Core Module','Hire-Experts Core Module','4.2.2',1,'extra'),('invite','Invite','Invite','4.8.2',1,'standard'),('like','Like','Like Plugin','4.2.3p1',1,'extra'),('messages','Messages','Messages','4.8.5',1,'standard'),('mobi','Mobi','Mobile','4.8.5',1,'extra'),('music','Music','Music','4.8.5',1,'extra'),('network','Networks','Networks','4.8.6',1,'standard'),('payment','Payment','Payment','4.8.1',1,'standard'),('poll','Polls','Polls','4.8.0',1,'extra'),('storage','Storage','Storage','4.8.5',1,'core'),('user','Members','Members','4.8.6',1,'core'),('video','Videos','Videos','4.8.5p1',1,'extra'),('zephyrtheme','Zephyr Theme','Options for Zephyr Theme','1.1.3',1,'extra');
/*!40000 ALTER TABLE `engine4_core_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_nodes`
--

DROP TABLE IF EXISTS `engine4_core_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_nodes` (
  `node_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `signature` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varbinary(16) NOT NULL,
  `first_seen` datetime NOT NULL,
  `last_seen` datetime NOT NULL,
  PRIMARY KEY (`node_id`),
  UNIQUE KEY `signature` (`signature`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_nodes`
--

LOCK TABLES `engine4_core_nodes` WRITE;
/*!40000 ALTER TABLE `engine4_core_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_pages`
--

DROP TABLE IF EXISTS `engine4_core_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_pages` (
  `page_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `displayname` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `url` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL,
  `custom` tinyint(1) NOT NULL DEFAULT '1',
  `fragment` tinyint(1) NOT NULL DEFAULT '0',
  `layout` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `levels` text COLLATE utf8_unicode_ci,
  `provides` text COLLATE utf8_unicode_ci,
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `search` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_pages`
--

LOCK TABLES `engine4_core_pages` WRITE;
/*!40000 ALTER TABLE `engine4_core_pages` DISABLE KEYS */;
INSERT INTO `engine4_core_pages` (`page_id`, `name`, `displayname`, `url`, `title`, `description`, `keywords`, `custom`, `fragment`, `layout`, `levels`, `provides`, `view_count`, `search`) VALUES (1,'header','Site Header',NULL,'','','',0,1,'',NULL,'header-footer',0,0),(2,'footer','Site Footer',NULL,'','','',0,1,'',NULL,'header-footer',0,0),(3,'core_index_index','Home Page',NULL,'Give Social Home','This is your site\'s landing page.','',0,0,'default',NULL,'no-viewer;no-subject',0,0),(4,'user_index_home','Member Home Page',NULL,'Member Home Page','This is the home page for members.','',0,0,'default',NULL,'viewer;no-subject',0,0),(5,'user_profile_index','Member Profile',NULL,'Member Profile','This is a member\'s profile.','',0,0,'',NULL,'subject=user',0,0),(6,'core_help_contact','Contact Page',NULL,'Contact Us','This is the contact page','',0,0,'',NULL,'no-viewer;no-subject',0,0),(7,'core_help_privacy','Privacy Page',NULL,'Privacy Policy','This is the privacy policy page','',0,0,'',NULL,'no-viewer;no-subject',0,0),(8,'core_help_terms','Terms of Service Page',NULL,'Terms of Service','This is the terms of service page','',0,0,'',NULL,'no-viewer;no-subject',0,0),(9,'core_error_requireuser','Sign-in Required Page',NULL,'Sign-in Required','','',0,0,'',NULL,NULL,0,0),(10,'core_search_index','Search Page',NULL,'Searc','','',0,0,'',NULL,NULL,0,0),(11,'user_auth_login','Sign-in Page',NULL,'Sign-in','This is the site sign-in page.','',0,0,'',NULL,NULL,0,0),(12,'user_signup_index','Sign-up Page',NULL,'Sign-up','This is the site sign-up page.','',0,0,'',NULL,NULL,0,0),(13,'user_auth_forgot','Forgot Password Page',NULL,'Forgot Password','This is the site forgot password page.','',0,0,'',NULL,NULL,0,0),(14,'user_settings_general','User General Settings Page',NULL,'General','This page is the user general settings page.','',0,0,'',NULL,NULL,0,0),(15,'user_settings_privacy','User Privacy Settings Page',NULL,'Privacy','This page is the user privacy settings page.','',0,0,'',NULL,NULL,0,0),(16,'user_settings_network','User Networks Settings Page',NULL,'Networks','This page is the user networks settings page.','',0,0,'',NULL,NULL,0,0),(17,'user_settings_notifications','User Notifications Settings Page',NULL,'Notifications','This page is the user notification settings page.','',0,0,'',NULL,NULL,0,0),(18,'user_settings_password','User Change Password Settings Page',NULL,'Change Password','This page is the change password page.','',0,0,'',NULL,NULL,0,0),(19,'user_settings_delete','User Delete Account Settings Page',NULL,'Delete Account','This page is the delete accout page.','',0,0,'',NULL,NULL,0,0),(20,'album_photo_view','Album Photo View Page',NULL,'Album Photo View','This page displays an album\'s photo.','',0,0,'',NULL,'subject=album_photo',0,0),(21,'album_album_view','Album View Page',NULL,'Album View','This page displays an album\'s photos.','',0,0,'',NULL,'subject=album',0,0),(22,'album_index_browse','Album Browse Page',NULL,'Album Browse','This page lists album entries.','',0,0,'',NULL,NULL,0,0),(23,'album_index_upload','Album Create Page',NULL,'Add New Photos','This page is the album create page.','',0,0,'',NULL,NULL,0,0),(24,'album_index_manage','Album Manage Page',NULL,'My Albums','This page lists album a user\'s albums.','',0,0,'',NULL,NULL,0,0),(25,'blog_index_list','Blog List Page',NULL,'Blog List','This page lists a member\'s blog entries.','',0,0,'',NULL,'subject=user',0,0),(26,'blog_index_view','Blog View Page',NULL,'Blog View','This page displays a blog entry.','',0,0,'',NULL,'subject=blog',0,0),(27,'blog_index_index','Blog Browse Page',NULL,'Blog Browse','This page lists blog entries.','',0,0,'',NULL,NULL,0,0),(28,'blog_index_create','Blog Create Page',NULL,'Write New Entry','This page is the blog create page.','',0,0,'',NULL,NULL,0,0),(29,'blog_index_manage','Blog Manage Page',NULL,'My Entries','This page lists a user\'s blog entries.','',0,0,'',NULL,NULL,0,0),(30,'chat_index_index','Chat Main Page',NULL,'Chat','This is the chat room.','',0,0,'',NULL,NULL,0,0),(31,'classified_index_index','Classified Browse Page',NULL,'Classified Browse','This page lists classifieds.','',0,0,'',NULL,NULL,0,0),(32,'classified_index_view','Classified View Page',NULL,'View Classified','This is the view page for a classified.','',0,0,'',NULL,'subject=classified',0,0),(33,'classified_index_create','Classified Create Page',NULL,'Post a New Listing','This page is the classified create page.','',0,0,'',NULL,NULL,0,0),(34,'classified_index_manage','Classified Manage Page',NULL,'My Listings','This page lists a user\'s classifieds.','',0,0,'',NULL,NULL,0,0),(35,'mobi_event_profile','Mobile Event Profile',NULL,'Mobile Event Profile','This is the mobile verison of an event profile.','',0,0,'',NULL,NULL,0,0),(36,'event_profile_index','Event Profile',NULL,'Event Profile','This is the profile for an event.','',0,0,'',NULL,'subject=event',0,0),(37,'event_index_browse','Event Browse Page',NULL,'Event Browse','This page lists events.','',0,0,'',NULL,NULL,0,0),(38,'event_index_create','Event Create Page',NULL,'Event Create','This page allows users to create events.','',0,0,'',NULL,NULL,0,0),(39,'event_index_manage','Event Manage Page',NULL,'My Events','This page lists a user\'s events.','',0,0,'',NULL,NULL,0,0),(40,'forum_index_index','Forum Main Page',NULL,'Forum Main','This is the main forum page.','',0,0,'',NULL,NULL,0,0),(41,'forum_forum_view','Forum View Page',NULL,'Forum View','This is the view forum page.','',0,0,'',NULL,NULL,0,0),(42,'forum_forum_topic-create','Forum Topic Create Page',NULL,'Post Topic','This is the forum topic create page.','',0,0,'',NULL,NULL,0,0),(43,'group_profile_index','Group Profile',NULL,'Group Profile','This is the profile for an group.','',0,0,'',NULL,'subject=group',0,0),(44,'mobi_group_profile','Mobile Group Profile',NULL,'Mobile Group Profile','This is the mobile verison of a group profile.','',0,0,'',NULL,NULL,0,0),(45,'group_index_browse','Group Browse Page',NULL,'Group Browse','This page lists groups.','',0,0,'',NULL,NULL,0,0),(46,'group_index_create','Group Create Page',NULL,'Group Create','This page allows users to create groups.','',0,0,'',NULL,NULL,0,0),(47,'group_index_manage','Group Manage Page',NULL,'My Groups','This page lists a user\'s groups.','',0,0,'',NULL,NULL,0,0),(48,'invite_index_index','Invite Page',NULL,'Invite','','',0,0,'',NULL,NULL,0,0),(49,'messages_messages_compose','Messages Compose Page',NULL,'Compose','','',0,0,'',NULL,NULL,0,0),(50,'messages_messages_inbox','Messages Inbox Page',NULL,'Inbox','','',0,0,'',NULL,NULL,0,0),(51,'messages_messages_outbox','Messages Outbox Page',NULL,'Inbox','','',0,0,'',NULL,NULL,0,0),(52,'messages_messages_search','Messages Search Page',NULL,'Search','','',0,0,'',NULL,NULL,0,0),(53,'messages_messages_view','Messages View Page',NULL,'My Message','','',0,0,'',NULL,NULL,0,0),(54,'header_mobi','Mobile Site Header',NULL,'Mobile Site Header','This is the mobile site header.','',0,1,'',NULL,NULL,0,0),(55,'footer_mobi','Mobile Site Footer',NULL,'Mobile Site Footer','This is the mobile site footer.','',0,1,'',NULL,NULL,0,0),(56,'mobi_index_index','Mobile Home Page',NULL,'Mobile Home Page','This is the mobile homepage.','',0,0,'default',NULL,NULL,0,0),(57,'mobi_index_userhome','Mobile Member Home Page',NULL,'Mobile Member Home Page','This is the mobile member homepage.','',0,0,'',NULL,NULL,0,0),(58,'mobi_index_profile','Mobile Member Profile',NULL,'Mobile Member Profile','This is the mobile verison of a member profile.','',0,0,'',NULL,NULL,0,0),(59,'music_index_browse','Music Browse Page',NULL,'Music Browse','This page lists music.','',0,0,'',NULL,NULL,0,0),(60,'music_playlist_view','Music Playlist View Page',NULL,'Music View','This page displays a playlist.','',0,0,'',NULL,NULL,0,0),(61,'music_index_create','Music Create Page',NULL,'Upload Music','This page is the music create page.','',0,0,'',NULL,NULL,0,0),(62,'music_index_manage','Music Manage Page',NULL,'My Music','This page is the music manage page.','',0,0,'',NULL,NULL,0,0),(63,'poll_index_browse','Poll Browse Page',NULL,'Poll Browse','This page lists polls.','',0,0,'',NULL,NULL,0,0),(64,'poll_poll_view','Poll View Page',NULL,'View Poll','This is the view page for a poll.','',0,0,'',NULL,'subject=poll',0,0),(65,'poll_index_create','Poll Create Page',NULL,'Create New Pll','This page is the poll create page.','',0,0,'',NULL,NULL,0,0),(66,'poll_index_manage','Poll Manage Page',NULL,'My Poll','This page lists a user\'s polls.','',0,0,'',NULL,NULL,0,0),(67,'video_index_view','Video View Page',NULL,'View Video','This is the view page for a video.','',0,0,'',NULL,'subject=video',0,0),(68,'video_index_browse','Video Browse Page',NULL,'Video Browse','This page lists videos.','',0,0,'',NULL,NULL,0,0),(69,'video_index_create','Video Create Page',NULL,'Video Create','This page allows video to be added.','',0,0,'',NULL,NULL,0,0),(70,'video_index_manage','Video Manage Page',NULL,'My Videos','This page lists a user\'s videos.','',0,0,'',NULL,NULL,0,0),(72,'donation_index_browse','Browse Charities',NULL,'Charities','This page displays a charity donations entry','',0,0,'','(NULL)','(NULL)',0,0),(73,'donation_index_view','Donation Profile Page',NULL,'Donation Profile','This is view pafe for donation.','',0,0,'',NULL,NULL,0,0),(74,'donation_donation_donate','Making Donation','(NULL)','Making Donation','Making donation page','',0,0,'','(NULL)','(NULL)',0,0),(75,'donation_project_browse','Browse Projects',NULL,'Projects','This page displays a project donations entry','',0,0,'','(NULL)','(NULL)',0,0),(76,'donation_fundraise_browse','Browse Fundraisers',NULL,'Fundraising','This page displays a fundraise donations entry','',0,0,'','(NULL)','(NULL)',0,0),(77,'donation_fundraise_view','Fundraising Profile Page','NULL','Fundraising Profile','This is view pafe for fundraising.','',1,0,'',NULL,NULL,0,0);
/*!40000 ALTER TABLE `engine4_core_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_processes`
--

DROP TABLE IF EXISTS `engine4_core_processes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_processes` (
  `pid` int(10) unsigned NOT NULL,
  `parent_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `system_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `started` int(10) unsigned NOT NULL,
  `timeout` mediumint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_processes`
--

LOCK TABLES `engine4_core_processes` WRITE;
/*!40000 ALTER TABLE `engine4_core_processes` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_processes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_referrers`
--

DROP TABLE IF EXISTS `engine4_core_referrers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_referrers` (
  `host` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `query` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `value` int(11) unsigned NOT NULL,
  PRIMARY KEY (`host`,`path`,`query`),
  KEY `value` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_referrers`
--

LOCK TABLES `engine4_core_referrers` WRITE;
/*!40000 ALTER TABLE `engine4_core_referrers` DISABLE KEYS */;
INSERT INTO `engine4_core_referrers` (`host`, `path`, `query`, `value`) VALUES ('google.com','/search','',1),('google.com','/url','q=http%3a%2f%2ftest.grsband.com&sa=d&sntz=1&usg=afqjcnf5wkj_vgffgfz_ww1sv4ey9oermg',1);
/*!40000 ALTER TABLE `engine4_core_referrers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_reports`
--

DROP TABLE IF EXISTS `engine4_core_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_reports` (
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `subject_type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `subject_id` int(11) NOT NULL,
  `creation_date` datetime NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`report_id`),
  KEY `category` (`category`),
  KEY `user_id` (`user_id`),
  KEY `read` (`read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_reports`
--

LOCK TABLES `engine4_core_reports` WRITE;
/*!40000 ALTER TABLE `engine4_core_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_routes`
--

DROP TABLE IF EXISTS `engine4_core_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_routes` (
  `name` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `config` text COLLATE utf8_unicode_ci NOT NULL,
  `order` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`),
  KEY `order` (`order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_routes`
--

LOCK TABLES `engine4_core_routes` WRITE;
/*!40000 ALTER TABLE `engine4_core_routes` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_search`
--

DROP TABLE IF EXISTS `engine4_core_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_search` (
  `type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hidden` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`type`,`id`),
  FULLTEXT KEY `LOOKUP` (`title`,`description`,`keywords`,`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_search`
--

LOCK TABLES `engine4_core_search` WRITE;
/*!40000 ALTER TABLE `engine4_core_search` DISABLE KEYS */;
INSERT INTO `engine4_core_search` (`type`, `id`, `title`, `description`, `keywords`, `hidden`) VALUES ('user',2,'Quintin Evans','','',''),('event',1,'Sample Event','Test','',''),('user',3,'Quintin2 Evans2','','',''),('user',4,'Mike Estes','','',''),('user',1,'Emil Torres','','',''),('album',1,'Profile Photos','','',''),('album_photo',1,'Profile Photo','Me at Crows Nest.','',''),('album_photo',2,'Yunyi','Yunyi and his teddy.','',''),('album_photo',3,'Ollie','Ollie Laying Down.','',''),('album_photo',4,'Cat','Some cat.','',''),('user',5,'Jason Bryant','','',''),('album',2,'Profile Photos','','',''),('album',3,'Profile Photos','','',''),('group',1,'Test','test','',''),('event',2,'test','test','',''),('donation',1,'Test','Testing Again Again','',''),('donation',2,'Project Test','Test Again','','');
/*!40000 ALTER TABLE `engine4_core_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_serviceproviders`
--

DROP TABLE IF EXISTS `engine4_core_serviceproviders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_serviceproviders` (
  `serviceprovider_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `name` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `class` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`serviceprovider_id`),
  UNIQUE KEY `type` (`type`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_serviceproviders`
--

LOCK TABLES `engine4_core_serviceproviders` WRITE;
/*!40000 ALTER TABLE `engine4_core_serviceproviders` DISABLE KEYS */;
INSERT INTO `engine4_core_serviceproviders` (`serviceprovider_id`, `title`, `type`, `name`, `class`, `enabled`) VALUES (1,'MySQL','database','mysql','Engine_ServiceLocator_Plugin_Database_Mysql',1),(2,'PDO MySQL','database','mysql_pdo','Engine_ServiceLocator_Plugin_Database_MysqlPdo',1),(3,'MySQLi','database','mysqli','Engine_ServiceLocator_Plugin_Database_Mysqli',1),(4,'File','cache','file','Engine_ServiceLocator_Plugin_Cache_File',1),(5,'APC','cache','apc','Engine_ServiceLocator_Plugin_Cache_Apc',1),(6,'Memcache','cache','memcached','Engine_ServiceLocator_Plugin_Cache_Memcached',1),(7,'Simple','captcha','image','Engine_ServiceLocator_Plugin_Captcha_Image',1),(8,'ReCaptcha','captcha','recaptcha','Engine_ServiceLocator_Plugin_Captcha_Recaptcha',1),(9,'SMTP','mail','smtp','Engine_ServiceLocator_Plugin_Mail_Smtp',1),(10,'Sendmail','mail','sendmail','Engine_ServiceLocator_Plugin_Mail_Sendmail',1),(11,'GD','image','gd','Engine_ServiceLocator_Plugin_Image_Gd',1),(12,'Imagick','image','imagick','Engine_ServiceLocator_Plugin_Image_Imagick',1),(13,'Akismet','akismet','standard','Engine_ServiceLocator_Plugin_Akismet',1);
/*!40000 ALTER TABLE `engine4_core_serviceproviders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_services`
--

DROP TABLE IF EXISTS `engine4_core_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_services` (
  `service_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `name` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `profile` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'default',
  `config` text COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`service_id`),
  UNIQUE KEY `type` (`type`,`profile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_services`
--

LOCK TABLES `engine4_core_services` WRITE;
/*!40000 ALTER TABLE `engine4_core_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_servicetypes`
--

DROP TABLE IF EXISTS `engine4_core_servicetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_servicetypes` (
  `servicetype_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `interface` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`servicetype_id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_servicetypes`
--

LOCK TABLES `engine4_core_servicetypes` WRITE;
/*!40000 ALTER TABLE `engine4_core_servicetypes` DISABLE KEYS */;
INSERT INTO `engine4_core_servicetypes` (`servicetype_id`, `title`, `type`, `interface`, `enabled`) VALUES (1,'Database','database','Zend_Db_Adapter_Abstract',1),(2,'Cache','cache','Zend_Cache_Backend',1),(3,'Captcha','captcha','Zend_Captcha_Adapter',1),(4,'Mail Transport','mail','Zend_Mail_Transport_Abstract',1),(5,'Image','image','Engine_Image_Adapter_Abstract',1),(6,'Akismet','akismet','Zend_Service_Akismet',1);
/*!40000 ALTER TABLE `engine4_core_servicetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_session`
--

DROP TABLE IF EXISTS `engine4_core_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_session` (
  `id` char(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `modified` int(11) DEFAULT NULL,
  `lifetime` int(11) DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_session`
--

LOCK TABLES `engine4_core_session` WRITE;
/*!40000 ALTER TABLE `engine4_core_session` DISABLE KEYS */;
INSERT INTO `engine4_core_session` (`id`, `modified`, `lifetime`, `data`, `user_id`) VALUES ('0682aa88646a50f87c841f1dc3a4b6f2',1414809482,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('0d7cfa7f312883bbadba7e7f196f34c1',1414771269,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('0f544fa1d1107240157b1ee4203b0b55',1414734849,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('17222be43f331f34fbdb97eb05ad822c',1414791132,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('18e5b9743d5460e334fff01735f59189',1414790633,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('195844e391305257e9c0bdba9525d7dd',1414790772,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('2485f8267f48c4ed94c4a27f1a0e704d',1414733203,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('2748efcb7737215b07f57c0cf5b1a6a0',1414735836,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('2db03bd5fdc8688f1da8a8c33d1ffd6b',1414771390,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('2e9d6ca9c8fea4171cc748a3af91b457',1414783374,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('34a52ce3275e5c5507a763c6fcb0c246',1414774487,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('3677faeb1593e755931476eadb4067bf',1414809756,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('3992afb5352b27c2c0ce90fd9e176cb3',1414758098,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('39de02961c7c54ded74d74ecdc63e37c',1414735898,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('3ee2c87a9b478806ded8a079e5221c42',1414782813,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('4332a2d861c598f978ee45730982436b',1414783254,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('46c13b70745c13140bba78d7ca8629e0',1414735772,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('46f9b6098ec554af45b1e67a5cfec1d9',1414774613,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('4af69fa121106088bc042bfc4eb83df0',1414733492,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('52080bb4430d8b0db947fdb7d2136304',1414790574,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('55d8dd3137bf0c950aa06b41b081c2d9',1414783132,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('62e482245a1d042fbfd2077b075cb024',1414783494,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('6fc0ef8338d236b1de9c227d5e872661',1414791252,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('7062fb3be982421a0c2aa504e47f292d',1414733326,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('834393dbe1e6191bd25e31223448ca4e',1414771144,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('89c4fd2ae828949ba037bba2e39d95cf',1414790892,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('929536aba913b729201c5b4bde8d45fe',1414734743,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('99921ca62e1b803bd096fe62d8846713',1414783734,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('a56a3a978075eafde0c1767763e9b2ef',1414782878,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('adf766c9534e3a6a6cdab674570c3b56',1414753458,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('b3ccc3a0795700a3bab7933156f9a796',1414753827,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('be256be11e89d9727407649c1f87cfe2',1414782851,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}redirectURL|s:12:\"/favicon.ico\";',NULL),('c0d0f943d4b3bca61b15da64f660f38c',1414783106,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}ActivityFormToken|a:1:{s:5:\"token\";s:32:\"c20dccb93b4ae39bb9178d61f281c6ec\";}redirectURL|s:6:\"/login\";Zend_Auth|a:1:{s:7:\"storage\";s:1:\"5\";}login_id|s:2:\"12\";twitter_lock|i:5;twitter_uid|b:0;',5),('c5d9502205fd4100eb2f4b5cdec53444',1414774824,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('c7760b2789095b646a3ebeecd9e3f495',1414757977,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('d4ca31bdc9df3ebb40f9d3aa510024ed',1414792872,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}redirectURL|s:6:\"/login\";Zend_Auth|a:1:{s:7:\"storage\";s:1:\"5\";}login_id|s:2:\"13\";ActivityFormToken|a:1:{s:5:\"token\";s:32:\"5839ef49fc7697ede15fff0742bff27b\";}twitter_lock|i:5;twitter_uid|b:0;',5),('d757cb033be03fc6809e34bdd9f35070',1414809805,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}redirectURL|s:6:\"/login\";Zend_Auth|a:1:{s:7:\"storage\";s:1:\"5\";}login_id|s:2:\"14\";ActivityFormToken|a:1:{s:5:\"token\";s:32:\"fd2e30db5b19ebb2460a8e04a9701471\";}twitter_lock|i:5;twitter_uid|b:0;',5),('d7f89eaf65a5353afce87b9dccec0f57',1414774826,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}redirectURL|s:5:\"/?c=5\";User_Plugin_Signup_Account|a:2:{s:6:\"active\";b:1;s:4:\"data\";N;}User_Plugin_Signup_Fields|a:1:{s:6:\"active\";b:1;}User_Plugin_Signup_Photo|a:1:{s:6:\"active\";b:1;}',NULL),('dbed2257814cbfa576e4a78a7a74d694',1414809635,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('df322cab4937598e6f0e4ddab448e043',1414783035,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('e827a7b8cbc66d8b10442524eeab8879',1414791012,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('eb593c6d24a6ea8a1f49e56237ba09dc',1414783614,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL),('f2ba80fa9a64ec89087d4250a48ba97c',1414733265,86400,'mobile|a:1:{s:6:\"mobile\";b:0;}',NULL);
/*!40000 ALTER TABLE `engine4_core_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_settings`
--

DROP TABLE IF EXISTS `engine4_core_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_settings` (
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_settings`
--

LOCK TABLES `engine4_core_settings` WRITE;
/*!40000 ALTER TABLE `engine4_core_settings` DISABLE KEYS */;
INSERT INTO `engine4_core_settings` (`name`, `value`) VALUES ('activity.content','everyone'),('activity.disallowed','N'),('activity.filter','1'),('activity.length','15'),('activity.liveupdate','120000'),('activity.publish','1'),('activity.userdelete','1'),('activity.userlength','5'),('chat.general.delay','5000'),('chat.im.privacy','friends'),('classified.currency','$'),('core.admin.mode','none'),('core.admin.password',''),('core.admin.reauthenticate','0'),('core.admin.timeout','600'),('core.analytics.code',''),('core.doctype','XHTML1_STRICT'),('core.facebook.enable','none'),('core.facebook.key',''),('core.facebook.secret',''),('core.general.analytics',''),('core.general.browse','1'),('core.general.commenthtml',''),('core.general.includes',''),('core.general.notificationupdate','120000'),('core.general.portal','1'),('core.general.profile','1'),('core.general.quota','0'),('core.general.search','1'),('core.general.site.description',''),('core.general.site.keywords',''),('core.general.site.title','Give Social'),('core.general.staticBaseUrl',''),('core.license.email','email@domain.com'),('core.license.key','0060-7443-6180-0336'),('core.license.statistics','1'),('core.locale.locale','auto'),('core.locale.timezone','US/Pacific'),('core.log.adapter','file'),('core.mail.count','25'),('core.mail.enabled','1'),('core.mail.from','email@domain.com'),('core.mail.name','Site Admin'),('core.mail.queueing','1'),('core.secret','3901a272903db494a680dd8446a93c98cf477356'),('core.site.counter','5'),('core.site.creation','2014-10-14 23:27:08'),('core.site.title','Social Network'),('core.spam.censor',''),('core.spam.comment','0'),('core.spam.contact','0'),('core.spam.email.antispam.login','1'),('core.spam.email.antispam.signup','1'),('core.spam.invite','0'),('core.spam.ipbans',''),('core.spam.login','0'),('core.spam.signup','0'),('core.static.baseurl',''),('core.tasks.count','1'),('core.tasks.interval','60'),('core.tasks.jobs','3'),('core.tasks.key','3a15d5ee'),('core.tasks.last','1414809756'),('core.tasks.mode','curl'),('core.tasks.pid',''),('core.tasks.processes','2'),('core.tasks.time','120'),('core.tasks.timeout','900'),('core.thumbnails.icon.height','48'),('core.thumbnails.icon.mode','crop'),('core.thumbnails.icon.width','48'),('core.thumbnails.main.height','720'),('core.thumbnails.main.mode','resize'),('core.thumbnails.main.width','720'),('core.thumbnails.normal.height','160'),('core.thumbnails.normal.mode','resize'),('core.thumbnails.normal.width','140'),('core.thumbnails.profile.height','400'),('core.thumbnails.profile.mode','resize'),('core.thumbnails.profile.width','200'),('core.translate.adapter','csv'),('core.twitter.enable','none'),('core.twitter.key',''),('core.twitter.secret',''),('event.bbcode','1'),('event.html','1'),('forum.bbcode','1'),('forum.forum.pagelength','25'),('forum.html','1'),('forum.public','1'),('forum.topic.pagelength','25'),('group.bbcode','1'),('group.html','1'),('hecore.featured.count','9'),('hecore.module.check.licenses','1414493349'),('invite.allowCustomMessage','1'),('invite.fromEmail',''),('invite.fromName',''),('invite.max','10'),('invite.message','You are being invited to join our social network.'),('invite.subject','Join Us'),('music.playlistsperpage','10'),('payment.benefit','all'),('payment.currency','USD'),('payment.secret','f32c7b5a401e200a23b5a8a7fdd4efc1'),('poll.canchangevote','1'),('poll.maxoptions','15'),('poll.showpiechart','0'),('storage.service.mirrored.counter','0'),('storage.service.mirrored.index','0'),('storage.service.roundrobin.counter','0'),('user.friends.direction','1'),('user.friends.eligible','2'),('user.friends.lists','1'),('user.friends.verification','1'),('user.signup.approve','1'),('user.signup.checkemail','1'),('user.signup.inviteonly','0'),('user.signup.random','0'),('user.signup.terms','1'),('user.signup.username','1'),('user.signup.verifyemail','0'),('user.support.links','1'),('video.embeds','1'),('video.ffmpeg.path',''),('video.jobs','2'),('zephyr.body.bgcolor','#e8ebf2'),('zephyr.body.img',''),('zephyr.body.imgcover','cover'),('zephyr.body.imgfixed','fixed'),('zephyr.body.imgrepeat','repeat'),('zephyr.button.bgcolor','#288d09'),('zephyr.button.color','#ffffff'),('zephyr.color.scheme','color_one'),('zephyr.comment.bgcolor','#f7f8fa'),('zephyr.content.bgcolor','#ffffff'),('zephyr.content.bordercolor','#706b57'),('zephyr.content.style','1'),('zephyr.custom.css',''),('zephyr.feat1.img',''),('zephyr.feat1.link',''),('zephyr.feat1.text',''),('zephyr.feat2.img',''),('zephyr.feat2.link',''),('zephyr.feat2.text',''),('zephyr.feat3.img',''),('zephyr.feat3.link',''),('zephyr.feat3.text',''),('zephyr.feat4.img',''),('zephyr.feat4.link',''),('zephyr.feat4.text',''),('zephyr.feat5.img',''),('zephyr.feat5.link',''),('zephyr.feat5.text',''),('zephyr.feat6.img',''),('zephyr.feat6.link',''),('zephyr.feat6.text',''),('zephyr.font.color','#333333'),('zephyr.font.colorlight','#777777'),('zephyr.font.size','13px'),('zephyr.footer.bgcolor','#2e2e2e'),('zephyr.footer.border','0px'),('zephyr.footer.bordercolor','#000000'),('zephyr.footer.color','#888888'),('zephyr.footer.facebook','https://www.facebook.com/'),('zephyr.footer.flickr',''),('zephyr.footer.google','https://www.google.com/'),('zephyr.footer.gototop','1'),('zephyr.footer.img',''),('zephyr.footer.imgcover','cover'),('zephyr.footer.imgfixed','fixed'),('zephyr.footer.imgrepeat','no-repeat'),('zephyr.footer.instagram',''),('zephyr.footer.linkcolor','#3dcf07'),('zephyr.footer.linkedin','https://www.linkedin.com/'),('zephyr.footer.logged','0'),('zephyr.footer.logo','public/admin/Give Social Small.jpg'),('zephyr.footer.notlogged','0'),('zephyr.footer.pinterest',''),('zephyr.footer.socialicons','1'),('zephyr.footer.style','1'),('zephyr.footer.tumblr',''),('zephyr.footer.twitter','https://www.twitter.com/'),('zephyr.footer.vimeo',''),('zephyr.footer.youtube','https://www.youtube.com/'),('zephyr.google.font','Open Sans'),('zephyr.google.fontfix','Open+Sans'),('zephyr.google.headingsfont','Raleway'),('zephyr.google.headingsfontfix','Raleway'),('zephyr.header.banner',''),('zephyr.header.bgcolor','#ffffff'),('zephyr.header.border','0px'),('zephyr.header.bordercolor','#706b57'),('zephyr.header.editprofile','1'),('zephyr.header.fixed','0'),('zephyr.header.height','52px'),('zephyr.header.icons','1'),('zephyr.header.img',''),('zephyr.header.imgcover','cover'),('zephyr.header.imgfixed','fixed'),('zephyr.header.imgrepeat','no-repeat'),('zephyr.header.layout','1'),('zephyr.header.loginbutton','0'),('zephyr.header.logo','public/admin/Give Social Small.jpg'),('zephyr.header.logout','1'),('zephyr.header.mainmenu','0'),('zephyr.header.mobilemenu','0'),('zephyr.header.searchcolor','#bbbbbb'),('zephyr.header.signupbutton','1'),('zephyr.header.style','1'),('zephyr.header.thumb','1'),('zephyr.headermenu.bgcolor','#f7f7f7'),('zephyr.headermenu.bghover','#f2f2f2'),('zephyr.headermenu.border','transparent'),('zephyr.headermenu.color','#777777'),('zephyr.headermenu.colorhover','#333333'),('zephyr.headings.font','Georgia, serif'),('zephyr.headings.fontweight','400'),('zephyr.headline.color','#333333'),('zephyr.home.bgimg',''),('zephyr.home.commbgimg',''),('zephyr.home.commh1','1'),('zephyr.home.commh2','1'),('zephyr.home.commimg',''),('zephyr.home.commimgshow','1'),('zephyr.home.eltop','10%'),('zephyr.home.h1','1'),('zephyr.home.h2','1'),('zephyr.home.ico.four',''),('zephyr.home.ico.one',''),('zephyr.home.ico.three',''),('zephyr.home.ico.two',''),('zephyr.home.icofour.link',''),('zephyr.home.icoone.link',''),('zephyr.home.icos','0'),('zephyr.home.icosimgs','0'),('zephyr.home.icothree.link',''),('zephyr.home.icotwo.link',''),('zephyr.home.imageheight','520px'),('zephyr.home.img',''),('zephyr.home.imgposition','2'),('zephyr.home.signup','1'),('zephyr.home.style','1'),('zephyr.home.uselogin','1'),('zephyr.home.usesignup','1'),('zephyr.home.video',''),('zephyr.homebottom.button','1'),('zephyr.homebottom.h1','1'),('zephyr.homebottom.h2','1'),('zephyr.homebottom.img',''),('zephyr.input.bgcolor','#f7f8fa'),('zephyr.link.color','#3dcf07'),('zephyr.link.colorhover','#555555'),('zephyr.logo.margin','2px'),('zephyr.main.font','Arial, Helvetica, sans-serif'),('zephyr.mainmenu.dropdown','5'),('zephyr.newsfeed.style','1'),('zephyr.responsive.layout','true'),('zephyr.text.fontweight','400'),('zephyr.use.googlefonts','true'),('zephyr.width.colleft','220px'),('zephyr.width.colright','220px'),('zephyr.width.main','1100px');
/*!40000 ALTER TABLE `engine4_core_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_statistics`
--

DROP TABLE IF EXISTS `engine4_core_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_statistics` (
  `type` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `date` datetime NOT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`type`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_statistics`
--

LOCK TABLES `engine4_core_statistics` WRITE;
/*!40000 ALTER TABLE `engine4_core_statistics` DISABLE KEYS */;
INSERT INTO `engine4_core_statistics` (`type`, `date`, `value`) VALUES ('core.emails','2014-10-17 11:00:00',2),('core.emails','2014-10-23 03:00:00',1),('core.emails','2014-10-23 23:00:00',1),('core.emails','2014-10-24 01:00:00',1),('core.emails','2014-10-27 01:00:00',1),('core.emails','2014-10-28 02:00:00',1),('core.likes','2014-10-28 02:00:00',1),('core.views','2014-10-14 23:00:00',2),('core.views','2014-10-15 01:00:00',2),('core.views','2014-10-15 12:00:00',1),('core.views','2014-10-16 01:00:00',6),('core.views','2014-10-16 02:00:00',2),('core.views','2014-10-17 00:00:00',1),('core.views','2014-10-17 10:00:00',13),('core.views','2014-10-17 11:00:00',34),('core.views','2014-10-18 16:00:00',3),('core.views','2014-10-19 17:00:00',3),('core.views','2014-10-20 18:00:00',3),('core.views','2014-10-21 01:00:00',3),('core.views','2014-10-21 05:00:00',4),('core.views','2014-10-21 18:00:00',3),('core.views','2014-10-21 22:00:00',3),('core.views','2014-10-23 01:00:00',22),('core.views','2014-10-23 02:00:00',92),('core.views','2014-10-23 03:00:00',64),('core.views','2014-10-23 16:00:00',2),('core.views','2014-10-23 23:00:00',65),('core.views','2014-10-24 00:00:00',144),('core.views','2014-10-24 01:00:00',39),('core.views','2014-10-24 06:00:00',10),('core.views','2014-10-24 10:00:00',12),('core.views','2014-10-24 13:00:00',3),('core.views','2014-10-24 16:00:00',3),('core.views','2014-10-25 16:00:00',3),('core.views','2014-10-26 02:00:00',1),('core.views','2014-10-26 16:00:00',3),('core.views','2014-10-26 19:00:00',12),('core.views','2014-10-27 01:00:00',32),('core.views','2014-10-27 02:00:00',52),('core.views','2014-10-27 08:00:00',3),('core.views','2014-10-27 11:00:00',2),('core.views','2014-10-27 12:00:00',40),('core.views','2014-10-27 16:00:00',4),('core.views','2014-10-27 19:00:00',2),('core.views','2014-10-27 20:00:00',13),('core.views','2014-10-28 02:00:00',34),('core.views','2014-10-28 04:00:00',4),('core.views','2014-10-28 09:00:00',14),('core.views','2014-10-28 10:00:00',26),('core.views','2014-10-28 11:00:00',40),('core.views','2014-10-28 15:00:00',43),('core.views','2014-10-28 20:00:00',56),('core.views','2014-10-28 21:00:00',32),('core.views','2014-10-29 13:00:00',24),('core.views','2014-10-29 14:00:00',23),('core.views','2014-10-29 17:00:00',7),('core.views','2014-10-29 22:00:00',9),('core.views','2014-10-30 18:00:00',3),('core.views','2014-10-31 05:00:00',17),('core.views','2014-10-31 06:00:00',2),('core.views','2014-10-31 15:00:00',2),('core.views','2014-10-31 16:00:00',8),('core.views','2014-10-31 17:00:00',2),('core.views','2014-10-31 19:00:00',67),('core.views','2014-10-31 21:00:00',28),('core.views','2014-11-01 02:00:00',8),('user.creations','2014-10-17 11:00:00',2),('user.creations','2014-10-23 03:00:00',1),('user.creations','2014-10-27 01:00:00',1),('user.friendships','2014-10-24 01:00:00',1),('user.logins','2014-10-23 01:00:00',1),('user.logins','2014-10-23 02:00:00',2),('user.logins','2014-10-23 23:00:00',1),('user.logins','2014-10-24 00:00:00',1),('user.logins','2014-10-28 02:00:00',1),('user.logins','2014-10-28 09:00:00',2),('user.logins','2014-10-29 22:00:00',1),('user.logins','2014-10-31 05:00:00',1),('user.logins','2014-10-31 19:00:00',1),('user.logins','2014-11-01 02:00:00',1);
/*!40000 ALTER TABLE `engine4_core_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_status`
--

DROP TABLE IF EXISTS `engine4_core_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_status` (
  `status_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `resource_type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `resource_id` int(11) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_status`
--

LOCK TABLES `engine4_core_status` WRITE;
/*!40000 ALTER TABLE `engine4_core_status` DISABLE KEYS */;
INSERT INTO `engine4_core_status` (`status_id`, `resource_type`, `resource_id`, `body`, `creation_date`) VALUES (1,'user',1,'Yoo Im Emil and I rule!!','2014-10-23 23:42:02'),(2,'user',5,'Hello!!','2014-10-27 01:46:49');
/*!40000 ALTER TABLE `engine4_core_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_styles`
--

DROP TABLE IF EXISTS `engine4_core_styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_styles` (
  `type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `style` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`type`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_styles`
--

LOCK TABLES `engine4_core_styles` WRITE;
/*!40000 ALTER TABLE `engine4_core_styles` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_tagmaps`
--

DROP TABLE IF EXISTS `engine4_core_tagmaps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_tagmaps` (
  `tagmap_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `resource_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `resource_id` int(11) unsigned NOT NULL,
  `tagger_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tagger_id` int(11) unsigned NOT NULL,
  `tag_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tag_id` int(11) unsigned NOT NULL,
  `creation_date` datetime DEFAULT NULL,
  `extra` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`tagmap_id`),
  KEY `resource_type` (`resource_type`,`resource_id`),
  KEY `tagger_type` (`tagger_type`,`tagger_id`),
  KEY `tag_type` (`tag_type`,`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_tagmaps`
--

LOCK TABLES `engine4_core_tagmaps` WRITE;
/*!40000 ALTER TABLE `engine4_core_tagmaps` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_tagmaps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_tags`
--

DROP TABLE IF EXISTS `engine4_core_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_tags` (
  `tag_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `text` (`text`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_tags`
--

LOCK TABLES `engine4_core_tags` WRITE;
/*!40000 ALTER TABLE `engine4_core_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_core_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_tasks`
--

DROP TABLE IF EXISTS `engine4_core_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_tasks` (
  `task_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `module` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `plugin` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `timeout` int(11) unsigned NOT NULL DEFAULT '60',
  `processes` smallint(3) unsigned NOT NULL DEFAULT '1',
  `semaphore` smallint(3) NOT NULL DEFAULT '0',
  `started_last` int(11) NOT NULL DEFAULT '0',
  `started_count` int(11) unsigned NOT NULL DEFAULT '0',
  `completed_last` int(11) NOT NULL DEFAULT '0',
  `completed_count` int(11) unsigned NOT NULL DEFAULT '0',
  `failure_last` int(11) NOT NULL DEFAULT '0',
  `failure_count` int(11) unsigned NOT NULL DEFAULT '0',
  `success_last` int(11) NOT NULL DEFAULT '0',
  `success_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`task_id`),
  UNIQUE KEY `plugin` (`plugin`),
  KEY `module` (`module`),
  KEY `started_last` (`started_last`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_tasks`
--

LOCK TABLES `engine4_core_tasks` WRITE;
/*!40000 ALTER TABLE `engine4_core_tasks` DISABLE KEYS */;
INSERT INTO `engine4_core_tasks` (`task_id`, `title`, `module`, `plugin`, `timeout`, `processes`, `semaphore`, `started_last`, `started_count`, `completed_last`, `completed_count`, `failure_last`, `failure_count`, `success_last`, `success_count`) VALUES (1,'Job Queue','core','Core_Plugin_Task_Jobs',5,1,0,1414809756,364,1414809756,364,0,0,1414809756,364),(2,'Background Mailer','core','Core_Plugin_Task_Mail',15,1,0,1414809756,364,1414809756,364,0,0,1414809756,364),(3,'Cache Prefetch','core','Core_Plugin_Task_Prefetch',300,1,0,1414809482,140,1414809482,140,0,0,1414809482,140),(4,'Statistics','core','Core_Plugin_Task_Statistics',43200,1,0,1414809635,15,1414809635,15,0,0,1414809635,15),(5,'Log Rotation','core','Core_Plugin_Task_LogRotation',7200,1,0,1414809756,24,1414809756,24,0,0,1414809756,24),(6,'Member Data Maintenance','user','User_Plugin_Task_Cleanup',60,1,0,1414791132,177,1414791132,177,0,0,1414791132,177),(7,'Payment Maintenance','user','Payment_Plugin_Task_Cleanup',43200,1,0,1414771390,13,1414771390,13,0,0,1414771390,13),(8,'Chat Data Maintenance','chat','Chat_Plugin_Task_Cleanup',60,1,0,1414791132,164,1414791132,164,0,0,1414791132,164),(9,'Music Cleanup','music','Music_Plugin_Task_Cleanup',43200,1,0,1414783035,12,1414783035,12,0,0,1414783035,12),(10,'Donation Cleanup','donation','Donation_Plugin_Task_Cleanup',60,1,0,1414791132,36,1414791132,36,0,0,1414791132,36);
/*!40000 ALTER TABLE `engine4_core_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_core_themes`
--

DROP TABLE IF EXISTS `engine4_core_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_core_themes` (
  `theme_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`theme_id`),
  UNIQUE KEY `name` (`name`),
  KEY `active` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_core_themes`
--

LOCK TABLES `engine4_core_themes` WRITE;
/*!40000 ALTER TABLE `engine4_core_themes` DISABLE KEYS */;
INSERT INTO `engine4_core_themes` (`theme_id`, `name`, `title`, `description`, `active`) VALUES (1,'default','Default','',0),(2,'midnight','Midnight','',0),(3,'clean','Clean','',0),(4,'modern','Modern','',0),(5,'bamboo','Bamboo','',0),(6,'digita','Digita','',0),(7,'grid-blue','Grid Blue','',0),(8,'grid-brown','Grid Brown','',0),(9,'grid-dark','Grid Dark','',0),(10,'grid-gray','Grid Gray','',0),(11,'grid-green','Grid Green','',0),(12,'grid-pink','Grid Pink','',0),(13,'grid-purple','Grid Purple','',0),(14,'grid-red','Grid Red','',0),(15,'kandy-cappuccino','Kandy Cappuccino','',0),(16,'kandy-limeorange','Kandy Limeorange','',0),(17,'kandy-mangoberry','Kandy Mangoberry','',0),(18,'kandy-watermelon','Kandy Watermelon','',0),(19,'musicbox-blue','Musicbox Blue','',0),(20,'musicbox-brown','Musicbox Brown','',0),(21,'musicbox-gray','Musicbox Gray','',0),(22,'musicbox-green','Musicbox Green','',0),(23,'musicbox-pink','Musicbox Pink','',0),(24,'musicbox-purple','Musicbox Purple','',0),(25,'musicbox-red','Musicbox Red','',0),(26,'musicbox-yellow','Musicbox Yellow','',0),(27,'quantum-beige','Quantum Beige','',0),(28,'quantum-blue','Quantum Blue','',0),(29,'quantum-gray','Quantum Gray','',0),(30,'quantum-green','Quantum Green','',0),(31,'quantum-orange','Quantum Orange','',0),(32,'quantum-pink','Quantum Pink','',0),(33,'quantum-purple','Quantum Purple','',0),(34,'quantum-red','Quantum Red','',0),(35,'slipstream','Slipstream','',0),(36,'snowbot','Snowbot','',0),(37,'zephyr','Zephyr Theme','',1);
/*!40000 ALTER TABLE `engine4_core_themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_donation_albums`
--

DROP TABLE IF EXISTS `engine4_donation_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_donation_albums` (
  `album_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `donation_id` int(11) unsigned NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `photo_id` int(11) unsigned NOT NULL DEFAULT '0',
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  `collectible_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`album_id`),
  KEY `donation_id` (`donation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_donation_albums`
--

LOCK TABLES `engine4_donation_albums` WRITE;
/*!40000 ALTER TABLE `engine4_donation_albums` DISABLE KEYS */;
INSERT INTO `engine4_donation_albums` (`album_id`, `donation_id`, `title`, `description`, `creation_date`, `modified_date`, `search`, `photo_id`, `view_count`, `comment_count`, `collectible_count`) VALUES (1,1,'','','2014-10-28 11:13:27','2014-10-28 11:13:27',1,0,0,0,0),(2,2,'','','2014-10-28 11:17:35','2014-10-28 11:17:35',1,0,0,0,0);
/*!40000 ALTER TABLE `engine4_donation_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_donation_categories`
--

DROP TABLE IF EXISTS `engine4_donation_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_donation_categories` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_donation_categories`
--

LOCK TABLES `engine4_donation_categories` WRITE;
/*!40000 ALTER TABLE `engine4_donation_categories` DISABLE KEYS */;
INSERT INTO `engine4_donation_categories` (`category_id`, `user_id`, `title`) VALUES (1,1,'Animals'),(2,1,'Art'),(3,1,'Children'),(4,1,'Disability'),(5,1,'Education'),(6,1,'Environmental'),(7,1,'Healthcare'),(8,1,'Hospices'),(9,1,'Religion'),(10,1,'Sport'),(11,1,'Others');
/*!40000 ALTER TABLE `engine4_donation_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_donation_donations`
--

DROP TABLE IF EXISTS `engine4_donation_donations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_donation_donations` (
  `donation_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short_desc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `view_count` int(11) NOT NULL DEFAULT '0',
  `owner_type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `owner_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `photo_id` int(11) NOT NULL DEFAULT '0',
  `min_amount` double(62,6) NOT NULL DEFAULT '0.000000',
  `type` enum('project','charity','fundraise') COLLATE utf8_unicode_ci DEFAULT 'project',
  `target_sum` double(62,6) NOT NULL DEFAULT '0.000000',
  `raised_sum` double(62,6) NOT NULL,
  `can_choose_amount` tinyint(1) NOT NULL DEFAULT '1',
  `allow_anonymous` tinyint(1) NOT NULL DEFAULT '1',
  `expiry_date` datetime NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `street` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `predefine_list` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `status` enum('active','expired','initial','cancelled') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'initial',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`donation_id`),
  KEY `owner_type` (`owner_type`,`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_donation_donations`
--

LOCK TABLES `engine4_donation_donations` WRITE;
/*!40000 ALTER TABLE `engine4_donation_donations` DISABLE KEYS */;
INSERT INTO `engine4_donation_donations` (`donation_id`, `title`, `short_desc`, `description`, `view_count`, `owner_type`, `owner_id`, `page_id`, `photo_id`, `min_amount`, `type`, `target_sum`, `raised_sum`, `can_choose_amount`, `allow_anonymous`, `expiry_date`, `creation_date`, `modified_date`, `country`, `state`, `city`, `street`, `phone`, `enabled`, `predefine_list`, `category_id`, `parent_id`, `status`, `approved`) VALUES (1,'Test','Testing Again','<p>Testing Again Again</p>',0,'user',1,0,0,0.150000,'charity',10000000000.000000,0.000000,1,1,'2019-01-01 00:00:00','2014-10-28 11:13:26','2014-10-28 11:13:26','','','','','',0,'5,10,20,50,100',1,0,'active',1),(2,'Project Test','Testing','<p>Test Again</p>',0,'user',1,0,0,0.150000,'project',20.000000,0.000000,1,1,'2019-01-01 00:00:00','2014-10-28 11:17:35','2014-10-28 11:17:35','','','','','',0,'5,10,20,50,100',1,0,'active',1);
/*!40000 ALTER TABLE `engine4_donation_donations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_donation_fin_infos`
--

DROP TABLE IF EXISTS `engine4_donation_fin_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_donation_fin_infos` (
  `fininfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `donation_id` int(11) NOT NULL DEFAULT '0',
  `pemail` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `2email` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`fininfo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_donation_fin_infos`
--

LOCK TABLES `engine4_donation_fin_infos` WRITE;
/*!40000 ALTER TABLE `engine4_donation_fin_infos` DISABLE KEYS */;
INSERT INTO `engine4_donation_fin_infos` (`fininfo_id`, `donation_id`, `pemail`, `2email`) VALUES (1,1,'thecooldetroit@gmail.com',NULL),(2,2,'thecooldetroit@gmail.com',NULL);
/*!40000 ALTER TABLE `engine4_donation_fin_infos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_donation_markers`
--

DROP TABLE IF EXISTS `engine4_donation_markers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_donation_markers` (
  `marker_id` int(11) NOT NULL AUTO_INCREMENT,
  `donation_id` int(11) NOT NULL DEFAULT '0',
  `latitude` float(10,6) NOT NULL,
  `longitude` float(10,6) NOT NULL,
  PRIMARY KEY (`marker_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_donation_markers`
--

LOCK TABLES `engine4_donation_markers` WRITE;
/*!40000 ALTER TABLE `engine4_donation_markers` DISABLE KEYS */;
INSERT INTO `engine4_donation_markers` (`marker_id`, `donation_id`, `latitude`, `longitude`) VALUES (1,1,0.000000,0.000000),(2,2,0.000000,0.000000);
/*!40000 ALTER TABLE `engine4_donation_markers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_donation_photos`
--

DROP TABLE IF EXISTS `engine4_donation_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_donation_photos` (
  `photo_id` int(11) NOT NULL AUTO_INCREMENT,
  `album_id` int(11) NOT NULL,
  `donation_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`photo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_donation_photos`
--

LOCK TABLES `engine4_donation_photos` WRITE;
/*!40000 ALTER TABLE `engine4_donation_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_donation_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_donation_transactions`
--

DROP TABLE IF EXISTS `engine4_donation_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_donation_transactions` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(128) CHARACTER SET ucs2 COLLATE ucs2_unicode_ci DEFAULT NULL,
  `item_id` int(11) unsigned NOT NULL DEFAULT '0',
  `item_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gateway_id` int(11) unsigned NOT NULL DEFAULT '0',
  `gateway_transaction_id` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `amount` double(62,6) NOT NULL DEFAULT '0.000000',
  `currency` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `creation_date` datetime NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_donation_transactions`
--

LOCK TABLES `engine4_donation_transactions` WRITE;
/*!40000 ALTER TABLE `engine4_donation_transactions` DISABLE KEYS */;
INSERT INTO `engine4_donation_transactions` (`transaction_id`, `order_id`, `user_id`, `name`, `email`, `item_id`, `item_type`, `state`, `gateway_id`, `gateway_transaction_id`, `amount`, `currency`, `description`, `creation_date`) VALUES (1,1,1,'Emil Torres','socialengine@test.grsband.com',1,'donation','failed',2,'',0.000000,'USD','','2014-10-28 11:14:42');
/*!40000 ALTER TABLE `engine4_donation_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_event_albums`
--

DROP TABLE IF EXISTS `engine4_event_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_event_albums` (
  `album_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(11) unsigned NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `photo_id` int(11) unsigned NOT NULL DEFAULT '0',
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  `collectible_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`album_id`),
  KEY `event_id` (`event_id`),
  KEY `search` (`search`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_event_albums`
--

LOCK TABLES `engine4_event_albums` WRITE;
/*!40000 ALTER TABLE `engine4_event_albums` DISABLE KEYS */;
INSERT INTO `engine4_event_albums` (`album_id`, `event_id`, `title`, `description`, `creation_date`, `modified_date`, `search`, `photo_id`, `view_count`, `comment_count`, `collectible_count`) VALUES (1,1,'','','2014-10-17 11:27:57','2014-10-17 11:27:57',1,0,0,0,0),(2,2,'','','2014-10-28 10:55:54','2014-10-28 10:55:54',1,0,0,0,0);
/*!40000 ALTER TABLE `engine4_event_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_event_categories`
--

DROP TABLE IF EXISTS `engine4_event_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_event_categories` (
  `category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_event_categories`
--

LOCK TABLES `engine4_event_categories` WRITE;
/*!40000 ALTER TABLE `engine4_event_categories` DISABLE KEYS */;
INSERT INTO `engine4_event_categories` (`category_id`, `title`) VALUES (1,'Arts'),(2,'Business'),(3,'Conferences'),(4,'Festivals'),(5,'Food'),(6,'Fundraisers'),(7,'Galleries'),(8,'Health'),(9,'Just For Fun'),(10,'Kids'),(11,'Learning'),(12,'Literary'),(13,'Movies'),(14,'Museums'),(15,'Neighborhood'),(16,'Networking'),(17,'Nightlife'),(18,'On Campus'),(19,'Organizations'),(20,'Outdoors'),(21,'Pets'),(22,'Politics'),(23,'Sales'),(24,'Science'),(25,'Spirituality'),(26,'Sports'),(27,'Technology'),(28,'Theatre'),(29,'Other');
/*!40000 ALTER TABLE `engine4_event_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_event_events`
--

DROP TABLE IF EXISTS `engine4_event_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_event_events` (
  `event_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `parent_type` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) unsigned NOT NULL,
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `starttime` datetime NOT NULL,
  `endtime` datetime NOT NULL,
  `host` varchar(115) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(115) COLLATE utf8_unicode_ci NOT NULL,
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `member_count` int(11) unsigned NOT NULL DEFAULT '0',
  `approval` tinyint(1) NOT NULL DEFAULT '0',
  `invite` tinyint(1) NOT NULL DEFAULT '0',
  `photo_id` int(11) unsigned NOT NULL,
  `category_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `parent_type` (`parent_type`,`parent_id`),
  KEY `starttime` (`starttime`),
  KEY `search` (`search`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_event_events`
--

LOCK TABLES `engine4_event_events` WRITE;
/*!40000 ALTER TABLE `engine4_event_events` DISABLE KEYS */;
INSERT INTO `engine4_event_events` (`event_id`, `title`, `description`, `user_id`, `parent_type`, `parent_id`, `search`, `creation_date`, `modified_date`, `starttime`, `endtime`, `host`, `location`, `view_count`, `member_count`, `approval`, `invite`, `photo_id`, `category_id`) VALUES (1,'Sample Event','Test',2,'user',2,1,'2014-10-17 11:27:56','2014-10-17 11:27:56','2014-10-22 05:00:00','2014-10-30 05:00:00','','',4,2,0,0,0,1),(2,'test','test',1,'group',1,1,'2014-10-28 10:55:52','2014-10-28 10:55:52','2014-10-31 08:00:00','2014-10-31 20:00:00','Test','',0,1,0,0,0,18);
/*!40000 ALTER TABLE `engine4_event_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_event_membership`
--

DROP TABLE IF EXISTS `engine4_event_membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_event_membership` (
  `resource_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `resource_approved` tinyint(1) NOT NULL DEFAULT '0',
  `user_approved` tinyint(1) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci,
  `rsvp` tinyint(3) NOT NULL DEFAULT '3',
  `title` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`resource_id`,`user_id`),
  KEY `REVERSE` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_event_membership`
--

LOCK TABLES `engine4_event_membership` WRITE;
/*!40000 ALTER TABLE `engine4_event_membership` DISABLE KEYS */;
INSERT INTO `engine4_event_membership` (`resource_id`, `user_id`, `active`, `resource_approved`, `user_approved`, `message`, `rsvp`, `title`) VALUES (1,2,1,1,1,NULL,2,NULL),(1,3,1,1,1,NULL,2,NULL),(2,1,1,1,1,NULL,2,NULL);
/*!40000 ALTER TABLE `engine4_event_membership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_event_photos`
--

DROP TABLE IF EXISTS `engine4_event_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_event_photos` (
  `photo_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` int(11) unsigned NOT NULL,
  `event_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `collection_id` int(11) unsigned NOT NULL,
  `file_id` int(11) unsigned NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`photo_id`),
  KEY `album_id` (`album_id`),
  KEY `event_id` (`event_id`),
  KEY `collection_id` (`collection_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_event_photos`
--

LOCK TABLES `engine4_event_photos` WRITE;
/*!40000 ALTER TABLE `engine4_event_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_event_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_event_posts`
--

DROP TABLE IF EXISTS `engine4_event_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_event_posts` (
  `post_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) unsigned NOT NULL,
  `event_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`post_id`),
  KEY `topic_id` (`topic_id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_event_posts`
--

LOCK TABLES `engine4_event_posts` WRITE;
/*!40000 ALTER TABLE `engine4_event_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_event_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_event_topics`
--

DROP TABLE IF EXISTS `engine4_event_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_event_topics` (
  `topic_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `sticky` tinyint(1) NOT NULL DEFAULT '0',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `post_count` int(11) unsigned NOT NULL DEFAULT '0',
  `lastpost_id` int(11) unsigned NOT NULL,
  `lastposter_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`topic_id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_event_topics`
--

LOCK TABLES `engine4_event_topics` WRITE;
/*!40000 ALTER TABLE `engine4_event_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_event_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_event_topicwatches`
--

DROP TABLE IF EXISTS `engine4_event_topicwatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_event_topicwatches` (
  `resource_id` int(10) unsigned NOT NULL,
  `topic_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `watch` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`resource_id`,`topic_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_event_topicwatches`
--

LOCK TABLES `engine4_event_topicwatches` WRITE;
/*!40000 ALTER TABLE `engine4_event_topicwatches` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_event_topicwatches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_forum_categories`
--

DROP TABLE IF EXISTS `engine4_forum_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_forum_categories` (
  `category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `order` smallint(6) NOT NULL DEFAULT '0',
  `forum_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`),
  KEY `order` (`order`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_forum_categories`
--

LOCK TABLES `engine4_forum_categories` WRITE;
/*!40000 ALTER TABLE `engine4_forum_categories` DISABLE KEYS */;
INSERT INTO `engine4_forum_categories` (`category_id`, `title`, `description`, `creation_date`, `modified_date`, `order`, `forum_count`) VALUES (1,'General','','2014-10-14 18:27:09','2014-10-14 18:27:09',1,3),(2,'Off-Topic','','2014-10-14 18:27:09','2014-10-14 18:27:09',2,2);
/*!40000 ALTER TABLE `engine4_forum_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_forum_forums`
--

DROP TABLE IF EXISTS `engine4_forum_forums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_forum_forums` (
  `forum_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) unsigned NOT NULL,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `order` smallint(6) NOT NULL DEFAULT '999',
  `file_id` int(11) unsigned NOT NULL DEFAULT '0',
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `topic_count` int(11) unsigned NOT NULL DEFAULT '0',
  `post_count` int(11) unsigned NOT NULL DEFAULT '0',
  `lastpost_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lastposter_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`forum_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_forum_forums`
--

LOCK TABLES `engine4_forum_forums` WRITE;
/*!40000 ALTER TABLE `engine4_forum_forums` DISABLE KEYS */;
INSERT INTO `engine4_forum_forums` (`forum_id`, `category_id`, `title`, `description`, `creation_date`, `modified_date`, `order`, `file_id`, `view_count`, `topic_count`, `post_count`, `lastpost_id`, `lastposter_id`) VALUES (1,1,'News and Announcements','','2010-02-01 14:59:01','2010-02-01 14:59:01',1,0,0,0,0,0,0),(2,1,'Support','','2010-02-01 15:09:01','2010-02-01 17:59:01',2,0,0,0,0,0,0),(3,1,'Suggestions','','2010-02-01 15:09:01','2010-02-01 17:59:01',3,0,0,0,0,0,0),(4,2,'Off-Topic Discussions','','2010-02-01 15:09:01','2010-02-01 17:59:01',1,0,0,0,0,0,0),(5,2,'Introduce Yourself','','2010-02-01 15:09:01','2010-02-01 17:59:01',2,0,0,0,0,0,0);
/*!40000 ALTER TABLE `engine4_forum_forums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_forum_listitems`
--

DROP TABLE IF EXISTS `engine4_forum_listitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_forum_listitems` (
  `listitem_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `list_id` int(11) unsigned NOT NULL,
  `child_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`listitem_id`),
  KEY `list_id` (`list_id`),
  KEY `child_id` (`child_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_forum_listitems`
--

LOCK TABLES `engine4_forum_listitems` WRITE;
/*!40000 ALTER TABLE `engine4_forum_listitems` DISABLE KEYS */;
INSERT INTO `engine4_forum_listitems` (`listitem_id`, `list_id`, `child_id`) VALUES (1,1,1),(2,2,1),(3,3,1),(4,4,1),(5,5,1);
/*!40000 ALTER TABLE `engine4_forum_listitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_forum_lists`
--

DROP TABLE IF EXISTS `engine4_forum_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_forum_lists` (
  `list_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) unsigned NOT NULL,
  `child_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`list_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_forum_lists`
--

LOCK TABLES `engine4_forum_lists` WRITE;
/*!40000 ALTER TABLE `engine4_forum_lists` DISABLE KEYS */;
INSERT INTO `engine4_forum_lists` (`list_id`, `owner_id`, `child_count`) VALUES (1,1,1),(2,2,1),(3,3,1),(4,4,1),(5,5,1);
/*!40000 ALTER TABLE `engine4_forum_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_forum_membership`
--

DROP TABLE IF EXISTS `engine4_forum_membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_forum_membership` (
  `resource_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `resource_approved` tinyint(1) NOT NULL DEFAULT '0',
  `moderator` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`resource_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_forum_membership`
--

LOCK TABLES `engine4_forum_membership` WRITE;
/*!40000 ALTER TABLE `engine4_forum_membership` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_forum_membership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_forum_posts`
--

DROP TABLE IF EXISTS `engine4_forum_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_forum_posts` (
  `post_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) unsigned NOT NULL,
  `forum_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `file_id` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`post_id`),
  KEY `topic_id` (`topic_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_forum_posts`
--

LOCK TABLES `engine4_forum_posts` WRITE;
/*!40000 ALTER TABLE `engine4_forum_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_forum_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_forum_signatures`
--

DROP TABLE IF EXISTS `engine4_forum_signatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_forum_signatures` (
  `signature_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `post_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`signature_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_forum_signatures`
--

LOCK TABLES `engine4_forum_signatures` WRITE;
/*!40000 ALTER TABLE `engine4_forum_signatures` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_forum_signatures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_forum_topics`
--

DROP TABLE IF EXISTS `engine4_forum_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_forum_topics` (
  `topic_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `forum_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `sticky` tinyint(4) NOT NULL DEFAULT '0',
  `closed` tinyint(4) NOT NULL DEFAULT '0',
  `post_count` int(11) unsigned NOT NULL DEFAULT '0',
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `lastpost_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lastposter_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`topic_id`),
  KEY `forum_id` (`forum_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_forum_topics`
--

LOCK TABLES `engine4_forum_topics` WRITE;
/*!40000 ALTER TABLE `engine4_forum_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_forum_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_forum_topicviews`
--

DROP TABLE IF EXISTS `engine4_forum_topicviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_forum_topicviews` (
  `user_id` int(11) unsigned NOT NULL,
  `topic_id` int(11) unsigned NOT NULL,
  `last_view_date` datetime NOT NULL,
  PRIMARY KEY (`user_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_forum_topicviews`
--

LOCK TABLES `engine4_forum_topicviews` WRITE;
/*!40000 ALTER TABLE `engine4_forum_topicviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_forum_topicviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_forum_topicwatches`
--

DROP TABLE IF EXISTS `engine4_forum_topicwatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_forum_topicwatches` (
  `resource_id` int(10) unsigned NOT NULL,
  `topic_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `watch` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`resource_id`,`topic_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_forum_topicwatches`
--

LOCK TABLES `engine4_forum_topicwatches` WRITE;
/*!40000 ALTER TABLE `engine4_forum_topicwatches` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_forum_topicwatches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_group_albums`
--

DROP TABLE IF EXISTS `engine4_group_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_group_albums` (
  `album_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) unsigned NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `photo_id` int(11) unsigned NOT NULL DEFAULT '0',
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  `collectible_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`album_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_group_albums`
--

LOCK TABLES `engine4_group_albums` WRITE;
/*!40000 ALTER TABLE `engine4_group_albums` DISABLE KEYS */;
INSERT INTO `engine4_group_albums` (`album_id`, `group_id`, `title`, `description`, `creation_date`, `modified_date`, `search`, `photo_id`, `view_count`, `comment_count`, `collectible_count`) VALUES (1,1,'','','2014-10-28 10:53:52','2014-10-28 10:53:52',1,0,0,0,0);
/*!40000 ALTER TABLE `engine4_group_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_group_categories`
--

DROP TABLE IF EXISTS `engine4_group_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_group_categories` (
  `category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_group_categories`
--

LOCK TABLES `engine4_group_categories` WRITE;
/*!40000 ALTER TABLE `engine4_group_categories` DISABLE KEYS */;
INSERT INTO `engine4_group_categories` (`category_id`, `title`) VALUES (1,'Animals'),(2,'Business & Finance'),(3,'Computers & Internet'),(4,'Cultures & Community'),(5,'Dating & Relationships'),(6,'Entertainment & Arts'),(7,'Family & Home'),(8,'Games'),(9,'Government & Politics'),(10,'Health & Wellness'),(11,'Hobbies & Crafts'),(12,'Music'),(13,'Recreation & Sports'),(14,'Regional'),(15,'Religion & Beliefs'),(16,'Schools & Education'),(17,'Science');
/*!40000 ALTER TABLE `engine4_group_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_group_groups`
--

DROP TABLE IF EXISTS `engine4_group_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_group_groups` (
  `group_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `invite` tinyint(1) NOT NULL DEFAULT '1',
  `approval` tinyint(1) NOT NULL DEFAULT '0',
  `photo_id` int(11) unsigned NOT NULL DEFAULT '0',
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `member_count` smallint(6) unsigned NOT NULL,
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  KEY `user_id` (`user_id`),
  KEY `search` (`search`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_group_groups`
--

LOCK TABLES `engine4_group_groups` WRITE;
/*!40000 ALTER TABLE `engine4_group_groups` DISABLE KEYS */;
INSERT INTO `engine4_group_groups` (`group_id`, `user_id`, `title`, `description`, `category_id`, `search`, `invite`, `approval`, `photo_id`, `creation_date`, `modified_date`, `member_count`, `view_count`) VALUES (1,1,'Test','test',2,1,1,0,0,'2014-10-28 10:53:51','2014-10-28 10:53:51',1,0);
/*!40000 ALTER TABLE `engine4_group_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_group_listitems`
--

DROP TABLE IF EXISTS `engine4_group_listitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_group_listitems` (
  `listitem_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `list_id` int(11) unsigned NOT NULL,
  `child_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`listitem_id`),
  KEY `list_id` (`list_id`),
  KEY `child_id` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_group_listitems`
--

LOCK TABLES `engine4_group_listitems` WRITE;
/*!40000 ALTER TABLE `engine4_group_listitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_group_listitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_group_lists`
--

DROP TABLE IF EXISTS `engine4_group_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_group_lists` (
  `list_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `owner_id` int(11) unsigned NOT NULL,
  `child_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`list_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_group_lists`
--

LOCK TABLES `engine4_group_lists` WRITE;
/*!40000 ALTER TABLE `engine4_group_lists` DISABLE KEYS */;
INSERT INTO `engine4_group_lists` (`list_id`, `title`, `owner_id`, `child_count`) VALUES (1,'GROUP_OFFICERS',1,0);
/*!40000 ALTER TABLE `engine4_group_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_group_membership`
--

DROP TABLE IF EXISTS `engine4_group_membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_group_membership` (
  `resource_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `resource_approved` tinyint(1) NOT NULL DEFAULT '0',
  `user_approved` tinyint(1) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci,
  `title` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`resource_id`,`user_id`),
  KEY `REVERSE` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_group_membership`
--

LOCK TABLES `engine4_group_membership` WRITE;
/*!40000 ALTER TABLE `engine4_group_membership` DISABLE KEYS */;
INSERT INTO `engine4_group_membership` (`resource_id`, `user_id`, `active`, `resource_approved`, `user_approved`, `message`, `title`) VALUES (1,1,1,1,1,NULL,NULL);
/*!40000 ALTER TABLE `engine4_group_membership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_group_photos`
--

DROP TABLE IF EXISTS `engine4_group_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_group_photos` (
  `photo_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` int(11) unsigned NOT NULL,
  `group_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `collection_id` int(11) unsigned NOT NULL,
  `file_id` int(11) unsigned NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`photo_id`),
  KEY `album_id` (`album_id`),
  KEY `group_id` (`group_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_group_photos`
--

LOCK TABLES `engine4_group_photos` WRITE;
/*!40000 ALTER TABLE `engine4_group_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_group_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_group_posts`
--

DROP TABLE IF EXISTS `engine4_group_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_group_posts` (
  `post_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `topic_id` int(11) unsigned NOT NULL,
  `group_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`post_id`),
  KEY `topic_id` (`topic_id`),
  KEY `group_id` (`group_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_group_posts`
--

LOCK TABLES `engine4_group_posts` WRITE;
/*!40000 ALTER TABLE `engine4_group_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_group_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_group_topics`
--

DROP TABLE IF EXISTS `engine4_group_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_group_topics` (
  `topic_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `sticky` tinyint(1) NOT NULL DEFAULT '0',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `post_count` int(11) unsigned NOT NULL DEFAULT '0',
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `lastpost_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lastposter_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`topic_id`),
  KEY `group_id` (`group_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_group_topics`
--

LOCK TABLES `engine4_group_topics` WRITE;
/*!40000 ALTER TABLE `engine4_group_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_group_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_group_topicwatches`
--

DROP TABLE IF EXISTS `engine4_group_topicwatches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_group_topicwatches` (
  `resource_id` int(10) unsigned NOT NULL,
  `topic_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `watch` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`resource_id`,`topic_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_group_topicwatches`
--

LOCK TABLES `engine4_group_topicwatches` WRITE;
/*!40000 ALTER TABLE `engine4_group_topicwatches` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_group_topicwatches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_hecore_featureds`
--

DROP TABLE IF EXISTS `engine4_hecore_featureds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_hecore_featureds` (
  `featured_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`featured_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_hecore_featureds`
--

LOCK TABLES `engine4_hecore_featureds` WRITE;
/*!40000 ALTER TABLE `engine4_hecore_featureds` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_hecore_featureds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_hecore_modules`
--

DROP TABLE IF EXISTS `engine4_hecore_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_hecore_modules` (
  `module_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  `version` varchar(32) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `installed` tinyint(1) NOT NULL DEFAULT '0',
  `modified_stamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_hecore_modules`
--

LOCK TABLES `engine4_hecore_modules` WRITE;
/*!40000 ALTER TABLE `engine4_hecore_modules` DISABLE KEYS */;
INSERT INTO `engine4_hecore_modules` (`module_id`, `name`, `version`, `key`, `installed`, `modified_stamp`) VALUES (1,'likes','4.2.3p1','7DD211E22C3ECD36',1,1414493035),(2,'donation','4.2.3p2','236AEA4A001A80DC',1,1414493118);
/*!40000 ALTER TABLE `engine4_hecore_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_hecore_user_settings`
--

DROP TABLE IF EXISTS `engine4_hecore_user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_hecore_user_settings` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL DEFAULT '0',
  `setting` varchar(255) DEFAULT '',
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_hecore_user_settings`
--

LOCK TABLES `engine4_hecore_user_settings` WRITE;
/*!40000 ALTER TABLE `engine4_hecore_user_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_hecore_user_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_invites`
--

DROP TABLE IF EXISTS `engine4_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_invites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `recipient` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `send_request` int(11) NOT NULL,
  `timestamp` datetime NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `new_user_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `user_id` (`user_id`),
  KEY `recipient` (`recipient`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_invites`
--

LOCK TABLES `engine4_invites` WRITE;
/*!40000 ALTER TABLE `engine4_invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_like_likes`
--

DROP TABLE IF EXISTS `engine4_like_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_like_likes` (
  `like_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `resource_type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `resource_title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `poster_type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `poster_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`like_id`),
  KEY `poster_type` (`poster_type`,`poster_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_like_likes`
--

LOCK TABLES `engine4_like_likes` WRITE;
/*!40000 ALTER TABLE `engine4_like_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_like_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_messages_conversations`
--

DROP TABLE IF EXISTS `engine4_messages_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_messages_conversations` (
  `conversation_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_id` int(11) unsigned NOT NULL,
  `recipients` int(11) unsigned NOT NULL,
  `modified` datetime NOT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `resource_type` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '',
  `resource_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`conversation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_messages_conversations`
--

LOCK TABLES `engine4_messages_conversations` WRITE;
/*!40000 ALTER TABLE `engine4_messages_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_messages_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_messages_messages`
--

DROP TABLE IF EXISTS `engine4_messages_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_messages_messages` (
  `message_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `conversation_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `attachment_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '',
  `attachment_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`message_id`),
  UNIQUE KEY `CONVERSATIONS` (`conversation_id`,`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_messages_messages`
--

LOCK TABLES `engine4_messages_messages` WRITE;
/*!40000 ALTER TABLE `engine4_messages_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_messages_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_messages_recipients`
--

DROP TABLE IF EXISTS `engine4_messages_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_messages_recipients` (
  `user_id` int(11) unsigned NOT NULL,
  `conversation_id` int(11) unsigned NOT NULL,
  `inbox_message_id` int(11) unsigned DEFAULT NULL,
  `inbox_updated` datetime DEFAULT NULL,
  `inbox_read` tinyint(1) DEFAULT NULL,
  `inbox_deleted` tinyint(1) DEFAULT NULL,
  `outbox_message_id` int(11) unsigned DEFAULT NULL,
  `outbox_updated` datetime DEFAULT NULL,
  `outbox_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`user_id`,`conversation_id`),
  KEY `INBOX_UPDATED` (`user_id`,`conversation_id`,`inbox_updated`),
  KEY `OUTBOX_UPDATED` (`user_id`,`conversation_id`,`outbox_updated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_messages_recipients`
--

LOCK TABLES `engine4_messages_recipients` WRITE;
/*!40000 ALTER TABLE `engine4_messages_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_messages_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_music_playlist_songs`
--

DROP TABLE IF EXISTS `engine4_music_playlist_songs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_music_playlist_songs` (
  `song_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `playlist_id` int(11) unsigned NOT NULL,
  `file_id` int(11) unsigned NOT NULL,
  `title` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `play_count` int(11) unsigned NOT NULL DEFAULT '0',
  `order` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`song_id`),
  KEY `playlist_id` (`playlist_id`,`file_id`),
  KEY `play_count` (`play_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_music_playlist_songs`
--

LOCK TABLES `engine4_music_playlist_songs` WRITE;
/*!40000 ALTER TABLE `engine4_music_playlist_songs` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_music_playlist_songs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_music_playlists`
--

DROP TABLE IF EXISTS `engine4_music_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_music_playlists` (
  `playlist_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(63) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `photo_id` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `owner_id` int(11) unsigned NOT NULL,
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `profile` tinyint(1) NOT NULL DEFAULT '0',
  `special` enum('wall','message') COLLATE utf8_unicode_ci DEFAULT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  `play_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`playlist_id`),
  KEY `creation_date` (`creation_date`),
  KEY `play_count` (`play_count`),
  KEY `owner_id` (`owner_type`,`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_music_playlists`
--

LOCK TABLES `engine4_music_playlists` WRITE;
/*!40000 ALTER TABLE `engine4_music_playlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_music_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_network_membership`
--

DROP TABLE IF EXISTS `engine4_network_membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_network_membership` (
  `resource_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `resource_approved` tinyint(1) NOT NULL DEFAULT '0',
  `user_approved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`resource_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_network_membership`
--

LOCK TABLES `engine4_network_membership` WRITE;
/*!40000 ALTER TABLE `engine4_network_membership` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_network_membership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_network_networks`
--

DROP TABLE IF EXISTS `engine4_network_networks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_network_networks` (
  `network_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `field_id` int(11) unsigned NOT NULL DEFAULT '0',
  `pattern` text COLLATE utf8_unicode_ci,
  `member_count` int(11) unsigned NOT NULL DEFAULT '0',
  `hide` tinyint(1) NOT NULL DEFAULT '0',
  `assignment` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`network_id`),
  KEY `assignment` (`assignment`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_network_networks`
--

LOCK TABLES `engine4_network_networks` WRITE;
/*!40000 ALTER TABLE `engine4_network_networks` DISABLE KEYS */;
INSERT INTO `engine4_network_networks` (`network_id`, `title`, `description`, `field_id`, `pattern`, `member_count`, `hide`, `assignment`) VALUES (1,'North America','',0,NULL,0,0,0),(2,'South America','',0,NULL,0,0,0),(3,'Europe','',0,NULL,0,0,0),(4,'Asia','',0,NULL,0,0,0),(5,'Africa','',0,NULL,0,0,0),(6,'Australia','',0,NULL,0,0,0),(7,'Antarctica','',0,NULL,0,0,0);
/*!40000 ALTER TABLE `engine4_network_networks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_payment_gateways`
--

DROP TABLE IF EXISTS `engine4_payment_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_payment_gateways` (
  `gateway_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `plugin` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `config` mediumblob,
  `test_mode` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gateway_id`),
  KEY `enabled` (`enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_payment_gateways`
--

LOCK TABLES `engine4_payment_gateways` WRITE;
/*!40000 ALTER TABLE `engine4_payment_gateways` DISABLE KEYS */;
INSERT INTO `engine4_payment_gateways` (`gateway_id`, `title`, `description`, `enabled`, `plugin`, `config`, `test_mode`) VALUES (1,'2Checkout',NULL,0,'Payment_Plugin_Gateway_2Checkout',NULL,0),(2,'PayPal',NULL,0,'Payment_Plugin_Gateway_PayPal',NULL,0),(3,'Testing',NULL,0,'Payment_Plugin_Gateway_Testing',NULL,1);
/*!40000 ALTER TABLE `engine4_payment_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_payment_orders`
--

DROP TABLE IF EXISTS `engine4_payment_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_payment_orders` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `gateway_id` int(10) unsigned NOT NULL,
  `gateway_order_id` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `gateway_transaction_id` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `state` enum('pending','cancelled','failed','incomplete','complete') CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'pending',
  `creation_date` datetime NOT NULL,
  `source_type` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `source_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `user_id` (`user_id`),
  KEY `gateway_id` (`gateway_id`,`gateway_order_id`),
  KEY `state` (`state`),
  KEY `source_type` (`source_type`,`source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_payment_orders`
--

LOCK TABLES `engine4_payment_orders` WRITE;
/*!40000 ALTER TABLE `engine4_payment_orders` DISABLE KEYS */;
INSERT INTO `engine4_payment_orders` (`order_id`, `user_id`, `gateway_id`, `gateway_order_id`, `gateway_transaction_id`, `state`, `creation_date`, `source_type`, `source_id`) VALUES (1,1,2,NULL,'','failed','2014-10-28 11:14:42','donation',1);
/*!40000 ALTER TABLE `engine4_payment_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_payment_packages`
--

DROP TABLE IF EXISTS `engine4_payment_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_payment_packages` (
  `package_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `level_id` int(10) unsigned NOT NULL,
  `downgrade_level_id` int(10) unsigned NOT NULL DEFAULT '0',
  `price` decimal(16,2) unsigned NOT NULL,
  `recurrence` int(11) unsigned NOT NULL,
  `recurrence_type` enum('day','week','month','year','forever') COLLATE utf8_unicode_ci NOT NULL,
  `duration` int(11) unsigned NOT NULL,
  `duration_type` enum('day','week','month','year','forever') COLLATE utf8_unicode_ci NOT NULL,
  `trial_duration` int(11) unsigned NOT NULL DEFAULT '0',
  `trial_duration_type` enum('day','week','month','year','forever') COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `signup` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `after_signup` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`package_id`),
  KEY `level_id` (`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_payment_packages`
--

LOCK TABLES `engine4_payment_packages` WRITE;
/*!40000 ALTER TABLE `engine4_payment_packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_payment_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_payment_products`
--

DROP TABLE IF EXISTS `engine4_payment_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_payment_products` (
  `product_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `extension_type` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `extension_id` int(10) unsigned DEFAULT NULL,
  `sku` bigint(20) unsigned NOT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `price` decimal(16,2) unsigned NOT NULL,
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `sku` (`sku`),
  KEY `extension_type` (`extension_type`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_payment_products`
--

LOCK TABLES `engine4_payment_products` WRITE;
/*!40000 ALTER TABLE `engine4_payment_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_payment_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_payment_subscriptions`
--

DROP TABLE IF EXISTS `engine4_payment_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_payment_subscriptions` (
  `subscription_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `package_id` int(11) unsigned NOT NULL,
  `status` enum('initial','trial','pending','active','cancelled','expired','overdue','refunded') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'initial',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `creation_date` datetime NOT NULL,
  `modified_date` datetime DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `expiration_date` datetime DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `gateway_id` int(10) unsigned DEFAULT NULL,
  `gateway_profile_id` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`subscription_id`),
  UNIQUE KEY `gateway_id` (`gateway_id`,`gateway_profile_id`),
  KEY `user_id` (`user_id`),
  KEY `package_id` (`package_id`),
  KEY `status` (`status`),
  KEY `active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_payment_subscriptions`
--

LOCK TABLES `engine4_payment_subscriptions` WRITE;
/*!40000 ALTER TABLE `engine4_payment_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_payment_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_payment_transactions`
--

DROP TABLE IF EXISTS `engine4_payment_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_payment_transactions` (
  `transaction_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_id` int(10) unsigned NOT NULL,
  `timestamp` datetime NOT NULL,
  `order_id` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `state` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `gateway_transaction_id` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `gateway_parent_transaction_id` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `gateway_order_id` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `amount` decimal(16,2) NOT NULL,
  `currency` char(3) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`transaction_id`),
  KEY `user_id` (`user_id`),
  KEY `gateway_id` (`gateway_id`),
  KEY `type` (`type`),
  KEY `state` (`state`),
  KEY `gateway_transaction_id` (`gateway_transaction_id`),
  KEY `gateway_parent_transaction_id` (`gateway_parent_transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_payment_transactions`
--

LOCK TABLES `engine4_payment_transactions` WRITE;
/*!40000 ALTER TABLE `engine4_payment_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_payment_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_poll_options`
--

DROP TABLE IF EXISTS `engine4_poll_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_poll_options` (
  `poll_option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `poll_id` int(11) unsigned NOT NULL,
  `poll_option` text COLLATE utf8_unicode_ci NOT NULL,
  `votes` smallint(4) unsigned NOT NULL,
  PRIMARY KEY (`poll_option_id`),
  KEY `poll_id` (`poll_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_poll_options`
--

LOCK TABLES `engine4_poll_options` WRITE;
/*!40000 ALTER TABLE `engine4_poll_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_poll_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_poll_polls`
--

DROP TABLE IF EXISTS `engine4_poll_polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_poll_polls` (
  `poll_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  `vote_count` int(11) unsigned NOT NULL DEFAULT '0',
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`poll_id`),
  KEY `user_id` (`user_id`),
  KEY `is_closed` (`is_closed`),
  KEY `creation_date` (`creation_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_poll_polls`
--

LOCK TABLES `engine4_poll_polls` WRITE;
/*!40000 ALTER TABLE `engine4_poll_polls` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_poll_polls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_poll_votes`
--

DROP TABLE IF EXISTS `engine4_poll_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_poll_votes` (
  `poll_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `poll_option_id` int(11) unsigned NOT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`poll_id`,`user_id`),
  KEY `poll_option_id` (`poll_option_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_poll_votes`
--

LOCK TABLES `engine4_poll_votes` WRITE;
/*!40000 ALTER TABLE `engine4_poll_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_poll_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_storage_chunks`
--

DROP TABLE IF EXISTS `engine4_storage_chunks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_storage_chunks` (
  `chunk_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_id` int(11) unsigned NOT NULL,
  `data` blob NOT NULL,
  PRIMARY KEY (`chunk_id`),
  KEY `file_id` (`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_storage_chunks`
--

LOCK TABLES `engine4_storage_chunks` WRITE;
/*!40000 ALTER TABLE `engine4_storage_chunks` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_storage_chunks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_storage_files`
--

DROP TABLE IF EXISTS `engine4_storage_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_storage_files` (
  `file_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_file_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(16) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `parent_type` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `service_id` int(10) unsigned NOT NULL DEFAULT '1',
  `storage_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `extension` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime_major` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `mime_minor` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `hash` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`file_id`),
  UNIQUE KEY `parent_file_id` (`parent_file_id`,`type`),
  KEY `PARENT` (`parent_type`,`parent_id`),
  KEY `user_id` (`user_id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_storage_files`
--

LOCK TABLES `engine4_storage_files` WRITE;
/*!40000 ALTER TABLE `engine4_storage_files` DISABLE KEYS */;
INSERT INTO `engine4_storage_files` (`file_id`, `parent_file_id`, `type`, `parent_type`, `parent_id`, `user_id`, `creation_date`, `modified_date`, `service_id`, `storage_path`, `extension`, `name`, `mime_major`, `mime_minor`, `size`, `hash`) VALUES (1,NULL,NULL,'user',1,1,'2014-10-23 23:40:55','2014-10-23 23:40:55',1,'public/user/01/0001_e8e4.jpg','jpg','imgemil_m.jpg','image','jpeg',10271,'d218e8e4295807778699ce281617cb21'),(2,1,'thumb.profile','user',1,1,'2014-10-23 23:40:55','2014-10-23 23:40:55',1,'public/user/02/0002_e8e4.jpg','jpg','imgemil_p.jpg','image','jpeg',10271,'d218e8e4295807778699ce281617cb21'),(3,1,'thumb.normal','user',1,1,'2014-10-23 23:40:55','2014-10-23 23:40:55',1,'public/user/03/0003_39a9.jpg','jpg','imgemil_in.jpg','image','jpeg',5982,'554f39a90648dfc1be258c9766862d48'),(4,1,'thumb.icon','user',1,1,'2014-10-23 23:40:55','2014-10-23 23:40:55',1,'public/user/04/0004_d1ff.jpg','jpg','imgemil_is.jpg','image','jpeg',1546,'f674d1ff7265d7c7aeb495e16d9b249e'),(5,NULL,NULL,'album_photo',1,1,'2014-10-23 23:40:56','2014-10-23 23:40:56',1,'public/album_photo/05/0005_659b.jpg','jpg','imgemil_m_m.jpg','image','jpeg',10239,'80a3659b0a2459b540ddb4ce6c6bc497'),(6,5,'thumb.normal','album_photo',1,1,'2014-10-23 23:40:56','2014-10-23 23:40:56',1,'public/album_photo/06/0006_44d9.jpg','jpg','imgemil_m_in.jpg','image','jpeg',5944,'b52e44d96d27d894589a16a62eca7c39'),(7,NULL,NULL,'album_photo',2,1,'2014-10-23 23:43:20','2014-10-23 23:43:20',1,'public/album_photo/07/0007_3ad7.JPG','JPG','IMG_0779_m.JPG','image','jpeg',51484,'a99a3ad778c344d56132f3dd09b4da0e'),(8,7,'thumb.normal','album_photo',2,1,'2014-10-23 23:43:20','2014-10-23 23:43:20',1,'public/album_photo/08/0008_f549.JPG','JPG','IMG_0779_in.JPG','image','jpeg',3758,'552cf549154fc149ae92a23fb7335855'),(9,NULL,NULL,'album_photo',3,1,'2014-10-23 23:43:22','2014-10-23 23:43:22',1,'public/album_photo/09/0009_adae.JPG','JPG','IMG_0782_m.JPG','image','jpeg',63736,'8305adae9ddb9248da0c07854ce47dc9'),(10,9,'thumb.normal','album_photo',3,1,'2014-10-23 23:43:22','2014-10-23 23:43:22',1,'public/album_photo/0a/000a_9ad2.JPG','JPG','IMG_0782_in.JPG','image','jpeg',4625,'c54d9ad229e1a13ae03af5ca270e3392'),(11,NULL,NULL,'album_photo',4,1,'2014-10-23 23:43:34','2014-10-23 23:43:34',1,'public/album_photo/0b/000b_4577.JPG','JPG','IMG_1047_m.JPG','image','jpeg',75873,'9b294577871eb695cd7aa4291795b962'),(12,11,'thumb.normal','album_photo',4,1,'2014-10-23 23:43:34','2014-10-23 23:43:34',1,'public/album_photo/0c/000c_b6fc.JPG','JPG','IMG_1047_in.JPG','image','jpeg',5140,'12cab6fcc3b265a6a9d3cca952fadc1d'),(13,NULL,NULL,'album_photo',5,1,'2014-10-23 23:43:44','2014-10-23 23:43:44',1,'public/album_photo/0d/000d_6219.JPG','JPG','IMG_1106_m.JPG','image','jpeg',55072,'e63d621937fc53d0742a7c269bd876da'),(14,13,'thumb.normal','album_photo',5,1,'2014-10-23 23:43:44','2014-10-23 23:43:44',1,'public/album_photo/0e/000e_3948.JPG','JPG','IMG_1106_in.JPG','image','jpeg',4782,'30be394882f63c92a1a47f81ad32a9b1'),(15,NULL,NULL,'user',5,5,'2014-10-27 01:48:06','2014-10-27 01:48:06',1,'public/user/0f/000f_1744.jpg','jpg','IMG_20141024_164456_m.jpg','image','jpeg',75943,'78e01744fbf31d636bd7b6cb306574e7'),(16,15,'thumb.profile','user',5,5,'2014-10-27 01:48:06','2014-10-27 01:48:06',1,'public/user/10/0010_61cc.jpg','jpg','IMG_20141024_164456_p.jpg','image','jpeg',7939,'9b7361cc906890583323b7eb75633cb8'),(17,15,'thumb.normal','user',5,5,'2014-10-27 01:48:06','2014-10-27 01:48:06',1,'public/user/11/0011_6e35.jpg','jpg','IMG_20141024_164456_in.jpg','image','jpeg',4676,'38656e35f2e0d21909c7494c341d0e79'),(18,15,'thumb.icon','user',5,5,'2014-10-27 01:48:06','2014-10-27 01:48:06',1,'public/user/12/0012_eded.jpg','jpg','IMG_20141024_164456_is.jpg','image','jpeg',1327,'6b32ededc73a0be2a2a079d72051b384'),(19,NULL,NULL,'album_photo',6,5,'2014-10-27 01:48:07','2014-10-27 01:48:07',1,'public/album_photo/13/0013_c110.jpg','jpg','IMG_20141024_164456_m_m.jpg','image','jpeg',75941,'68f9c11065b82f5e4a3693b7c8aadcc6'),(20,19,'thumb.normal','album_photo',6,5,'2014-10-27 01:48:07','2014-10-27 01:48:07',1,'public/album_photo/14/0014_128d.jpg','jpg','IMG_20141024_164456_m_in.jpg','image','jpeg',4667,'4675128dcfea711c5968a3a4682de039'),(21,NULL,NULL,'user',4,4,'2014-10-28 02:26:58','2014-10-28 02:26:58',1,'public/user/15/0015_ed3b.png','png','Face-Logo-blue-2_m.png','image','png',242480,'b5b8ed3b9512b29b2a50012b4a418cf2'),(22,21,'thumb.profile','user',4,4,'2014-10-28 02:26:58','2014-10-28 02:26:58',1,'public/user/16/0016_836b.png','png','Face-Logo-blue-2_p.png','image','png',21497,'1c65836bc42d31d79ab45c508c4c4b82'),(23,21,'thumb.normal','user',4,4,'2014-10-28 02:26:58','2014-10-28 02:26:58',1,'public/user/17/0017_6293.png','png','Face-Logo-blue-2_in.png','image','png',15152,'18206293a29ede4786dc7687acd4033b'),(24,21,'thumb.icon','user',4,4,'2014-10-28 02:26:58','2014-10-28 02:26:58',1,'public/user/18/0018_72b1.png','png','Face-Logo-blue-2_is.png','image','png',3161,'e1d272b19e5a110116db5e9906417ae1'),(25,NULL,NULL,'album_photo',7,4,'2014-10-28 02:26:59','2014-10-28 02:26:59',1,'public/album_photo/19/0019_ed3b.png','png','Face-Logo-blue-2_m_m.png','image','png',242480,'b5b8ed3b9512b29b2a50012b4a418cf2'),(26,25,'thumb.normal','album_photo',7,4,'2014-10-28 02:26:59','2014-10-28 02:26:59',1,'public/album_photo/1a/001a_11d4.png','png','Face-Logo-blue-2_m_in.png','image','png',13484,'b34911d4e14bf484899c954111f1143c');
/*!40000 ALTER TABLE `engine4_storage_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_storage_mirrors`
--

DROP TABLE IF EXISTS `engine4_storage_mirrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_storage_mirrors` (
  `file_id` bigint(20) unsigned NOT NULL,
  `service_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`file_id`,`service_id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_storage_mirrors`
--

LOCK TABLES `engine4_storage_mirrors` WRITE;
/*!40000 ALTER TABLE `engine4_storage_mirrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_storage_mirrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_storage_services`
--

DROP TABLE IF EXISTS `engine4_storage_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_storage_services` (
  `service_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `servicetype_id` int(10) unsigned NOT NULL,
  `config` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_storage_services`
--

LOCK TABLES `engine4_storage_services` WRITE;
/*!40000 ALTER TABLE `engine4_storage_services` DISABLE KEYS */;
INSERT INTO `engine4_storage_services` (`service_id`, `servicetype_id`, `config`, `enabled`, `default`) VALUES (1,1,NULL,1,1);
/*!40000 ALTER TABLE `engine4_storage_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_storage_servicetypes`
--

DROP TABLE IF EXISTS `engine4_storage_servicetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_storage_servicetypes` (
  `servicetype_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `plugin` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `form` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`servicetype_id`),
  UNIQUE KEY `plugin` (`plugin`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_storage_servicetypes`
--

LOCK TABLES `engine4_storage_servicetypes` WRITE;
/*!40000 ALTER TABLE `engine4_storage_servicetypes` DISABLE KEYS */;
INSERT INTO `engine4_storage_servicetypes` (`servicetype_id`, `title`, `plugin`, `form`, `enabled`) VALUES (1,'Local Storage','Storage_Service_Local','Storage_Form_Admin_Service_Local',1),(2,'Database Storage','Storage_Service_Db','Storage_Form_Admin_Service_Db',0),(3,'Amazon S3','Storage_Service_S3','Storage_Form_Admin_Service_S3',1),(4,'Virtual File System','Storage_Service_Vfs','Storage_Form_Admin_Service_Vfs',1),(5,'Round-Robin','Storage_Service_RoundRobin','Storage_Form_Admin_Service_RoundRobin',0),(6,'Mirrored','Storage_Service_Mirrored','Storage_Form_Admin_Service_Mirrored',0);
/*!40000 ALTER TABLE `engine4_storage_servicetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_block`
--

DROP TABLE IF EXISTS `engine4_user_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_block` (
  `user_id` int(11) unsigned NOT NULL,
  `blocked_user_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`blocked_user_id`),
  KEY `REVERSE` (`blocked_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_block`
--

LOCK TABLES `engine4_user_block` WRITE;
/*!40000 ALTER TABLE `engine4_user_block` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_user_block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_facebook`
--

DROP TABLE IF EXISTS `engine4_user_facebook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_facebook` (
  `user_id` int(11) unsigned NOT NULL,
  `facebook_uid` bigint(20) unsigned NOT NULL,
  `access_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `facebook_uid` (`facebook_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_facebook`
--

LOCK TABLES `engine4_user_facebook` WRITE;
/*!40000 ALTER TABLE `engine4_user_facebook` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_user_facebook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_fields_maps`
--

DROP TABLE IF EXISTS `engine4_user_fields_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_fields_maps` (
  `field_id` int(11) unsigned NOT NULL,
  `option_id` int(11) unsigned NOT NULL,
  `child_id` int(11) unsigned NOT NULL,
  `order` smallint(6) NOT NULL,
  PRIMARY KEY (`field_id`,`option_id`,`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_fields_maps`
--

LOCK TABLES `engine4_user_fields_maps` WRITE;
/*!40000 ALTER TABLE `engine4_user_fields_maps` DISABLE KEYS */;
INSERT INTO `engine4_user_fields_maps` (`field_id`, `option_id`, `child_id`, `order`) VALUES (0,0,1,1),(1,1,2,2),(1,1,3,3),(1,1,4,4),(1,1,5,5),(1,1,6,6),(1,1,7,7),(1,1,8,8),(1,1,9,9),(1,1,10,10),(1,1,11,11),(1,1,12,12),(1,1,13,13);
/*!40000 ALTER TABLE `engine4_user_fields_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_fields_meta`
--

DROP TABLE IF EXISTS `engine4_user_fields_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_fields_meta` (
  `field_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(24) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `label` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(32) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `display` tinyint(1) unsigned NOT NULL,
  `publish` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `search` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `order` smallint(3) unsigned NOT NULL DEFAULT '999',
  `config` text COLLATE utf8_unicode_ci,
  `validators` text COLLATE utf8_unicode_ci,
  `filters` text COLLATE utf8_unicode_ci,
  `style` text COLLATE utf8_unicode_ci,
  `error` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`field_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_fields_meta`
--

LOCK TABLES `engine4_user_fields_meta` WRITE;
/*!40000 ALTER TABLE `engine4_user_fields_meta` DISABLE KEYS */;
INSERT INTO `engine4_user_fields_meta` (`field_id`, `type`, `label`, `description`, `alias`, `required`, `display`, `publish`, `search`, `show`, `order`, `config`, `validators`, `filters`, `style`, `error`) VALUES (1,'profile_type','Profile Type','','profile_type',1,0,0,2,1,999,'',NULL,NULL,NULL,NULL),(2,'heading','Personal Information','','',0,1,0,0,1,999,'',NULL,NULL,NULL,NULL),(3,'first_name','First Name','','first_name',1,1,0,2,1,999,'','[[\"StringLength\",false,[1,32]]]',NULL,NULL,NULL),(4,'last_name','Last Name','','last_name',1,1,0,2,1,999,'','[[\"StringLength\",false,[1,32]]]',NULL,NULL,NULL),(5,'gender','Gender','','gender',0,1,0,1,1,999,'',NULL,NULL,NULL,NULL),(6,'birthdate','Birthday','','birthdate',0,1,0,1,1,999,'',NULL,NULL,NULL,NULL),(7,'heading','Contact Information','','',0,1,0,0,1,999,'',NULL,NULL,NULL,NULL),(8,'website','Website','','',0,1,0,0,1,999,'',NULL,NULL,NULL,NULL),(9,'twitter','Twitter','','',0,1,0,0,1,999,'',NULL,NULL,NULL,NULL),(10,'facebook','Facebook','','',0,1,0,0,1,999,'',NULL,NULL,NULL,NULL),(11,'aim','AIM','','',0,1,0,0,1,999,'',NULL,NULL,NULL,NULL),(12,'heading','Personal Details','','',0,1,0,0,1,999,'',NULL,NULL,NULL,NULL),(13,'about_me','About Me','','',0,1,0,0,1,999,'',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `engine4_user_fields_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_fields_options`
--

DROP TABLE IF EXISTS `engine4_user_fields_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_fields_options` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(11) unsigned NOT NULL,
  `label` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order` smallint(6) NOT NULL DEFAULT '999',
  PRIMARY KEY (`option_id`),
  KEY `field_id` (`field_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_fields_options`
--

LOCK TABLES `engine4_user_fields_options` WRITE;
/*!40000 ALTER TABLE `engine4_user_fields_options` DISABLE KEYS */;
INSERT INTO `engine4_user_fields_options` (`option_id`, `field_id`, `label`, `order`) VALUES (1,1,'Regular Member',1),(2,5,'Male',1),(3,5,'Female',2);
/*!40000 ALTER TABLE `engine4_user_fields_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_fields_search`
--

DROP TABLE IF EXISTS `engine4_user_fields_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_fields_search` (
  `item_id` int(11) unsigned NOT NULL,
  `profile_type` smallint(11) unsigned DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` smallint(6) unsigned DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `profile_type` (`profile_type`),
  KEY `first_name` (`first_name`),
  KEY `last_name` (`last_name`),
  KEY `gender` (`gender`),
  KEY `birthdate` (`birthdate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_fields_search`
--

LOCK TABLES `engine4_user_fields_search` WRITE;
/*!40000 ALTER TABLE `engine4_user_fields_search` DISABLE KEYS */;
INSERT INTO `engine4_user_fields_search` (`item_id`, `profile_type`, `first_name`, `last_name`, `gender`, `birthdate`) VALUES (1,1,'Emil','Torres',2,'0000-00-00'),(2,1,'Quintin','Evans',0,'0000-00-00'),(3,1,'Quintin2','Evans2',0,'0000-00-00'),(4,1,'Mike','Estes',2,'1987-01-30'),(5,1,'Jason','Bryant',2,'1988-11-16');
/*!40000 ALTER TABLE `engine4_user_fields_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_fields_values`
--

DROP TABLE IF EXISTS `engine4_user_fields_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_fields_values` (
  `item_id` int(11) unsigned NOT NULL,
  `field_id` int(11) unsigned NOT NULL,
  `index` smallint(3) unsigned NOT NULL DEFAULT '0',
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `privacy` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`item_id`,`field_id`,`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_fields_values`
--

LOCK TABLES `engine4_user_fields_values` WRITE;
/*!40000 ALTER TABLE `engine4_user_fields_values` DISABLE KEYS */;
INSERT INTO `engine4_user_fields_values` (`item_id`, `field_id`, `index`, `value`, `privacy`) VALUES (1,1,0,'1',NULL),(1,3,0,'Emil','everyone'),(1,4,0,'Torres','everyone'),(1,5,0,'2','everyone'),(1,6,0,'','self'),(1,8,0,'','everyone'),(1,9,0,'','everyone'),(1,10,0,'https://www.facebook.com/emil.torres.10','everyone'),(1,11,0,'','everyone'),(1,13,0,'My name is Emil and I will soon be rich!!','everyone'),(2,1,0,'1',NULL),(2,3,0,'Quintin',NULL),(2,4,0,'Evans',NULL),(2,5,0,'',NULL),(2,6,0,'',NULL),(2,8,0,'',NULL),(2,9,0,'',NULL),(2,10,0,'',NULL),(2,11,0,'',NULL),(2,13,0,'',NULL),(3,1,0,'1',NULL),(3,3,0,'Quintin2',NULL),(3,4,0,'Evans2',NULL),(3,5,0,'',NULL),(3,6,0,'',NULL),(3,8,0,'',NULL),(3,9,0,'',NULL),(3,10,0,'',NULL),(3,11,0,'',NULL),(3,13,0,'',NULL),(4,1,0,'1',NULL),(4,3,0,'Mike','everyone'),(4,4,0,'Estes','everyone'),(4,5,0,'2','everyone'),(4,6,0,'1987-1-30','everyone'),(4,8,0,'www.facebook.com/lootgasm','everyone'),(4,9,0,'','everyone'),(4,10,0,'','everyone'),(4,11,0,'','everyone'),(4,13,0,'','everyone'),(5,1,0,'1',NULL),(5,3,0,'Jason',NULL),(5,4,0,'Bryant',NULL),(5,5,0,'2',NULL),(5,6,0,'1988-11-16',NULL),(5,8,0,'',NULL),(5,9,0,'',NULL),(5,10,0,'',NULL),(5,11,0,'',NULL),(5,13,0,'',NULL);
/*!40000 ALTER TABLE `engine4_user_fields_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_forgot`
--

DROP TABLE IF EXISTS `engine4_user_forgot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_forgot` (
  `user_id` int(11) unsigned NOT NULL,
  `code` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `creation_date` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_forgot`
--

LOCK TABLES `engine4_user_forgot` WRITE;
/*!40000 ALTER TABLE `engine4_user_forgot` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_user_forgot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_janrain`
--

DROP TABLE IF EXISTS `engine4_user_janrain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_janrain` (
  `user_id` int(11) unsigned NOT NULL,
  `identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `provider` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `identifier` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_janrain`
--

LOCK TABLES `engine4_user_janrain` WRITE;
/*!40000 ALTER TABLE `engine4_user_janrain` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_user_janrain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_listitems`
--

DROP TABLE IF EXISTS `engine4_user_listitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_listitems` (
  `listitem_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `list_id` int(11) unsigned NOT NULL,
  `child_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`listitem_id`),
  KEY `list_id` (`list_id`),
  KEY `child_id` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_listitems`
--

LOCK TABLES `engine4_user_listitems` WRITE;
/*!40000 ALTER TABLE `engine4_user_listitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_user_listitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_lists`
--

DROP TABLE IF EXISTS `engine4_user_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_lists` (
  `list_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `owner_id` int(11) unsigned NOT NULL,
  `child_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`list_id`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_lists`
--

LOCK TABLES `engine4_user_lists` WRITE;
/*!40000 ALTER TABLE `engine4_user_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_user_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_logins`
--

DROP TABLE IF EXISTS `engine4_user_logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_logins` (
  `login_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip` varbinary(16) NOT NULL,
  `timestamp` datetime NOT NULL,
  `state` enum('success','no-member','bad-password','disabled','unpaid','third-party','v3-migration','unknown') CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'unknown',
  `source` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`login_id`),
  KEY `user_id` (`user_id`),
  KEY `email` (`email`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_logins`
--

LOCK TABLES `engine4_user_logins` WRITE;
/*!40000 ALTER TABLE `engine4_user_logins` DISABLE KEYS */;
INSERT INTO `engine4_user_logins` (`login_id`, `user_id`, `email`, `ip`, `timestamp`, `state`, `source`, `active`) VALUES (1,1,'socialengine@test.grsband.com','�Y�U','2014-10-23 01:20:25','success',NULL,0),(2,1,'socialengine@test.grsband.com','�Y�U','2014-10-23 02:30:26','success',NULL,0),(3,1,'socialengine@test.grsband.com','�Y�U','2014-10-23 02:45:43','success',NULL,0),(4,NULL,'sregge@gmail.com','G/i','2014-10-23 03:23:54','no-member',NULL,0),(5,1,'socialengine@test.grsband.com','�Y�U','2014-10-23 23:38:46','success',NULL,0),(6,1,'socialengine@test.grsband.com','�Y�U','2014-10-24 00:46:33','success',NULL,0),(7,4,'sregge@gmail.com','G/i','2014-10-28 02:26:22','success',NULL,1),(8,1,'socialengine@test.grsband.com','��\'�','2014-10-28 09:53:51','success',NULL,0),(9,NULL,'admin@socialengine.com','��\'�','2014-10-28 09:56:04','no-member',NULL,0),(10,1,'socialengine@test.grsband.com','��\'�','2014-10-28 09:56:37','success',NULL,1),(11,5,'jlorde34@yahoo.com','G+\\)','2014-10-29 22:05:12','success',NULL,1),(12,5,'jlorde34@yahoo.com','2Y�','2014-10-31 05:27:29','success',NULL,1),(13,5,'jlorde34@yahoo.com','���','2014-10-31 19:14:01','success',NULL,1),(14,5,'jlorde34@yahoo.com','2Y�','2014-11-01 02:38:06','success',NULL,1);
/*!40000 ALTER TABLE `engine4_user_logins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_membership`
--

DROP TABLE IF EXISTS `engine4_user_membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_membership` (
  `resource_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `resource_approved` tinyint(1) NOT NULL DEFAULT '0',
  `user_approved` tinyint(1) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`resource_id`,`user_id`),
  KEY `REVERSE` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_membership`
--

LOCK TABLES `engine4_user_membership` WRITE;
/*!40000 ALTER TABLE `engine4_user_membership` DISABLE KEYS */;
INSERT INTO `engine4_user_membership` (`resource_id`, `user_id`, `active`, `resource_approved`, `user_approved`, `message`, `description`) VALUES (1,4,1,1,1,NULL,NULL),(4,1,1,1,1,NULL,NULL);
/*!40000 ALTER TABLE `engine4_user_membership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_online`
--

DROP TABLE IF EXISTS `engine4_user_online`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_online` (
  `ip` varbinary(16) NOT NULL,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `active` datetime NOT NULL,
  PRIMARY KEY (`ip`,`user_id`),
  KEY `LOOKUP` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_online`
--

LOCK TABLES `engine4_user_online` WRITE;
/*!40000 ALTER TABLE `engine4_user_online` DISABLE KEYS */;
INSERT INTO `engine4_user_online` (`ip`, `user_id`, `active`) VALUES ('ѼV�',0,'2014-10-31 21:34:12'),('���',5,'2014-10-31 22:01:12'),('2Y�',0,'2014-11-01 02:38:06'),('2Y�',5,'2014-11-01 02:43:25');
/*!40000 ALTER TABLE `engine4_user_online` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_settings`
--

DROP TABLE IF EXISTS `engine4_user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_settings` (
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_settings`
--

LOCK TABLES `engine4_user_settings` WRITE;
/*!40000 ALTER TABLE `engine4_user_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_user_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_signup`
--

DROP TABLE IF EXISTS `engine4_user_signup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_signup` (
  `signup_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `order` smallint(6) NOT NULL DEFAULT '999',
  `enable` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`signup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_signup`
--

LOCK TABLES `engine4_user_signup` WRITE;
/*!40000 ALTER TABLE `engine4_user_signup` DISABLE KEYS */;
INSERT INTO `engine4_user_signup` (`signup_id`, `class`, `order`, `enable`) VALUES (1,'User_Plugin_Signup_Account',1,1),(2,'User_Plugin_Signup_Fields',2,1),(3,'User_Plugin_Signup_Photo',3,1),(4,'User_Plugin_Signup_Invite',4,0),(5,'Payment_Plugin_Signup_Subscription',0,0);
/*!40000 ALTER TABLE `engine4_user_signup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_twitter`
--

DROP TABLE IF EXISTS `engine4_user_twitter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_twitter` (
  `user_id` int(10) unsigned NOT NULL,
  `twitter_uid` bigint(20) unsigned NOT NULL,
  `twitter_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter_secret` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `twitter_uid` (`twitter_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_twitter`
--

LOCK TABLES `engine4_user_twitter` WRITE;
/*!40000 ALTER TABLE `engine4_user_twitter` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_user_twitter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_user_verify`
--

DROP TABLE IF EXISTS `engine4_user_verify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_user_verify` (
  `user_id` int(11) unsigned NOT NULL,
  `code` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_user_verify`
--

LOCK TABLES `engine4_user_verify` WRITE;
/*!40000 ALTER TABLE `engine4_user_verify` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_user_verify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_users`
--

DROP TABLE IF EXISTS `engine4_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_users` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `displayname` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `photo_id` int(11) unsigned NOT NULL DEFAULT '0',
  `status` text COLLATE utf8_unicode_ci,
  `status_date` datetime DEFAULT NULL,
  `password` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `salt` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `locale` varchar(16) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'auto',
  `language` varchar(8) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'en_US',
  `timezone` varchar(64) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'America/Los_Angeles',
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `show_profileviewers` tinyint(1) NOT NULL DEFAULT '1',
  `level_id` int(11) unsigned NOT NULL,
  `invites_used` int(11) unsigned NOT NULL DEFAULT '0',
  `extra_invites` int(11) unsigned NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  `creation_date` datetime NOT NULL,
  `creation_ip` varbinary(16) NOT NULL,
  `modified_date` datetime NOT NULL,
  `lastlogin_date` datetime DEFAULT NULL,
  `lastlogin_ip` varbinary(16) DEFAULT NULL,
  `update_date` int(11) DEFAULT NULL,
  `member_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `EMAIL` (`email`),
  UNIQUE KEY `USERNAME` (`username`),
  KEY `MEMBER_COUNT` (`member_count`),
  KEY `CREATION_DATE` (`creation_date`),
  KEY `search` (`search`),
  KEY `enabled` (`enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_users`
--

LOCK TABLES `engine4_users` WRITE;
/*!40000 ALTER TABLE `engine4_users` DISABLE KEYS */;
INSERT INTO `engine4_users` (`user_id`, `email`, `username`, `displayname`, `photo_id`, `status`, `status_date`, `password`, `salt`, `locale`, `language`, `timezone`, `search`, `show_profileviewers`, `level_id`, `invites_used`, `extra_invites`, `enabled`, `verified`, `approved`, `creation_date`, `creation_ip`, `modified_date`, `lastlogin_date`, `lastlogin_ip`, `update_date`, `member_count`, `view_count`) VALUES (1,'socialengine@test.grsband.com','test','Emil Torres',1,'Yoo Im Emil and I rule!!','2014-10-23 23:42:02','ba344486de69a0940096c9c1b2cd1385','3059322','auto','en_US','US/Pacific',1,1,1,0,0,1,1,1,'2014-10-14 23:35:53','3092880725','2014-10-28 11:18:11','2014-10-28 09:56:37','��\'�',NULL,1,2),(2,'quintin_evans@hotmail.com','qthegreat3','Quintin Evans',0,NULL,NULL,'2966411fe9826039bb3f2ba60a4623ec','9367468','English','English','US/Eastern',1,1,4,0,0,1,1,1,'2014-10-17 11:11:57','��\'�','2014-10-17 11:27:56','2014-10-17 11:11:57','��\'�',NULL,0,0),(3,'qthegreat3@hotmail.com','quintin','Quintin2 Evans2',0,NULL,NULL,'037a1dc8101971f0f3428ad4c9e2f807','3398358','English','English','US/Pacific',1,1,4,0,0,1,1,1,'2014-10-17 11:30:55','��\'�','2014-10-17 11:31:19','2014-10-17 11:30:55','��\'�',NULL,0,2),(4,'sregge@gmail.com','sregge','Mike Estes',21,NULL,NULL,'7addf9bf1c8b84a51cdd1f7e246298d8','6014959','English','English','US/Pacific',1,1,4,0,0,1,1,1,'2014-10-23 03:24:47','G/i','2014-10-28 02:26:58','2014-10-28 02:26:22','G/i',NULL,1,0),(5,'jlorde34@yahoo.com','jlorde34','Jason Bryant',15,'Hello!!','2014-10-27 01:46:49','15c6e163691b45b42f3ccbd3f12d8a81','5247395','English','English','US/Eastern',1,1,4,0,0,1,1,1,'2014-10-27 01:45:59','2Y�','2014-10-27 01:48:06','2014-11-01 02:38:06','2Y�',NULL,0,3);
/*!40000 ALTER TABLE `engine4_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_video_categories`
--

DROP TABLE IF EXISTS `engine4_video_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_video_categories` (
  `category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `category_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_video_categories`
--

LOCK TABLES `engine4_video_categories` WRITE;
/*!40000 ALTER TABLE `engine4_video_categories` DISABLE KEYS */;
INSERT INTO `engine4_video_categories` (`category_id`, `user_id`, `category_name`) VALUES (1,0,'Autos & Vehicles'),(2,0,'Comedy'),(3,0,'Education'),(4,0,'Entertainment'),(5,0,'Film & Animation'),(6,0,'Gaming'),(7,0,'Howto & Style'),(8,0,'Music'),(9,0,'News & Politics'),(10,0,'Nonprofits & Activism'),(11,0,'People & Blogs'),(12,0,'Pets & Animals'),(13,0,'Science & Technology'),(14,0,'Sports'),(15,0,'Travel & Events');
/*!40000 ALTER TABLE `engine4_video_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_video_ratings`
--

DROP TABLE IF EXISTS `engine4_video_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_video_ratings` (
  `video_id` int(10) unsigned NOT NULL,
  `user_id` int(9) unsigned NOT NULL,
  `rating` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`video_id`,`user_id`),
  KEY `INDEX` (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_video_ratings`
--

LOCK TABLES `engine4_video_ratings` WRITE;
/*!40000 ALTER TABLE `engine4_video_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_video_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `engine4_video_videos`
--

DROP TABLE IF EXISTS `engine4_video_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `engine4_video_videos` (
  `video_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `search` tinyint(1) NOT NULL DEFAULT '1',
  `owner_type` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `owner_id` int(11) NOT NULL,
  `parent_type` varchar(128) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `parent_id` int(11) unsigned DEFAULT NULL,
  `creation_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `view_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL,
  `code` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `photo_id` int(11) unsigned DEFAULT NULL,
  `rating` float NOT NULL,
  `category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL,
  `file_id` int(11) unsigned NOT NULL,
  `duration` int(9) unsigned NOT NULL,
  `rotation` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`video_id`),
  KEY `owner_id` (`owner_id`,`owner_type`),
  KEY `search` (`search`),
  KEY `creation_date` (`creation_date`),
  KEY `view_count` (`view_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `engine4_video_videos`
--

LOCK TABLES `engine4_video_videos` WRITE;
/*!40000 ALTER TABLE `engine4_video_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `engine4_video_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'grsbandc_socialengine'
--

--
-- Dumping routines for database 'grsbandc_socialengine'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-09  4:42:42
