<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'moocomet',
    'version' => '4.0.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/moocomet',
    'repository' => 'socialengine.com',
    'title' => 'Moocomet',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/moocomet',
    )
  )
) ?>