<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'html5media',
    'version' => '4.8.5',
    'revision' => '$Revision: 10270 $',
    'path' => 'externals/html5media',
    'repository' => 'socialengine.com',
    'title' => 'Html5 Media',
    'author' => 'Webligo Developments',
    'changeLog' => array(
    ),
    'directories' => array(
      'externals/html5media',
    )
  )
) ?>