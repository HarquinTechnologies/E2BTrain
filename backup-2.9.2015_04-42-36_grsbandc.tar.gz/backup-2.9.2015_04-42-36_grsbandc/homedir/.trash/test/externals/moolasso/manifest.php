<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'moolasso',
    'version' => '4.1.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/moolasso',
    'repository' => 'socialengine.com',
    'title' => 'Moolasso',
    'author' => 'Webligo Developments',
    'changeLog' => array(
      '4.1.0' => array(
        'Lasso.Crop.js' => 'Fixes issue with Internet Explorer',
        'Lasso.js' => 'Fixes issue with Internet Explorer',
        'manifest.php' => 'Incremented version',
      ),
    ),
    'directories' => array(
      'externals/moolasso',
    )
  )
) ?>