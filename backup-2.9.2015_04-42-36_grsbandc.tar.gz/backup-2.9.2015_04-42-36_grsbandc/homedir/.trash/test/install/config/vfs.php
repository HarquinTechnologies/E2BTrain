<?php return array (
  'adapter' => 'ftp',
  'config' => 
  array (
    'host' => '127.0.0.1:21',
    'username' => 'grsbandc',
    'path' => '/public_html/test',
    'useSsl' => '',
  ),
)?>