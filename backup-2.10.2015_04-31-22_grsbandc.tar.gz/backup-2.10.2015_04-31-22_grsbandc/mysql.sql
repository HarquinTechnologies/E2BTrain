-- cPanel mysql backup
GRANT USAGE ON *.* TO 'grsbandc'@'localhost' IDENTIFIED BY PASSWORD '*418FB161A0C3679BB81BDD5158E9480744CFDF02';
GRANT ALL PRIVILEGES ON `grsbandc\_socialengine`.* TO 'grsbandc'@'localhost';
GRANT ALL PRIVILEGES ON `grsbandc\_wp314`.* TO 'grsbandc'@'localhost';
GRANT USAGE ON *.* TO 'grsbandc_harquin'@'localhost' IDENTIFIED BY PASSWORD '*B9F747020F4F0BA4D7E39FDD3405441AE236EBC9';
GRANT ALL PRIVILEGES ON `grsbandc\_socialengine`.* TO 'grsbandc_harquin'@'localhost';
GRANT USAGE ON *.* TO 'grsbandc_wp314'@'localhost' IDENTIFIED BY PASSWORD '*0BC7B87C475AE7FC6726550BCE8C33395DA2D17A';
GRANT ALL PRIVILEGES ON `grsbandc\_wp314`.* TO 'grsbandc_wp314'@'localhost';
